'use strict';
// T-376 phase 2 helper: read the live HideEmbeds/RemoveGIFS/RemoveStickers/
// GoodEmoji state out of the running Discord. Read-only.

const { pageTargets, connect } = require('../../tools/cdp-client.js');

const PORT = Number(process.env.BD_CDP_PORT || 9223);
const FOUR = ['HideEmbeds', 'RemoveGIFS', 'RemoveStickers', 'GoodEmoji'];

const ATTRS = ['state', 'visual', 'ph', 'act', 'shown', 'scoped', 'embed', 'scope'];

const SNAPSHOT = `(() => {
  const out = { attrCounts: {} };
  for (const a of ${JSON.stringify(ATTRS)}) {
    const sel = '[data-w95-' + a + ']';
    out.attrCounts[a] = document.querySelectorAll(sel).length;
  }
  out.attrValues = {
    state: [...new Set([...document.querySelectorAll('[data-w95-state]')].map(n => n.getAttribute('data-w95-state')))],
    visual: [...new Set([...document.querySelectorAll('[data-w95-visual]')].map(n => n.getAttribute('data-w95-visual')))]
  };
  out.plugins = {};
  for (const n of ${JSON.stringify(FOUR)}) {
    try {
      const p = BdApi.Plugins.get(n);
      out.plugins[n] = {
        settings: p.settings || null,
        started: p.started === undefined ? null : p.started,
        enabled: p.enabled === undefined ? null : p.enabled,
        hasStart: typeof p.start === 'function',
        hasStop: typeof p.stop === 'function'
      };
    } catch (e) {
      out.plugins[n] = 'ERR ' + e.message;
    }
  }
  out.dom = {
    rows: document.querySelectorAll('[id^=chat-messages]').length,
    img: document.querySelectorAll('[class*=messageContent] img').length,
    video: document.querySelectorAll('video').length,
    httpLinks: document.querySelectorAll('a[href^=http]').length,
    sticker: document.querySelectorAll('[class*=sticker], img[src*="stickers"]').length,
    gif: document.querySelectorAll('img[src*="media"], video[src*="media"]').length
  };
  return JSON.stringify(out);
})()`;

async function evaluate(cdp, expression) {
  const r = await cdp.send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: false });
  if (r.exceptionDetails) {
    throw new Error('evaluate threw: ' + (r.exceptionDetails.exception?.description || r.exceptionDetails.text));
  }
  return r.result.value;
}

async function main() {
  const targets = await pageTargets(PORT);
  if (!targets.length) throw new Error('no page target on CDP ' + PORT);
  const cdp = connect(targets[0]);
  await cdp.ready;
  await cdp.send('Runtime.enable');
  const raw = await evaluate(cdp, SNAPSHOT);
  console.log(JSON.stringify(JSON.parse(raw), null, 2));
  cdp.close();
}

main().catch((e) => {
  console.error('FAILED: ' + (e && e.message ? e.message : String(e)));
  process.exit(2);
});