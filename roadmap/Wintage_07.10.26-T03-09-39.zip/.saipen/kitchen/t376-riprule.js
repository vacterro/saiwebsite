'use strict';
// T-376: does ANY message row in this channel satisfy the shipped rich-link-card
// rule? This is the same predicate HideEmbeds uses (cardBlock + the anchor
// vetoes), re-implemented read-only against the live DOM, so the answer is about
// real message content rather than about a loose class-name guess.
//
// Read-only: it classifies, it does not mutate.

const { pageTargets, connect } = require('../../tools/cdp-client.js');

const PORT = Number(process.env.BD_CDP_PORT || 9223);

async function ev(c, e) {
  const r = await c.send('Runtime.evaluate', { expression: e, returnByValue: true });
  if (r.exceptionDetails) {
    throw new Error((r.exceptionDetails.exception && r.exceptionDetails.exception.description) || r.exceptionDetails.text);
  }
  return r.result.value;
}

const SCROLLER = `[...document.querySelectorAll('div')].find(x => x.scrollHeight > x.clientHeight + 40 && x.clientHeight > 200 && x.querySelector('[id^=chat-messages]'))`;

const BY = (dy) => `(() => { const n = ${SCROLLER}; if (!n) return 'no scroller'; n.scrollTop += ${dy}; return Math.round(n.scrollTop); })()`;

// The shipped rule, transcribed from HideEmbeds v1.1.2 cardBlock()/richCards().
const SCAN = `(() => {
  const MSG_TEXT = '[id^="message-content-"]';
  const REPLY_REF = '[class*="messageReference"]';
  const CHROME = '[class*="chatContent"], nav, [role="navigation"]';
  const CONTROL = '[class*="messageActions"], [class*="hoverButton"], button, [role="button"]';
  const CDN = /^(?:https?:\\/\\/)?(?:cdn|media)\\.(?:discordapp|discord)\\.net/i;
  const text = (n) => (n.textContent || '').trim();

  function cardBlock(row, anchor) {
    if (anchor.closest(MSG_TEXT)) return null;
    if (anchor.closest(REPLY_REF)) return null;
    if (anchor.closest(CHROME)) return null;
    if (anchor.closest(CONTROL)) return null;
    if (anchor.closest('[data-poll-id],[id^="components-"]')) return null;
    let block = anchor, n = anchor.parentElement;
    while (n && n !== row && row.contains(n)) {
      if (n.querySelector(MSG_TEXT) || n.querySelector(REPLY_REF)) break;
      block = n; n = n.parentElement;
    }
    if (block === row) return null;
    return block;
  }

  const rows = [...document.querySelectorAll('[id^=chat-messages]')];
  let candidateAnchors = 0, vetoedText = 0, vetoedMedia = 0, vetoedShort = 0, vetoedCdn = 0, realCards = 0;
  const cardRows = [];
  for (const row of rows) {
    let rowCards = 0;
    for (const a of row.querySelectorAll('a[href^="http"]')) {
      candidateAnchors++;
      const href = a.getAttribute('href') || '';
      if (CDN.test(href)) { vetoedCdn++; continue; }
      if (a.querySelector('img,video')) { vetoedMedia++; continue; }
      if (text(a).length < 3) { vetoedShort++; continue; }
      const block = cardBlock(row, a);
      if (!block) { vetoedText++; continue; }
      rowCards++;
    }
    if (rowCards) { realCards += rowCards; cardRows.push({ id: row.id.slice(0, 46), cards: rowCards }); }
  }
  return JSON.stringify({
    rowsScanned: rows.length,
    candidateAnchors,
    vetoedCdn, vetoedMedia, vetoedShort, vetoedInTextOrChrome: vetoedText,
    qualifyingRichCards: realCards,
    cardRows: cardRows.slice(0, 10)
  });
})()`;

const wait = (ms) => new Promise((r) => setTimeout(r, ms));

(async () => {
  const t = (await pageTargets(PORT))[0];
  const c = connect(t);
  await c.ready;
  await c.send('Runtime.enable');

  let total = 0;
  for (let i = 0; i < 14; i++) {
    const s = JSON.parse(await ev(c, SCAN));
    total = Math.max(total, s.qualifyingRichCards);
    console.log('pass' + i + ': ' + JSON.stringify(s));
    if (s.qualifyingRichCards > 0) { console.log('QUALIFYING CARD EXISTS'); break; }
    await ev(c, BY(-900));
    await wait(2000);
  }
  console.log('best qualifyingRichCards across passes: ' + total);
  c.close();
})().catch((e) => { console.error('FAILED: ' + (e && e.message ? e.message : String(e))); process.exit(2); });