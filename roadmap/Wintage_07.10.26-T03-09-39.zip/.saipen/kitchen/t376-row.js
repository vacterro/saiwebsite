'use strict';
// T-376 phase 2, step 6: dump the real DOM of the HideEmbeds row so the
// settings entry point is found from the markup rather than guessed at.

const { pageTargets, connect } = require('../../tools/cdp-client.js');

const PORT = Number(process.env.BD_CDP_PORT || 9223);

async function ev(cdp, expression) {
  const r = await cdp.send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: false });
  if (r.exceptionDetails) throw new Error(r.exceptionDetails.exception?.description || r.exceptionDetails.text);
  return r.result.value;
}

const ROW = `(() => {
  const d = document.querySelector('[role="dialog"]');
  const leaves = [...d.querySelectorAll('div,span')]
    .filter(n => (n.textContent || '').trim() === 'HideEmbeds');
  if (!leaves.length) return 'no HideEmbeds leaf';
  const leaf = leaves[0];
  const out = [];
  let n = leaf;
  for (let i = 0; i < 6 && n && n !== d; i++) {
    out.push({
      up: i,
      tag: n.tagName,
      cls: (n.className || '').toString().slice(0, 90),
      role: n.getAttribute('role'),
      rect: (() => { const r = n.getBoundingClientRect(); return [Math.round(r.x), Math.round(r.y), Math.round(r.width), Math.round(r.height)]; })(),
      kids: [...n.children].map(c => c.tagName + '.' + (c.className || '').toString().split(' ')[0]).slice(0, 10)
    });
    n = n.parentElement;
  }
  return JSON.stringify(out, null, 1);
})()`;

const SIDEBAR_AFTER = `(() => {
  const d = document.querySelector('[role="dialog"]');
  const nav = d.querySelector('[role="navigation"], nav, [class*="sidebar"]') || d;
  return JSON.stringify([...nav.querySelectorAll('div,span,button,a')]
    .map(n => (n.textContent || '').trim())
    .filter(t => t && t.length < 40)
    .filter((v, i, a) => a.indexOf(v) === i)
    .slice(0, 60));
})()`;

async function main() {
  const targets = await pageTargets(PORT);
  const cdp = connect(targets[0]);
  await cdp.ready;
  await cdp.send('Runtime.enable');
  console.log('row ancestry: ' + await ev(cdp, ROW));
  console.log('sidebar: ' + await ev(cdp, SIDEBAR_AFTER));
  cdp.close();
}

main().catch((e) => { console.error('FAILED: ' + (e && e.message ? e.message : String(e))); process.exit(2); });