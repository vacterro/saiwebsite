'use strict';
// T-376 phase 2, step 6c: what is in the HideEmbeds card footer -- that is
// BetterDiscord's real settings entry point for a plugin.

const { pageTargets, connect } = require('../../tools/cdp-client.js');

const PORT = Number(process.env.BD_CDP_PORT || 9223);

async function ev(cdp, expression) {
  const r = await cdp.send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: false });
  if (r.exceptionDetails) throw new Error(r.exceptionDetails.exception?.description || r.exceptionDetails.text);
  return r.result.value;
}

const FOOTER = `(() => {
  const d = document.querySelector('[role="dialog"]');
  const leaf = [...d.querySelectorAll('div,span')].find(n => (n.textContent || '').trim() === 'HideEmbeds');
  const card = leaf && leaf.closest('.bd-addon-card');
  if (!card) return 'no card';
  const foot = card.querySelector('.bd-footer');
  const out = {
    footerHTML: foot ? foot.outerHTML.slice(0, 900) : '(no footer)',
    footerText: foot ? (foot.innerText || '').trim().slice(0, 200) : '',
    clickables: [...card.querySelectorAll('button, [role=button], a, input, [class*=settings], [class*=gear]')]
      .map(el => el.tagName + ' | ' + (el.className || '').toString().slice(0, 60) + ' | ' + (el.getAttribute('aria-label') || (el.innerText || '').trim().slice(0, 40)))
  };
  return JSON.stringify(out, null, 1);
})()`;

async function main() {
  const targets = await pageTargets(PORT);
  const cdp = connect(targets[0]);
  await cdp.ready;
  await cdp.send('Runtime.enable');
  console.log(await ev(cdp, FOOTER));
  cdp.close();
}

main().catch((e) => { console.error('FAILED: ' + (e && e.message ? e.message : String(e))); process.exit(2); });