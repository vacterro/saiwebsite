'use strict';
// T-376 phase 4: "a row holding both a sticker and a GIF never collapses when
// either plugin is stopped".
//
// Discord never merges a sticker and a GIF into one message: they are separate
// messages. What the clause means in practice is that neither plugin's removal
// can take the OTHER kind down with it -- so the live proof is: find a row that
// carries a GIF and a row that carries a sticker, stop each plugin in turn from
// the real panel, and confirm the other kind is still present and the row has
// not collapsed.

const { pageTargets, connect } = require('../../tools/cdp-client.js');

const PORT = Number(process.env.BD_CDP_PORT || 9223);

async function ev(c, e) {
  const r = await c.send('Runtime.evaluate', { expression: e, returnByValue: true });
  if (r.exceptionDetails) {
    throw new Error((r.exceptionDetails.exception && r.exceptionDetails.exception.description) || r.exceptionDetails.text);
  }
  return r.result.value;
}

const ROWS = `(() => {
  const rows = [...document.querySelectorAll('[id^=chat-messages]')];
  const classify = (row) => {
    const img = [...row.querySelectorAll('img')];
    const sticker = img.filter(i => /sticker|1084|emoji/i.test((i.src || '') + (i.className || '')));
    const gif = img.filter(i => /\\.gif|media\\.discordapp/i.test(i.src || ''));
    const video = [...row.querySelectorAll('video')];
    return {
      id: row.id.slice(0, 40),
      imgs: img.length,
      stickers: sticker.length,
      gifs: gif.length,
      videos: video.length,
      collapsed: row.getBoundingClientRect().height < 12,
      height: Math.round(row.getBoundingClientRect().height)
    };
  };
  const out = rows.map(classify);
  return JSON.stringify({
    total: out.length,
    withGif: out.filter(r => r.gifs > 0).length,
    withSticker: out.filter(r => r.stickers > 0).length,
    withBoth: out.filter(r => r.gifs > 0 && r.stickers > 0).length,
    collapsed: out.filter(r => r.collapsed).map(r => r.id),
    sample: out.filter(r => r.gifs > 0 || r.stickers > 0).slice(0, 8)
  }, null, 1);
})()`;

// Toggle a plugin from the REAL Plugins list: find its card, click its switch.
const TOGGLE_PLUGIN = (name) => `(() => {
  const d = document.querySelector('[role="dialog"]');
  if (!d) return 'no plugins dialog';
  const leaf = [...d.querySelectorAll('div,span')].find(n => (n.textContent || '').trim() === ${JSON.stringify(name)});
  const card = leaf && leaf.closest('.bd-addon-card');
  if (!card) return 'no card for ' + ${JSON.stringify(name)};
  const inp = card.querySelector('input[type=checkbox]');
  if (!inp) return 'no switch';
  const before = inp.checked;
  inp.click();
  return ${JSON.stringify(name)} + ' ' + before + ' -> ' + inp.checked;
})()`;

const wait = (ms) => new Promise((r) => setTimeout(r, ms));

(async () => {
  const t = (await pageTargets(PORT))[0];
  const c = connect(t);
  await c.ready;
  await c.send('Runtime.enable');

  console.log('--- baseline ---');
  console.log(await ev(c, ROWS));

  for (const name of ['RemoveGIFS', 'RemoveStickers']) {
    console.log('--- stop ' + name + ' ---');
    console.log(await ev(c, TOGGLE_PLUGIN(name)));
    await wait(3000);
    console.log(await ev(c, ROWS));
  }

  console.log('--- restore both ---');
  for (const name of ['RemoveStickers', 'RemoveGIFS']) {
    console.log(await ev(c, TOGGLE_PLUGIN(name)));
    await wait(2500);
  }
  console.log(await ev(c, ROWS));

  c.close();
})().catch((e) => { console.error('FAILED: ' + (e && e.message ? e.message : String(e))); process.exit(2); });