'use strict';
// T-376 phase 2, step 7b: open HideEmbeds' settings pane. textContent, not
// innerText: BetterDiscord keeps a card's action buttons at zero opacity until
// hover, and innerText of a hidden node is empty, so the first attempt found
// no Settings button in a button that was plainly labelled.

const { pageTargets, connect } = require('../../tools/cdp-client.js');

const PORT = Number(process.env.BD_CDP_PORT || 9223);

async function ev(cdp, expression) {
  const r = await cdp.send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: false });
  if (r.exceptionDetails) throw new Error(r.exceptionDetails.exception?.description || r.exceptionDetails.text);
  return r.result.value;
}

const OPEN = `(() => {
  const d = document.querySelector('[role="dialog"]');
  const leaf = [...d.querySelectorAll('div,span')].find(n => (n.textContent || '').trim() === 'HideEmbeds');
  const card = leaf && leaf.closest('.bd-addon-card');
  if (!card) return 'no card';
  card.scrollIntoView({ block: 'center' });
  const btns = [...card.querySelectorAll('button')];
  const labels = btns.map(b => ((b.getAttribute('aria-label') || '') + '|' + (b.textContent || '').trim()).slice(0, 40));
  const btn = btns.find(b => (b.getAttribute('aria-label') || '').trim() === 'Settings')
           || btns.find(b => (b.textContent || '').trim() === 'Settings');
  if (!btn) return 'buttons=' + JSON.stringify(labels);
  btn.click();
  return 'clicked Settings';
})()`;

const PANE = `(() => {
  const d = document.querySelector('[role="dialog"]');
  if (!d) return 'NO DIALOG';
  const wide = [...d.querySelectorAll('div')].filter(n => {
    const r = n.getBoundingClientRect(); return r.width > 400 && r.height > 200;
  }).pop();
  const pane = wide || d;
  const txt = (pane.innerText || pane.textContent || '');
  return JSON.stringify({
    head: txt.slice(0, 700),
    switches: [...pane.querySelectorAll('input[type=checkbox], [role=switch]')].map(el => ({
      checked: el.checked === undefined ? null : el.checked,
      labelText: (el.closest('div') && el.closest('div').textContent || '').trim().slice(0, 80)
    })),
    buttons: [...pane.querySelectorAll('button')].map(b => (b.textContent || '').trim()).filter(Boolean).slice(0, 40),
    dropdowns: [...pane.querySelectorAll('[class*=dropdown], [class*=Dropdown], [role=combobox], select')].map(el => ({
      cls: (el.className || '').toString().slice(0, 45), text: (el.textContent || '').trim().slice(0, 70)
    })).slice(0, 15)
  }, null, 1);
})()`;

async function main() {
  const targets = await pageTargets(PORT);
  const cdp = connect(targets[0]);
  await cdp.ready;
  await cdp.send('Runtime.enable');
  console.log('open: ' + await ev(cdp, OPEN));
  await new Promise((r) => setTimeout(r, 3000));
  console.log(await ev(cdp, PANE));
  cdp.close();
}

main().catch((e) => { console.error('FAILED: ' + (e && e.message ? e.message : String(e))); process.exit(2); });