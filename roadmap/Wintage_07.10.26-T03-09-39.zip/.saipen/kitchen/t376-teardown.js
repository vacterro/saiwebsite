'use strict';
// T-376 teardown: prove the run left the operator's settings exactly as it found
// them, close the panels this run opened, and report the final state.
//
// Nothing here is a claim about the pass; it is the receipt that the pass did
// not permanently alter anything.

const { pageTargets, connect } = require('../../tools/cdp-client.js');

const PORT = Number(process.env.BD_CDP_PORT || 9223);

async function ev(c, e) {
  const r = await c.send('Runtime.evaluate', { expression: e, returnByValue: true });
  if (r.exceptionDetails) {
    throw new Error((r.exceptionDetails.exception && r.exceptionDetails.exception.description) || r.exceptionDetails.text);
  }
  return r.result.value;
}

const PANEL = `(() => {
  const d = [...document.querySelectorAll('[role="dialog"]')].find(x => /HideEmbeds Settings/.test(x.textContent || ''));
  if (!d) return 'no HideEmbeds dialog';
  const out = {};
  for (const inp of d.querySelectorAll('input[type=checkbox]')) {
    let n = inp, t = '';
    for (let i = 0; i < 6 && n; i++) { const c2 = (n.textContent || '').trim(); if (c2 && c2.length < 120) { t = c2; break; } n = n.parentElement; }
    out[t] = inp.checked;
  }
  const sel = [...d.querySelectorAll('select')].map(s => s.value);
  return JSON.stringify({ checkboxes: out, selects: sel });
})()`;

const PLUGINS_LIST = `(() => {
  const d = [...document.querySelectorAll('[role="dialog"]')].find(x => /Plugins sidebar|Plugins/.test(x.textContent || '') && /Plugins [0-9]+ \\([0-9]+ Enabled\\)/.test(x.textContent || ''));
  if (!d) return 'no plugins dialog';
  const want = ['HideEmbeds', 'RemoveGIFS', 'RemoveStickers', 'GoodEmoji'];
  const out = {};
  for (const b of d.querySelectorAll('input[type=checkbox]')) {
    let n = b, name = null;
    for (let i = 0; i < 8 && n; i++) {
      const t = (n.textContent || '').trim();
      const m = want.find(w => t.startsWith(w));
      if (m) { name = m; break; }
      n = n.parentElement;
    }
    if (name) out[name] = b.checked;
  }
  return JSON.stringify({ toggles: out, total: d.querySelectorAll('input[type=checkbox]').length });
})()`;

const CLOSE_ALL = `(() => {
  const before = document.querySelectorAll('[role="dialog"]').length;
  for (const b of document.querySelectorAll('[role="dialog"] button')) {
    const a = (b.getAttribute('aria-label') || '');
    if (/close/i.test(a)) { b.click(); break; }
  }
  return 'dialogs ' + before + ' -> ' + document.querySelectorAll('[role="dialog"]').length;
})()`;

const wait = (ms) => new Promise((r) => setTimeout(r, ms));

(async () => {
  const t = (await pageTargets(PORT))[0];
  const c = connect(t);
  await c.ready;
  await c.send('Runtime.enable');

  console.log('HideEmbeds panel : ' + await ev(c, PANEL));
  console.log('plugin toggles   : ' + await ev(c, PLUGINS_LIST));
  console.log('close            : ' + await ev(c, CLOSE_ALL));
  await wait(1200);
  console.log('close again      : ' + await ev(c, CLOSE_ALL));
  await wait(1200);
  console.log('dialogs left     : ' + await ev(c, `String(document.querySelectorAll('[role="dialog"]').length)`));
  c.close();
})().catch((e) => { console.error('FAILED: ' + (e && e.message ? e.message : String(e))); process.exit(2); });