'use strict';
// T-376 phase 2, step 5: read the enable toggle of each of the four plugins out
// of the real Plugins panel, then open HideEmbeds' own settings page.

const fs = require('fs');
const { pageTargets, connect } = require('../../tools/cdp-client.js');

const PORT = Number(process.env.BD_CDP_PORT || 9223);
const FOUR = ['HideEmbeds', 'RemoveGIFS', 'RemoveStickers', 'GoodEmoji'];

async function ev(cdp, expression) {
  const r = await cdp.send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: false });
  if (r.exceptionDetails) throw new Error(r.exceptionDetails.exception?.description || r.exceptionDetails.text);
  return r.result.value;
}

// Walk up from each checkbox to the row that names its plugin. BetterDiscord
// renders name+version+author in one row element; the checkbox is a sibling.
const FOUR_TOGGLES = `(() => {
  const want = ${JSON.stringify(FOUR)};
  const d = document.querySelector('[role="dialog"]');
  const boxes = [...d.querySelectorAll('input[type=checkbox]')];
  const out = {};
  for (const b of boxes) {
    let n = b;
    let name = null;
    for (let i = 0; i < 8 && n; i++) {
      const t = (n.innerText || '').trim();
      const m = want.find(w => t.startsWith(w));
      if (m) { name = m; break; }
      n = n.parentElement;
    }
    if (name) out[name] = { checked: b.checked, id: b.id || null };
  }
  return JSON.stringify({ found: Object.keys(out), out, totalBoxes: boxes.length,
                          checked: boxes.filter(b => b.checked).length });
})()`;

const OPEN_PLUGIN = (name) => `(() => {
  const d = document.querySelector('[role="dialog"]');
  const nodes = [...d.querySelectorAll('div,span,button,a')].filter(n => (n.textContent || '').trim().startsWith(${JSON.stringify(name)}));
  const hit = nodes[nodes.length - 1];
  if (!hit) return 'not found';
  (hit.closest('[role=button],button,a,div[class*=header],div[class*=name]') || hit).click();
  return 'opened ' + ${JSON.stringify(name)};
})()`;

const PANEL_TEXT = `(() => {
  const d = document.querySelector('[role="dialog"]');
  if (!d) return 'NO DIALOG';
  const wide = [...d.querySelectorAll('div')].filter(n => { const r = n.getBoundingClientRect(); return r.width > 400 && r.height > 200; }).pop();
  const pane = wide || d;
  return JSON.stringify({
    text: pane.innerText.slice(0, 1400),
    checkboxes: [...pane.querySelectorAll('input[type=checkbox]')].map(el => ({
      checked: el.checked,
      row: (el.closest('div') && el.closest('div').innerText || '').trim().slice(0, 70)
    })),
    selects: [...pane.querySelectorAll('select, [role=combobox], [class*=select]')].map(el => ({
      tag: el.tagName, text: (el.innerText || el.textContent || '').trim().slice(0, 80)
    })),
    buttons: [...pane.querySelectorAll('button')].map(el => (el.innerText || '').trim().slice(0, 50)).filter(Boolean)
  });
})()`;

async function shot(cdp, name) {
  const s = await cdp.send('Page.captureScreenshot', { format: 'png' });
  const p = '.saipen/kitchen/t376-' + name + '.png';
  fs.writeFileSync(p, Buffer.from(s.data, 'base64'));
  return p;
}

async function main() {
  const targets = await pageTargets(PORT);
  const cdp = connect(targets[0]);
  await cdp.ready;
  await cdp.send('Runtime.enable');
  await cdp.send('Page.enable');

  console.log('toggles: ' + await ev(cdp, FOUR_TOGGLES));
  console.log('open: ' + await ev(cdp, OPEN_PLUGIN('HideEmbeds')));
  await new Promise((r) => setTimeout(r, 2000));
  console.log('panel: ' + await ev(cdp, PANEL_TEXT));
  console.log('shot: ' + await shot(cdp, 'hideembeds-settings'));

  cdp.close();
}

main().catch((e) => { console.error('FAILED: ' + (e && e.message ? e.message : String(e))); process.exit(2); });