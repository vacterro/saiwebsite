"""T-238: archive the WHOLE stray saitranslate tree before retiring it.

The first pass archived only the files unique by NAME and refused on the rest,
which was the right call and changed the shape of the job: 60 of the 98
same-named files DIFFER between the two kitchens. They are two divergent
generations of the same translations, not a superset and a subset, so deleting
either copy destroys bytes the other does not hold. The published repo is ahead
of both (19 table rows and the T-311 marker in 29 of 32 desktop READMEs, against
14 in one kitchen and 15 in the other).

So the conservative default is: archive the entire divergent tree verbatim,
with a per-file digest manifest AND an explicit list of the files that differ
from the surviving canonical copy -- that list is the whole reason this archive
exists, and it is what a future producer round needs in order to know a second
generation once existed and what it said. No automatic merge is attempted: two
divergent translations of the same sentence cannot be reconciled mechanically,
and pretending otherwise is how a merge loses meaning.

Then the tree is removed with `git rm -r`, so the removal is itself recorded and
`git checkout HEAD -- <path>` restores all 116 files byte for byte.
"""
from __future__ import annotations

import hashlib
import pathlib
import subprocess
import sys

STRAY = pathlib.Path(".saipen/extensions/subs/saitranslate")
CANON = pathlib.Path(".saipen/saitranslate")
ARCHIVE = pathlib.Path(".saipen/recovery/saitranslate-stray-20260929")


def sha(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def main() -> int:
    if not STRAY.is_dir():
        print("stray tree already absent: %s" % STRAY)
        return 0
    files = sorted(p.relative_to(STRAY).as_posix() for p in STRAY.rglob("*") if p.is_file())

    tracked = {
        l for l in subprocess.run(
            ["git", "ls-files", "--", ".saipen/extensions/subs/saitranslate"],
            capture_output=True, check=True, text=True, encoding="utf-8").stdout.splitlines()
        if l
    }
    untracked = [r for r in files if (STRAY / r).as_posix() not in tracked]
    if untracked:
        print("REFUSED: %d file(s) are not tracked, so git cannot restore them: %s"
              % (len(untracked), untracked[:5]))
        return 1
    for rel in files:
        proc = subprocess.run(["git", "cat-file", "-e", "HEAD:" + (STRAY / rel).as_posix()],
                              capture_output=True, text=True)
        if proc.returncode != 0:
            print("REFUSED: no blob at HEAD for %s" % rel)
            return 1

    full = ARCHIVE / "full-tree"
    rows, diverging, unique = [], [], []
    for rel in files:
        raw = (STRAY / rel).read_bytes()
        dst = full / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        dst.write_bytes(raw)
        twin = CANON / rel
        if not twin.is_file():
            state, diverging = "UNIQUE", diverging
            unique.append(rel)
        elif sha(twin.read_bytes()) == sha(raw):
            state = "identical"
        else:
            state = "DIFFERS"
            diverging.append(rel)
        rows.append((rel, len(raw), sha(raw), state))

    lines = [
        "# T-238 archive -- the retired .saipen/extensions/subs/saitranslate/ tree",
        "",
        "## Why this tree was retired",
        "",
        "`.saipen/extensions/subs/MANIFEST.md` registers exactly five roles",
        "(saiwiki, saihunt, saitest, saiui, saipython). `saitranslate` is not among",
        "them, so no engine path reads, collects, syncs or manages this tree: the",
        "role's own namespace is `.saipen/saitranslate/`, named by",
        "`producer.py::_resolve_namespace_ownership`, `crew.py::_role_paths_for` and",
        "the role charter alike. The charter names this exact shape -- a generic",
        "spawn leaving a second live instance that crew never reads and collect can",
        "never see -- and directs that it be retired on sight.",
        "",
        "## Why it is ARCHIVED rather than merged or dropped",
        "",
        "It is not a subset or a superset of the canonical kitchen. Of the %d files"
        % len(files),
        "here, %d are unique and %d share a name with a canonical file of DIFFERENT"
        % (len(unique), len(diverging)),
        "bytes -- two divergent generations of the same translations. Deleting either",
        "copy destroys bytes the other does not hold, so the whole tree is kept here",
        "verbatim. No merge was attempted: two divergent translations of one",
        "sentence cannot be reconciled mechanically, and a merge that picks one",
        "silently loses the other's meaning.",
        "",
        "The published repo is ahead of BOTH kitchens (19 table rows and the T-311",
        "marker in 29 of 32 desktop READMEs, against 14 rows in the canonical copy",
        "and 15 in this one), so the retirement loses no published content.",
        "",
        "## Recovery",
        "",
        "1. The 18 files unique by name are also archived under `files/`.",
        "2. Every one of the %d files here is tracked at HEAD with a blob present, so" % len(files),
        "   `git checkout HEAD -- .saipen/extensions/subs/saitranslate/` restores all",
        "   of them byte for byte.",
        "",
        "## Files that DIFFER from the surviving canonical kitchen",
        "",
        "| file | bytes | sha256 | vs canonical |",
        "|---|---|---|---|",
    ]
    for rel, size, digest, state in rows:
        if state == "DIFFERS":
            lines.append("| `%s` | %d | `%s` | DIFFERS |" % (rel, size, digest))
    lines += [
        "",
        "## Files unique to this tree",
        "",
        "| file | bytes | sha256 |",
        "|---|---|---|",
    ]
    for rel, size, digest, state in rows:
        if state == "UNIQUE":
            lines.append("| `%s` | %d | `%s` |" % (rel, size, digest))
    lines += [
        "",
        "## Every file in the archived tree",
        "",
        "| file | bytes | sha256 | vs canonical |",
        "|---|---|---|---|",
    ]
    for rel, size, digest, state in rows:
        lines.append("| `%s` | %d | `%s` | %s |" % (rel, size, digest, state))
    lines.append("")
    (ARCHIVE / "MANIFEST.md").write_text("\n".join(lines), encoding="utf-8", newline="\n")

    print("archived %d files" % len(rows))
    print("  unique to this tree : %d" % len(unique))
    print("  differ from canonical: %d" % len(diverging))
    print("  byte-identical      : %d" % (len(rows) - len(unique) - len(diverging)))
    print("manifest: %s" % (ARCHIVE / "MANIFEST.md"))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
