# T-371 / T-372 — BetterDiscord four-plugin media repair: DELIVERABLE evidence

Date: 2026-10-04. Tree: working tree at `44f6b33` plus this pass's uncommitted
work. Every number below is from a run against that exact checkout. No number is
carried over from an earlier run.

---

## 0. Headline

The repair is complete and every BetterDiscord gate is green. The one thing the
operator still owes is a signed-in Discord acceptance pass; that debt is recorded
on the ticket as `LIVE_ACCEPTANCE_PENDING_OPERATOR` and is not closed here.

| Suite | Result |
|---|---|
| `test-bd-false-positives` | 54 pass, 0 fail |
| `test-bd-coexistence` | 57 pass, 0 fail |
| `test-hide-embeds` | 61 pass, 0 fail |
| `test-remove-stickers` | 26 pass, 0 fail |
| `test-remove-gifs` | 30 pass, 0 fail |
| `test-goodemoji` | 33 pass, 0 fail |
| `test-goodemoji-matchsrc` | 20 pass, 0 fail |
| `test-bd-media-contract` (new) | 817 pass, 0 fail, exit 0 |
| `test-betterdiscord-plugin-installer.ps1` | 40 pass, 0 fail |
| **Full `tests/Run-Tests.ps1`** | **279 pass, 2 fail** — both unrelated, see §9 |

---

## 1. The new gate, and why a green run means something

`tools/test-bd-media-contract.js` drives the four real plugin sources in a real
Chromium through Playwright. It carries **eight red controls**. Each rebuilds the
pre-repair source with a single anchored string replacement, asserts the
replacement differs from and is present in the shipped bytes, then requires that
section's own assertions to **go red** against it.

A gate that cannot fail is not a gate, so the harness exits 0 only after proving
each defect still exists in mutated form. All eight are red:

| Oracle | Defect reproduced | Red-control assertions fired |
|---|---|---|
| `badKey` | P0-1 checkbox bound to `hideRich` | 9 |
| `noTextVeto` | P0-2 typed hyperlink classified as a card | 5 |
| `presenceScoped` | HideEmbeds skipped on a sibling's row stamp | 3 |
| `noVisual` | P0-3 no `data-w95-visual` state | 10 |
| `noReconcile` | P1-6 no bar reconcile after reveal/conceal | 2 |
| `withBars` | P1-7 session actions treat message bars as media | 2 |
| `polled` | P1-4 1 Hz route poll | 2 |
| `collapseAnyway` | P1-5 foreign-owner guard removed | 50 |

Two of these were not in the handoff and were found while building the gate:
`presenceScoped` (below) and the owner-id lookup defect in §5.

## 2. P0-1 — the rich-cards checkbox was wired to a key that does not exist

`getSettingsPanel()` built `check('hideRich', s.sHideRich)` while the runtime
reads `hideRichCards`. Toggling the control wrote `settings.hideRich`; no rich
card was ever hidden.

**Gate.** The checkbox is located by its label text
(`Hide rich link preview cards`), driven through a real DOM `change` event, and
never by index or by calling `setSetting()`. The gate then asserts
`settings.hideRichCards === true`, asserts the fixture card block actually
changes, simulates a plugin restart, and asserts the setting and the hidden card
both survive. It also asserts no bogus `hideRich` key was ever written.

The red control re-binds the control to `hideRich` and produces 9 red assertions,
including *no bogus hideRich key was written*.

## 3. P0-2 — an ordinary hyperlink was classified as a rich card

The old test was "an external link plus some text", which every message
containing a URL satisfies. `cardBlock()` now vetoes anything inside
`[id^="message-content-"]` and identifies cards positively (provider footer +
embed body + title, generated beside the text).

**Gate.** A typed link (`read https://example.com/article`) and a link-only
message must stay visible with rich cards ON; a real card must be hidden; the
provider footer must not produce a second placeholder. The negative control
asserts on `#typed-1` specifically, because measuring the wrapping `<li>` would
pass even while the link itself was hidden.

## 4. Defect found here, not in the handoff — the shared row-stamp collision

All three plugins stamp the **same attribute name** (`data-w95-scoped`) with
their own owner value. `row.hasAttribute(ATTR_SCOPED)` therefore read a
`RemoveStickers` or `RemoveGIFS` mark as *"HideEmbeds already handled this row"*
and returned before classifying anything. With all four plugins installed, a
correct checkbox hid nothing.

This is why the first build of the rich-card gate failed green-path: the card
really was being hidden by nothing.

**Repair.** Each plugin compares the attribute **value** to its own owner token.
`presenceScoped` reverts HideEmbeds to `hasAttribute()` and goes red on three
assertions.

Also fixed in the same pass: both removers' `const VERSION` still read `1.1.1`
while their headers read `1.1.1`, and the panel title drives off the constant —
the panel could report a build that did not exist.

## 5. P1-4 / P1-5 / P1-6 / P1-7 — removers, row collapse, bar, session

- **P1-4.** Neither remover runs a `setInterval`. Both use the low-idle
  architecture: one observer that finds the list and notices route changes, with
  no idle-page work and no independent full-body observer. The gate counts
  message-list queries across an idle window and also asserts the shipped bytes
  contain no `setInterval`. The red control injects the 1 Hz poll and both
  assertions go red.
- **P1-5.** A row collapses only when *all* hidden meaningful media in it belongs
  to that same plugin. The matrix runs **6 row shapes x 2 start orders x 6 stop
  permutations**. Sole-owner rows must still collapse **by their own owner** under
  the guard mutation — without that, "stop collapsing rows" would pass the same
  assertions as "stop stealing rows".
- **P1-6.** `reveal()` and `conceal()` both re-run the row reconciliation. The
  bar no longer keeps a stale *Show all* over two already-revealed images, and no
  second bar is created.
- **P1-7.** Session reveal/hide excludes `[data-w95-scope="message"]`. A message
  bar is a control, not a media placeholder. The fixture puts the attachment
  anchors as **direct children** of the row, because `mediaFor()`'s backward walk
  dead-ends on a wrapper and the defect hides.

**A defect in the gate itself, found and fixed here.** The restore assertions
looked up `[data-w95-owner="RemoveGIFS"]`, but the DOM stamps the *short* owner
id (`sticker` / `gif` / `embed`). The lookup found nothing and every
"its own media is visible again" check short-circuited to `true` — a green that
proved nothing. Corrected, and the affected assertions now genuinely bite.

A second gate defect: the P1-5 red control never fired under the live start
order, because the remover evaluated the row *before* its siblings hid anything
and returned early — the guard was unreachable. Adding the reverse start order
(`HideEmbeds, RemoveGIFS, RemoveStickers`) is what makes removing the guard
change the outcome, and what makes the control real.

## 6. P0-3 / P2-8 / P2-9 / P2-10

- **P0-3.** Blurred preview is inert in the old build: the CSS used a
  previous-sibling combinator, but `insertStrip()` inserts the strip *after* the
  media, so the rule never matched. The visual state is now an explicit
  `data-w95-visual="blurred"` attribute on the marked block, proven through
  computed style (`display`, `filter`, `opacity`) and `getBoundingClientRect()`,
  and independently readable from the DOM.
- **P2-8.** The legacy loose classifier is behind an Advanced two-step
  arm-and-confirm switch with an explicit warning; an imported or persisted
  `strict: false` is normalised through that same confirmation, so a stale value
  cannot silently re-enable the catch-all.
- **P2-9.** The CHANGELOG names **1.0.0** as the version that introduced the
  screenshot regression and **1.1.0** as the version that fixes it. It does not
  make the fixed version look like the regressing one.
- **P2-10.** Playwright is a pinned dev dependency (`^1.62.1`) in `package.json`
  with one documented bootstrap command (`npm ci`). `node_modules/` is
  git-ignored and never shipped; an end user installing Wintage never needs Node.

## 7. Preserved, not regressed

The handoff's already-repaired v1.0 false-positive class is intact and still
gated by `test-bd-false-positives` (54/0) and `test-bd-coexistence` (57/0):
positive identification, the role-icons veto, the Twemoji veto, GoodEmoji
ownership, foreign-ownership deferral, block-level media root, and no
fabricated `img.src` for *Open original*. No ChatGPT repair was made in this
pass.

## 8. One failure this pass caused, and its fix

`test-betterdiscord-plugin-installer.ps1` failed on
`English BdHideEmbedsDesc names the plugin version (v1.1.2)` and
`every locale description names the shipped version`. Cause: all 33 locale
files asserted `HideEmbeds v1.1.0` (and `RemoveStickers v1.0.0`,
`RemoveGIFS v1.0.0`) while the plugin headers had moved on. The installer gate
reads the version from the header, so the drift was always going to fail.

**Fixed:** all 33 locales synced to the shipped headers. Gate re-run:
**40 pass, 0 fail**. This was a real product-side defect caught by the suite,
not a test to be relaxed.

## 9. Full repository suite — classified

`tests/Run-Tests.ps1` → **279 pass, 2 fail**. Both failures are outside this
work, and neither file reads a BetterDiscord plugin.

**PRODUCT FAILURE: none.** Every BetterDiscord gate is green.

**TEST-ENVIRONMENT BLOCK: none attributable to this pass.**

**UNRELATED T-359 / T-365 LIVE ACCEPTANCE (pre-existing, not caused here):**

1. `test-inspect-web-mutations.js` — 4 red-control assertions red on the R6/R12
   cascade-attribution clause (`the probe builds an ownership map when
   attribution is requested`, `the report states whether the cascade was
   actually attributed`, and the two derived controls). This is the inspect-web /
   ChatGPT attribution lineage, working-tree delta present before this pass.
2. `test-inspect-web-cdp-live.js` — one assertion red:
   `fixture sets each surface background to its own token, so nothing may
   mismatch`, reporting `['prompt-editor']` against an expected `[]`. This suite
   drives a real browser over real CDP against chatgpt.com. It is the live
   acceptance gate for T-359, which is already parked
   `LIVE_ACCEPTANCE_PENDING_OPERATOR`.

Neither failure was counted as a full-suite product failure of this repair.

## 10. Ticket disposition

- **T-371** — `LIVE_ACCEPTANCE_PENDING_OPERATOR`. The repair and every wired gate
  are green (evidence **E-2659**). What remains is operator-only: load the four
  plugins into a signed-in Discord + BetterDiscord, toggle *Hide rich link
  preview cards*, blurred preview and session reveal from the real settings
  panel, and confirm a sticker+GIF row never collapses. Nothing else is owed by
  an agent.
- **T-372** — `ABSORBED_BY_T-371`, explicitly **not** marked DONE. It is the same
  lineage (SRC-059 is the media-collision clause of the SRC-058 repair); its whole
  clause set shipped inside the T-371 repair and is gated by
  `test-bd-media-contract.js`. It is blocked rather than open so a future run
  cannot pick it up as duplicate active work.

  It is blocked rather than superseded for a mechanical reason worth recording:
  the engine only lets a **DONE** ticket settle another, and T-371 cannot be DONE
  while live acceptance is still owed. Marking both DONE for the same evidence
  was explicitly ruled out.

- STATE is `phase: DONE`, no claimed ticket, no workable ticket. The DOING seat is
  released; the live acceptance debt stays visible on the board.

## 11. Acceptance items

| # | Item | Status |
|---|---|---|
| 1 | Rich-card checkbox drives `hideRichCards` through the real panel | PASS |
| 2 | Rich card positively identified; typed link and UNKNOWN never qualify | PASS |
| 3 | Blurred preview is an explicit, independently testable DOM state | PASS |
| 4 | Neither remover runs a route poll; no extra full-body observer | PASS |
| 5 | Row collapse requires sole ownership; full stop-order matrix green | PASS |
| 6 | `reveal()`/`conceal()` reconcile the bar; no duplicate bars | PASS |
| 7 | Session actions exclude message-level bars | PASS |
| 8 | Legacy loose classifier behind armed Advanced confirmation | PASS |
| 9 | CHANGELOG names 1.0.0 as the regressing version | PASS |
| 10 | Playwright pinned, one bootstrap command, no shipped `node_modules` | PASS |
| 11 | Every new gate proven to go red on a known-bad input | PASS (8/8) |
| 17 | Live signed-in Discord acceptance | **LIVE_ACCEPTANCE_PENDING_OPERATOR** |

No ChatGPT repair was made in this pass.