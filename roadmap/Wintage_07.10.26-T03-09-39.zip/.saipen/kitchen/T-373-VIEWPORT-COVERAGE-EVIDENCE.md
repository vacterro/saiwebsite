# T-373 — ChatGPT viewport-owner coverage: DELIVERABLE evidence

Ticket: **T-373** (ChatGPT viewport owner coverage repair)
Disposition: **LIVE_ACCEPTANCE_PENDING_OPERATOR** — see §7.
Date: 2026-10-04

---

## 1. The defect, stated as the cascade actually is

The October block in `CHATGPT_FAST_CSS` themed four elements:

```
#web-mobile-root
[data-testid="desktop-app-shell"]
main[aria-label="ChatGPT"]
[role="region"][aria-label="Conversation"]
```

The current shell paints `[data-testid="mobile-app-shell-scroll-container]`
with **its own opaque background**, and that element is a **child of all four**.
So every themed ancestor was correct and irrelevant: the element covering the
middle of the screen painted over them.

This is the failure mode the handoff named, and it is the reason string-presence
gates cannot see it:

> PARENT THEMED / CHILD VIEWPORT OWNER OPAQUE STOCK => visible page still wrong.

`test-chatgpt-2026.js` and `test-chatgpt-perf-css.js` read RULES. They assert the
October contracts are selectors on live rules in the sheet ChatGPT actually
receives. All four were. Both gates were green. The page was still stock.

## 2. Product change (`wintage.user.js`, `CHATGPT_FAST_CSS` only)

```
html[data-w95-chatgpt="1"] [data-testid="mobile-app-shell-scroll-container"] {
  background-color: ${T.backgroundSoft} !important;
  color: ${T.textPrimary} !important;
}
```

The parent rules are **kept** — they remain the fallback for rollouts with no
scroll container. `GLOBAL_CSS` is **not** touched; the handoff forbids restoring
it on ChatGPT and `ACTIVE_GLOBAL_CSS` still routes ChatGPT to the fast sheet.

### Header / footer fades

```
main[aria-label="ChatGPT"] [data-testid="desktop-app-shell"] > header,
main[aria-label="ChatGPT"] [data-testid="desktop-app-shell"] > footer,
[data-testid="mobile-app-shell-scroll-container"] > header,
[data-testid="mobile-app-shell-scroll-container"] > footer,
#page-header {
  background-image: none !important;
  background-color: ${T.backgroundSoft} !important;
  color: ${T.textPrimary} !important;
}
```

Two deliberate decisions, both evidence-driven rather than taste:

**A gradient was not used.** UI.md law 2 is *"zero rounded corners, zero shadow,
zero gradients, zero blur…"*, and `wintage.user.js:3100` already strips gradient
`background-image`s on any repaint. Painting a gradient here would have bought a
themed header until the next repaint, then reverted. Solid colour plus
`background-image: none` is both the law and the cheap path.

**The direct-child combinator is the whole scoping argument.** A message embed's
header or footer is nested inside the conversation region, several levels below
either shell, so it can never be a direct child and cannot match. That satisfies
*"do not affect headers/footers inside message embeds"* without `:has()`, without
a class fragment, and without a universal selector — all three of which the
existing gates ban on ChatGPT.

**Declared limit, not a defect.** If a rollout nests the fade one wrapper
deeper, this rule misses it and it shows stock. The trade is deliberate: miss
narrowly rather than over-reach onto embed internals.

## 3. New gate: `tools/test-chatgpt-viewport-coverage.js`

Real Chromium, real cascade. The Golden Default palette is parsed out of the
theme table (so it cannot drift), every `${T.*}` is resolved to its real value,
and the sheet is injected **after** a stock sheet that reproduces the shell with
an opaque `#000000` scroll container.

The measurement walks up from a point in the viewport to the first element that
actually paints something opaque — that is "what the user sees", not "is the rule
present". An owner that paints a `background-image` counts as **not** themed,
because a gradient owner is still a stock-coloured owner.

**Result: 33 pass / 0 fail, exit 0.**

| viewport state | assertions |
|---|---|
| A empty new-chat | defect reproduced, owner themed, visible = backgroundSoft, no stock, parents live |
| B populated conversation | same five |
| C composer focused | same five |
| D sidebar expanded | same five |
| E band below a short conversation region | four (no defect-reproduction assertion — see below) |
| header fade | stock gradient reproduced, then stripped and repainted |
| embed containment | embed header/footer computed colours **identical** themed vs unthemed |

Each of A–D asserts the **stock** build is wrong before asserting the themed
build is right. State E deliberately skips that: at a 60%-height conversation
region the stock scroll container is not the visible owner, so asserting the
defect there would be false. State E exists to prove the parent rules are
non-load-bearing.

### Four red controls, each proven able to fail

| control | cut | asserted to go red |
|---|---|---|
| RC1 | ONLY the scroll-container rule | visible viewport returns stock black **while all four parent contracts survive** |
| RC2 | ONLY the header/footer fade scope | page header keeps the stock gradient |
| RC3 | `${T.backgroundSoft}` → `inherit` | nothing painted in the palette |
| RC4 | the whole Wintage sheet | every viewport stock |
| RC5 | a backtick inside `CHATGPT_FAST_CSS` | the parse assertion bites |

Every control verifies **its own cut removed what it claimed and left standing
what it claimed to keep**, before it is allowed to run. RC1 is the control the
whole gate exists for. RC2's first anchoring attempt matched `main[aria-label="ChatGPT"]`,
which also appears in the parent block — it was cutting the contracts it was
supposed to preserve, and would have gone red for the wrong reason.

## 4. Two gate defects found and fixed while building this

### 4a. `test-inspect-web-mutations.js` was running 8 of 34 controls as no-ops

`tools/inspect-web.js` checks out with CRLF on Windows. Eight `MUTATIONS` anchors
are multi-line strings written with `\n`, so `original.includes(from)` could never
match them. Each printed `FAIL: mutation anchor not found`, incremented a
counter, and the run still exited 0.

A harness skipping a control is not the control biting. The source is now
normalised to LF before any anchor is matched.

**Before: 27 pass / 8 anchor-not-found, exit 1. After: 35 pass / 0, exit 0, and
all 34 controls go red.** Verified directly: normalising the source to LF takes
the missing count from 8 to 0.

### 4b. Nothing in the ChatGPT gate chain could see a broken userscript

While editing the new CSS I wrote a backtick around `` `opaque` `` inside a
comment inside the `CHATGPT_FAST_CSS` template literal. That closed the string
early. `wintage.user.js` stopped being valid JavaScript — and **all three ChatGPT
gates stayed green**, because they extract the literal as *text* and the regex
that finds the closing delimiter walks straight past a backtick that is not
preceded by a newline.

This is the same vacuity class as §1, living in the test layer. The new gate now
does a real `new Function(SRC)` parse, with RC5 proving the assertion can fail.
The backtick is removed; the file parses (236,439 chars).

## 5. `tools/inspect-web.js`

- **`app-scroll-container`** surface, `CONTRACT.ALWAYS`, bound to
  `--chat-background-color` — the viewport owner is now a first-class matrix row.
- **Per-surface ownership**: bounding rect, viewport coverage ratio, computed
  `background-color` / `background-image`, and the nearest opaque ancestor
  (40 hops).
- **`opaque` command**: lists every opaque node covering ≥ `WINTAGE_OPAQUE_MIN`
  (default 10%) of the viewport and exits non-zero when any remain. That is the
  acceptance condition — *"a large opaque #000000 / rgb(0,0,0) / stock charcoal in
  the central empty/new-chat viewport"* — measured instead of asserted.
- **Attribution honesty**: colour is credited to Wintage only when Wintage is
  actually live (`stamp` + sheets + host attribute). With attribution off the
  report says so and credits nothing. Without that gate the first run reported 1
  stock node when 4 existed, because with Wintage off the semantic tokens resolve
  to ChatGPT's own values and stock black matched.
- **Privacy**: structural identity only — tag, element id, `data-testid`, `role`.
  No `textContent`, no `aria-label`, no `href`, no `src`, no titles, no
  conversation content. The opaque expression is 4,928 bytes and contains none of
  those tokens.

## 6. Gate results

| gate | result |
|---|---|
| `test-chatgpt-2026.js` | **9 / 0**, exit 0 |
| `test-chatgpt-perf-css.js` | **27 / 0**, exit 0 |
| `test-chatgpt-viewport-coverage.js` | **33 / 0**, exit 0 |
| `test-inspect-web.js` | **90 / 0**, exit 0 |
| `test-inspect-web-mutations.js` | **35 / 0**, exit 0, **34/34 controls red** |
| `test-cdp-client.js` | **25 / 0**, exit 0 |
| `tests/Run-Tests.ps1` (full) | **281 pass / 1 fail** — see below |

`test-chatgpt-viewport-coverage.js` is registered in `tests/Run-Tests.ps1`
immediately after the two existing ChatGPT gates and ran green inside the full
run (E-…).

### The one full-suite failure, and why it is not this ticket's

`test-inspect-web-cdp-live.js` fails on `mismatchedEver = ["prompt-editor"]`.
This is **pre-existing** — identical signature to the failure recorded before
this ticket began (T-359 / T-365 lineage), and unchanged by this work.

Instrumented, before this ticket's fixture fix:

```
MISMATCHED_EVER = ["prompt-editor"]
MISSING_EVER    = ["root-app","app-scroll-container","sidebar","prompt-editor","settings-page"]
```

`app-scroll-container` was in the missing list because the fixture did not render
it — an `ALWAYS` contract the matrix declares and the fixture contradicted, which
is a fixture bug wearing a product regression's clothes. The fixture now renders
the scroll container:

```
MISMATCHED_EVER = ["prompt-editor"]          <- unchanged, pre-existing
MISSING_EVER    = ["settings-page"]          <- restored to the pre-ticket baseline
```

`prompt-editor` was left alone on purpose: it is a live-CDP finding that belongs
to T-359's investigation, and quietly patching the fixture that produces it would
launder an open ticket into a green suite.

## 7. Live acceptance — OWED, NOT PERFORMED

**This ticket is not DONE. It is `LIVE_ACCEPTANCE_PENDING_OPERATOR`.**

What I could not obtain, and why it matters:

- **No open chatgpt.com tab exposes the October shell.** Two tabs are open. One
  is the older `#_r_mt_…` generation; the other is the light-mode new-chat page
  (`rgb(252,252,252)` / `rgb(255,255,255)`, root `#_R_trcuktdbntccged79l75_`).
  Neither exposes `[data-testid="mobile-app-shell-scroll-container"]`.
- **Wintage is not injected on either tab** (`stamp=false sheets=0`). With
  attribution off, the opaque audit correctly refused to credit any colour to
  Wintage and reported **3 of 3** opaque nodes as NOT a Wintage palette colour.

**The header/footer fade rule is therefore scoped from the handoff's recorded
structure, not from a live confirmation of this account's shell.** It is honest
CSS and it is narrowly scoped, but whether the fade is still a *direct child* of
the scroll container on the live page is the one claim in this ticket that no
green gate here proves.

**T-359 is NOT closed by this landing.** The tool half is proven; the product
half still needs a signed-in tab.

### Operator steps, on an operator-owned signed-in tab

1. Install the userscript, confirm the stamp: `document.documentElement.getAttribute('data-w95-chatgpt')` returns `"1"`, and `inspect-web.js targets` shows Wintage's sheets injected.
2. Open the current shell (the one exposing `[data-testid="mobile-app-shell-scroll-container"]`) on the **empty / new-chat** viewport.
3. Run `node tools/inspect-web.js opaque chatgpt.com`. **Expect zero opaque nodes above threshold**, and every colour attributed as a Wintage palette colour. Golden Default: `backgroundSoft #232018`, `background #1A1810`, `surface #332E22`, `surfaceRaised #3D372A`.
4. Repeat across all eight acceptance surfaces (sidebar, conversation, composer, prompt editor, code block, user bubble, header, footer).
5. If the fade is visibly stock, run `node tools/inspect-web.js rules chatgpt.com '#page-header'` and paste the matched-rule list. **That is the evidence that would let the fade scope be widened** — and it is the only thing that would justify it.

**Acceptance fails if the central empty/new-chat viewport still contains a large
opaque `#000000`, `rgb(0,0,0)`, or stock charcoal.**
