"""T-238: what exactly diverges between the two saitranslate kitchens?

The two trees are not a superset/subset pair -- 60 of the 98 same-named files
differ. So neither can simply be deleted. This maps the divergence per surface
so the merge rule can be decided from evidence instead of from the newer
mtime or the larger directory.
"""
import hashlib
import pathlib
import re

STRAY = pathlib.Path(".saipen/extensions/saitranslate")
CANON = pathlib.Path(".saipen/saitranslate")
REPO = pathlib.Path(".")

SURFACES = [
    ("root README", "", pathlib.Path(".")),
    ("desktop README", "desktop", pathlib.Path("desktop")),
    ("browser-theme README", "browser-theme", pathlib.Path("browser-theme")),
    ("locale JSON", "locales", pathlib.Path("desktop/locales")),
]

MARK = re.compile(r"T-311")


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()[:12]


def rows_of(p):
    return len([l for l in p.read_text(encoding="utf-8", errors="replace").split("\n")
                if l.startswith("|")])


def digest_of(p):
    m = MARK.search(p.read_text(encoding="utf-8", errors="replace"))
    return m.group(0) if m else "-"


print("The three places each translated surface exists:\n")
print("%-20s %-26s %-26s %-26s" % ("surface", "stray kitchen", "canonical kitchen", "repo (published)"))
for label, sub, repo in SURFACES:
    s_dir, c_dir = STRAY / "kitchen" / sub, CANON / "kitchen" / sub
    s_files = sorted(p.name for p in s_dir.glob("*") if p.is_file()) if s_dir.is_dir() else []
    c_files = sorted(p.name for p in c_dir.glob("*") if p.is_file()) if c_dir.is_dir() else []
    r_files = sorted(p.name for p in repo.glob("*") if p.is_file()) if repo.is_dir() else []
    print("%-20s %-26s %-26s %-26s" % (label, "%d files" % len(s_files), "%d files" % len(c_files), "%d files" % len(r_files)))

print()
print("Per-file: which copy is the T-311-refreshed one (carries the marker)?")
for label, sub, repo in SURFACES:
    s_dir, c_dir = STRAY / "kitchen" / sub, CANON / "kitchen" / sub
    if not s_dir.is_dir() or not c_dir.is_dir():
        continue
    s_mark = sum(1 for p in s_dir.glob("*") if p.is_file() and MARK.search(p.read_text(encoding="utf-8", errors="replace")))
    c_mark = sum(1 for p in c_dir.glob("*") if p.is_file() and MARK.search(p.read_text(encoding="utf-8", errors="replace")))
    r_mark = 0
    if repo.is_dir():
        r_mark = sum(1 for p in repo.glob("*") if p.is_file() and MARK.search(p.read_text(encoding="utf-8", errors="replace")))
    print("  %-20s stray=%-3d canonical=%-3d repo=%-3d" % (label, s_mark, c_mark, r_mark))

print()
print("desktop README row counts (English source has 18):")
for label, root in (("stray", STRAY / "kitchen/desktop"), ("canonical", CANON / "kitchen/desktop"), ("repo", pathlib.Path("desktop"))):
    if not root.is_dir():
        continue
    counts = {}
    for p in sorted(root.glob("README.*.md")):
        if p.name == "README.md":
            continue
        counts[rows_of(p)] = counts.get(rows_of(p), 0) + 1
    print("  %-10s %s" % (label, counts))
