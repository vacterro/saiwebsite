"""T-352 deliverable: the per-language translation worklist, computed.

Not a report -- a worklist. Run it and it prints, for every language, exactly
which table rows of `desktop/README.md` that language is missing and which of
its present rows carry text that no longer matches the source's structure. A
translator executes the list; nobody has to diff 32 files by hand, and nobody
has to guess whether a round is needed at all.

Usage:
    python .saipen/kitchen/translation-worklist.py            # every language
    python .saipen/kitchen/translation-worklist.py de es fr   # named languages

What it compares, and why these are the right things to compare:
  * ROW SET, by the first cell's backticked code literals. A target name is a
    code literal (`qbittorrent`, `totalcmd`, `totalcmd2`), so it is the same
    string in every language and can be compared mechanically.
  * SEPARATOR COUNT per table, because a row appended to the wrong table or a
    table split in two is invisible to a row-set comparison.
  * THE `terminal` ROW'S MECHANISM CELL, called out separately, because it is
    the one cell where the source text CHANGED rather than a row appearing or
    disappearing: the source now says "Terminus (TTF) for Windows" where the
    translations still carry the older Consolas wording. Structural comparison
    cannot see that, and it is exactly the kind of change a refresh misses.
"""
from __future__ import annotations

import pathlib
import re
import sys

SRC_README = pathlib.Path("desktop/README.md")
DESKTOP = pathlib.Path("desktop")


def cells(line: str) -> list[str]:
    return [c.strip() for c in line.strip().strip("|").split("|")]


def target_key(line: str) -> str:
    """The first cell's backticked literals, sorted -- language-independent."""
    return "|".join(sorted(re.findall(r"`([^`]+)`", cells(line)[0])))


def data_rows(text: str) -> list[str]:
    out = []
    for line in text.split("\n"):
        if not line.startswith("|"):
            continue
        body = cells(line)
        if set("".join(body).replace(" ", "")) <= set("|-:") and "-" in "".join(body):
            continue  # separator
        if re.fullmatch(r"[^\s|]+", body[0]) and not re.search(r"`", body[0]):
            continue  # header row
        out.append(line)
    return out


def lang_of(path: pathlib.Path) -> str:
    parts = path.name.split(".")
    return parts[1] if len(parts) > 2 else "md"


def main(argv: list[str]) -> int:
    if not SRC_README.is_file():
        print("run from the project root: desktop/README.md not found", file=sys.stderr)
        return 2
    src_text = SRC_README.read_text(encoding="utf-8")
    src = data_rows(src_text)
    src_keys = [target_key(r) for r in src]
    src_terminal = next((r for r in src if target_key(r) == "terminal"), None)
    print("source: desktop/README.md, %d data rows" % len(src))
    print("targets: %s\n" % ", ".join(src_keys))

    wanted = set(argv) or None
    total_missing = 0
    for path in sorted(DESKTOP.glob("README.*.md")):
        if path.name == "README.md":
            continue
        lang = lang_of(path)
        if wanted and lang not in wanted:
            continue
        text = path.read_text(encoding="utf-8")
        rows = data_rows(text)
        keys = [target_key(r) for r in rows]
        missing = [k for k in src_keys if k not in keys]
        extra = [k for k in keys if k not in src_keys]
        terminal = next((r for r in rows if target_key(r) == "terminal"), None)
        terminal_stale = (
            src_terminal is not None
            and terminal is not None
            and cells(terminal)[1] != cells(src_terminal)[1]
        )
        total_missing += len(missing)
        print("  %-4s rows=%-3d missing=%-2d %s%s%s"
              % (lang, len(rows), len(missing),
                 ("[" + ",".join(missing) + "] ") if missing else "",
                 ("EXTRA[" + ",".join(extra) + "] ") if extra else "",
                 "terminal-cell-stale" if terminal_stale else ""))
    print("\nTOTAL missing cells across the languages printed above: %d" % total_missing)
    print("Each missing row is ONE cell to translate: the first cell is the code")
    print("literal above and the third is a yes/no clause; only the mechanism cell")
    print("is language-dependent. A refresh is then re-stamp, not rewrite.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
