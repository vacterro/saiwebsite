'use strict';
// T-376 phase 2, step 6b: compact ancestry of the HideEmbeds row.

const { pageTargets, connect } = require('../../tools/cdp-client.js');

const PORT = Number(process.env.BD_CDP_PORT || 9223);

async function ev(cdp, expression) {
  const r = await cdp.send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: false });
  if (r.exceptionDetails) throw new Error(r.exceptionDetails.exception?.description || r.exceptionDetails.text);
  return r.result.value;
}

const CHAIN = `(() => {
  const d = document.querySelector('[role="dialog"]');
  const leaf = [...d.querySelectorAll('div,span')].find(n => (n.textContent || '').trim() === 'HideEmbeds');
  if (!leaf) return 'no leaf';
  const out = [];
  let n = leaf;
  for (let i = 0; i < 7 && n && n !== d.parentElement; i++) {
    const kids = [...n.children].map(c => c.tagName + '.' + (c.className || '').toString().trim().split(/\\s+/).join('.'));
    out.push(i + ' ' + n.tagName + ' | ' + (n.className || '').toString().slice(0, 120) +
             ' | onclick=' + (typeof n.onclick) +
             ' | kids=[' + kids.slice(0, 12).join(', ') + ']');
    n = n.parentElement;
  }
  return out.join('\\n');
})()`;

const BD_HOOKS = `(() => {
  const bd = globalThis.BdApi;
  return JSON.stringify({
    hasUi: typeof bd.UI,
    uiKeys: bd.UI ? Object.keys(bd.UI) : null,
    domKeys: bd.DOM ? Object.keys(bd.DOM) : null,
    components: bd.Components ? Object.keys(bd.Components).slice(0, 40) : null
  });
})()`;

async function main() {
  const targets = await pageTargets(PORT);
  const cdp = connect(targets[0]);
  await cdp.ready;
  await cdp.send('Runtime.enable');
  console.log(await ev(cdp, CHAIN));
  console.log('---');
  console.log(await ev(cdp, BD_HOOKS));
  cdp.close();
}

main().catch((e) => { console.error('FAILED: ' + (e && e.message ? e.message : String(e))); process.exit(2); });