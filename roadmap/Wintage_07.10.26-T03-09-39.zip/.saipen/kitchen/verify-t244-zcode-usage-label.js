#!/usr/bin/env node
// T-244 re-verification: the ZCode desktop "Usage remaining" popup's 5-hour
// quota label. Executed evidence, not an attestation -- it reads the shipped
// userscript and fails when the rule is gone or has been re-anchored onto
// something that no longer distinguishes the 5-hour column.
//
// The discriminator is load-bearing. The popup has three quota columns and CSS
// cannot match on their text, so the rule anchors on the column's own bar token
// (--color-usage-chart-1; Weekly is chart-2, MCP is chart-5) via a [style*=]
// attribute match. A bare "usage-chart-1" substring would also match
// usage-chart-10..19 if the app ever grows that many tokens, hence the closing
// paren in the anchor -- this check asserts the paren is still there.

const fs = require('fs');
const path = require('path');

const src = fs.readFileSync(path.join(__dirname, '..', '..', 'wintage.user.js'), 'utf8');
const problems = [];

if (!/\[style\*="usage-chart-1\)"\]/.test(src)) {
  problems.push('the [style*="usage-chart-1)"] anchor is gone or lost its closing paren');
}
if (!/has\(> div\[class\*="h-1\.5"\] > div\[style\*="usage-chart-1\)"\]\) > div > div:first-child > span\[class\*="text-foreground-subtle"\]/.test(src)) {
  problems.push('the descendant chain no longer reaches the label span of the chart-1 column');
}
if (!/color-mix\(in srgb, \$\{T\.borderHighlight\} 55%, \$\{T\.dangerText\} 45%\)/.test(src)) {
  problems.push('the light-orange mix is gone; the label must derive from the palette, never a literal');
}
if (!/color-mix\(in srgb, \$\{T\.borderHighlight\} 55%, \$\{T\.dangerText\} 45%\)[^}]*font-weight: 700/.test(src)) {
  problems.push('the label no longer carries the bold weight that makes it distinguishable from the dim rows');
}
// The repainter must spare the chart-token bars, or process() rewrites the very
// token the selector anchors on and the rule stops matching anything.
if (!/--color-usage-chart-/.test(src)) {
  problems.push('the --color-usage-chart- repainter guard is gone; the bars would be recoloured and the anchor invalidated');
}

if (problems.length) {
  for (const p of problems) console.error('T-244 REVERIFY FAIL: ' + p);
  process.exit(1);
}
console.log('T-244 REVERIFY PASS: ZCode 5-hour quota label anchored on usage-chart-1), palette-derived light orange, bold, and the repainter guard intact');
