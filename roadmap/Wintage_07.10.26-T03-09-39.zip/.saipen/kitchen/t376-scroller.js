'use strict';
// T-376: find the REAL scrollable message list (the previous probe latched onto
// a 36px node) and walk up through older history looking for a rich link
// preview card, which #matchmaking's loaded window has none of.
//
// Read-only: scrolling renders already-received messages and marks nothing read.

const { pageTargets, connect } = require('../../tools/cdp-client.js');

const PORT = Number(process.env.BD_CDP_PORT || 9223);

async function ev(c, e) {
  const r = await c.send('Runtime.evaluate', { expression: e, returnByValue: true });
  if (r.exceptionDetails) {
    throw new Error((r.exceptionDetails.exception && r.exceptionDetails.exception.description) || r.exceptionDetails.text);
  }
  return r.result.value;
}

const SCROLLERS = `(() => {
  const out = [];
  for (const n of document.querySelectorAll('div')) {
    if (n.scrollHeight > n.clientHeight + 40 && n.clientHeight > 200 && n.querySelector('[id^=chat-messages]')) {
      const r = n.getBoundingClientRect();
      out.push({ cls: (n.className || '').toString().slice(0, 60), scrollHeight: n.scrollHeight, clientHeight: n.clientHeight, top: Math.round(r.top), h: Math.round(r.height) });
    }
  }
  return JSON.stringify(out.slice(0, 8));
})()`;

const SCROLL_BY = (dy) => `(() => {
  const n = [...document.querySelectorAll('div')].find(x => x.scrollHeight > x.clientHeight + 40 && x.clientHeight > 200 && x.querySelector('[id^=chat-messages]'));
  if (!n) return 'no scroller';
  n.scrollTop -= ${dy};
  return 'scrollTop=' + Math.round(n.scrollTop) + ' of ' + n.scrollHeight;
})()`;

const COUNT = `(() => {
  const rows = document.querySelectorAll('[id^=chat-messages]').length;
  const embeds = document.querySelectorAll('[class*="messageEmbed"], [class*="embedWrapper"], [class*="embedFull"], [class*="embeds"]').length;
  const w95 = [...document.querySelectorAll('[data-w95-embed]')].map(e => e.getAttribute('data-w95-embed'));
  const c = {}; for (const v of w95) c[v] = (c[v] || 0) + 1;
  return JSON.stringify({ rows, embeds, w95embed: c });
})()`;

const wait = (ms) => new Promise((r) => setTimeout(r, ms));

(async () => {
  const t = (await pageTargets(PORT))[0];
  const c = connect(t);
  await c.ready;
  await c.send('Runtime.enable');

  console.log('scrollers: ' + await ev(c, SCROLLERS));
  console.log('baseline: ' + await ev(c, COUNT));

  for (let i = 0; i < 8; i++) {
    const s = await ev(c, SCROLL_BY(700));
    await wait(1800);
    const n = JSON.parse(await ev(c, COUNT));
    console.log('up' + (i + 1) + ': ' + s + '  ' + JSON.stringify(n));
    if (n.embeds > 0) { console.log('FOUND EMBED'); break; }
  }

  c.close();
})().catch((e) => { console.error('FAILED: ' + (e && e.message ? e.message : String(e))); process.exit(2); });