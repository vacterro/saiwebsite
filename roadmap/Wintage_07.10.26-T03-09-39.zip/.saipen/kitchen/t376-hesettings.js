'use strict';
// T-376 phase 2, step 7: open HideEmbeds' real settings pane through the real
// Settings button and inventory the controls it renders.

const { pageTargets, connect } = require('../../tools/cdp-client.js');

const PORT = Number(process.env.BD_CDP_PORT || 9223);

async function ev(cdp, expression) {
  const r = await cdp.send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: false });
  if (r.exceptionDetails) throw new Error(r.exceptionDetails.exception?.description || r.exceptionDetails.text);
  return r.result.value;
}

const OPEN = `(() => {
  const d = document.querySelector('[role="dialog"]');
  const leaf = [...d.querySelectorAll('div,span')].find(n => (n.textContent || '').trim() === 'HideEmbeds');
  const card = leaf && leaf.closest('.bd-addon-card');
  if (!card) return 'no card';
  const btn = [...card.querySelectorAll('button')].find(b => (b.innerText || '').trim() === 'Settings');
  if (!btn) return 'no Settings button';
  btn.click();
  return 'clicked Settings';
})()`;

const PANE = `(() => {
  const d = document.querySelector('[role="dialog"]');
  if (!d) return 'NO DIALOG';
  const wide = [...d.querySelectorAll('div')].filter(n => {
    const r = n.getBoundingClientRect(); return r.width > 400 && r.height > 200;
  }).pop();
  const pane = wide || d;
  const items = [...pane.querySelectorAll('div')].filter(n => {
    const t = (n.innerText || '').trim();
    return t && t.length < 90 && /Hides user-posted|Hide rich|placeholder|Reveal|blur|compact|collapsed|session|media/i.test(t);
  }).map(n => ({ cls: (n.className || '').toString().slice(0, 50), text: (n.innerText || '').trim().slice(0, 80) }));
  const uniq = []; const seen = new Set();
  for (const i of items) { if (!seen.has(i.text)) { seen.add(i.text); uniq.push(i); } }
  return JSON.stringify({
    text: pane.innerText.slice(0, 1200),
    switches: [...pane.querySelectorAll('input[type=checkbox], [role=switch]')].map(el => ({
      checked: el.checked === undefined ? null : el.checked,
      label: (el.getAttribute('aria-label') || '').toString().slice(0, 60),
      row: (el.closest('div[class*=item], div') && el.closest('div[class*=item], div').innerText || '').trim().slice(0, 60)
    })),
    buttons: [...pane.querySelectorAll('button')].map(b => (b.innerText || '').trim()).filter(Boolean).slice(0, 30),
    selects: [...pane.querySelectorAll('select, [role=combobox], [class*=dropdown], [class*=Dropdown]')].map(el => ({
      tag: el.tagName, cls: (el.className || '').toString().slice(0, 40), text: (el.innerText || '').trim().slice(0, 60)
    })),
    matched: uniq.slice(0, 25)
  }, null, 1);
})()`;

async function main() {
  const targets = await pageTargets(PORT);
  const cdp = connect(targets[0]);
  await cdp.ready;
  await cdp.send('Runtime.enable');
  console.log('open: ' + await ev(cdp, OPEN));
  await new Promise((r) => setTimeout(r, 2500));
  console.log(await ev(cdp, PANE));
  cdp.close();
}

main().catch((e) => { console.error('FAILED: ' + (e && e.message ? e.message : String(e))); process.exit(2); });