'use strict';
// T-376 phase 2, step 1: open the REAL BetterDiscord settings panel through
// Discord's own User Settings button and report what is inside it. Every
// interaction here is a real synthesized click on a real control, so what is
// observed afterwards is what a user's own hand would produce.

const { pageTargets, connect } = require('../../tools/cdp-client.js');

const PORT = Number(process.env.BD_CDP_PORT || 9223);

const CLICK_SETTINGS = `(() => {
  const labels = ['user settings', 'settings'];
  const btns = [...document.querySelectorAll('button, [role="button"], nav[aria-label] [role="tab"]')];
  const hit = btns.find(b => {
    const l = ((b.getAttribute('aria-label') || '') + ' ' + (b.className || '')).toLowerCase();
    return labels.some(t => l.includes(t));
  });
  if (!hit) return 'no settings control found';
  hit.click();
  return 'clicked: ' + ((hit.getAttribute('aria-label') || hit.className || '').toString().slice(0, 80));
})()`;

const INVENTORY = `(() => {
  const modal = document.querySelector('[role="dialog"], [aria-modal="true"], .modal-3hJdRH') ||
                document.querySelector('.panels-3x1UlJ, [class*="panels"]');
  const root = modal || document.body;
  const sect = [...root.querySelectorAll('nav[aria-label] [role="tab"], nav a, nav [class*="item"]')]
    .map(n => ((n.textContent || '').trim() + (n.getAttribute('aria-selected') === 'true' ? ' [SEL]' : '')))
    .filter(Boolean).slice(0, 40);
  const w95 = [...document.querySelectorAll('[data-w95-plugin-ui]')].map(n => n.getAttribute('data-w95-plugin-ui'));
  const controls = [...root.querySelectorAll('input, select, [role="switch"], [role="checkbox"]')]
    .slice(0, 40)
    .map(el => ({
      tag: el.tagName,
      type: el.type || null,
      role: el.getAttribute('role') || null,
      checked: el.checked === undefined ? null : el.checked,
      text: (el.getAttribute('aria-label') || el.name || el.id || el.textContent || '').toString().trim().slice(0, 60)
    }));
  return JSON.stringify({
    dialogFound: !!modal,
    sections: sect,
    w95Panels: w95,
    controlCount: controls.length,
    controls
  });
})()`;

async function ev(cdp, expression) {
  const r = await cdp.send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: false });
  if (r.exceptionDetails) throw new Error(r.exceptionDetails.exception?.description || r.exceptionDetails.text);
  return r.result.value;
}

async function main() {
  const targets = await pageTargets(PORT);
  const cdp = connect(targets[0]);
  await cdp.ready;
  await cdp.send('Runtime.enable');

  console.log('open: ' + await ev(cdp, CLICK_SETTINGS));
  await new Promise((r) => setTimeout(r, 2500));
  console.log(JSON.stringify(JSON.parse(await ev(cdp, INVENTORY)), null, 2));

  cdp.close();
}

main().catch((e) => { console.error('FAILED: ' + (e && e.message ? e.message : String(e))); process.exit(2); });