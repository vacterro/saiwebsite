"""T-238: archive the files unique to the stray saitranslate tree, with a
per-file digest manifest, BEFORE the tree is removed.

Recovery has two independent proofs here and both are checked:

  1. ARCHIVE -- the 19 files that exist nowhere else are copied here with a
     sha256 manifest, so their exact bytes survive even if the git proof below
     is somehow unavailable.
  2. GIT -- all 116 files in the tree are tracked at HEAD, so
     `git checkout HEAD -- <path>` restores every one byte for byte. This
     script verifies that claim rather than asserting it: for every file it
     asks git for the blob at HEAD and refuses to finish if any is missing.

Writes nothing outside the archive directory. Removes nothing -- deletion is a
separate, deliberate step after this one has been read back.
"""
from __future__ import annotations

import hashlib
import pathlib
import subprocess
import sys

STRAY = pathlib.Path(".saipen/extensions/subs/saitranslate")
CANON = pathlib.Path(".saipen/saitranslate")
ARCHIVE = pathlib.Path(".saipen/recovery/saitranslate-stray-20260929")


def tracked_set() -> set[str]:
    out = subprocess.run(
        ["git", "ls-files", "--", ".saipen/extensions/subs/saitranslate"],
        capture_output=True, check=True, text=True, encoding="utf-8",
    )
    return {l for l in out.stdout.splitlines() if l}


def blob_at_head(path: str) -> str | None:
    proc = subprocess.run(
        ["git", "cat-file", "-e", "HEAD:" + path], capture_output=True, text=True
    )
    return path if proc.returncode == 0 else None


def main() -> int:
    if not STRAY.is_dir():
        print("stray tree already absent: %s" % STRAY)
        return 0
    stray_files = sorted(
        p.relative_to(STRAY).as_posix() for p in STRAY.rglob("*") if p.is_file()
    )
    canon_files = (
        {p.relative_to(CANON).as_posix() for p in CANON.rglob("*") if p.is_file()}
        if CANON.is_dir()
        else set()
    )
    unique = [rel for rel in stray_files if rel not in canon_files]
    shared = [rel for rel in stray_files if rel in canon_files]

    tracked = tracked_set()
    untracked = [rel for rel in stray_files if (STRAY / rel).as_posix() not in tracked]
    if untracked:
        print("REFUSED: %d file(s) in the tree are NOT tracked, so git cannot "
              "restore them: %s" % (len(untracked), untracked[:5]))
        return 1
    missing_at_head = [rel for rel in stray_files if blob_at_head((STRAY / rel).as_posix()) is None]
    if missing_at_head:
        print("REFUSED: %d tracked file(s) have no blob at HEAD: %s"
              % (len(missing_at_head), missing_at_head[:5]))
        return 1

    ARCHIVE.mkdir(parents=True, exist_ok=True)
    manifest = []
    for rel in unique:
        src = STRAY / rel
        dst = ARCHIVE / "files" / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        raw = src.read_bytes()
        dst.write_bytes(raw)
        manifest.append((rel, len(raw), hashlib.sha256(raw).hexdigest()))

    lines = [
        "# T-238 archive -- files unique to .saipen/extensions/subs/saitranslate/",
        "",
        "That tree was an UNREGISTERED leftover: .saipen/extensions/subs/MANIFEST.md",
        "lists five roles and saitranslate is not among them, so no engine path",
        "reads, collects, syncs or manages it. The charter names this exact shape",
        "as a copy to retire on sight.",
        "",
        "Recovery is twofold. These files are the only copy, so they are archived",
        "here verbatim. Every OTHER file in the tree (%d of them) is a byte-identical",
        "counterpart of a file in the canonical .saipen/saitranslate/, or is",
        "restorable from git: all %d files in the tree are tracked at HEAD, each",
        "with a blob present there, so `git checkout HEAD -- <path>` restores them.",
        "",
        "Canonical counterparts for the %d shared files: .saipen/saitranslate/<same rel>",
        "",
        "## Archived files (unique to the retired tree)",
        "",
        "| file | bytes | sha256 |",
        "|---|---|---|",
    ]
    for rel, size, digest in manifest:
        lines.append("| `%s` | %d | `%s` |" % (rel, size, digest))
    lines += [
        "",
        "## Verify the archive",
        "",
        "    python .saipen/kitchen/archive-saitranslate-stray.py --verify",
        "",
    ]
    (ARCHIVE / "MANIFEST.md").write_text("\n".join(lines) + "\n", encoding="utf-8", newline="\n")

    print("stray tree: %d files (%d unique, %d also in the canonical kitchen)"
          % (len(stray_files), len(unique), len(shared)))
    print("git proof : every file tracked at HEAD with a blob present")
    print("archived  : %d unique file(s) -> %s" % (len(manifest), ARCHIVE))
    for rel, size, digest in manifest[:5]:
        print("   %-34s %7d  %s" % (rel, size, digest[:16]))
    if len(manifest) > 5:
        print("   ... and %d more" % (len(manifest) - 5))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
