'use strict';
// T-376, final attempt at the third setting: scroll a real rich embed card
// (embedFull__623de, 11 images, 15 links -- a game-listing widget) into the
// viewport, then toggle "Hide rich link preview cards" from the real panel and
// watch that card.
//
// The earlier failures were all measurement failures, not plugin failures: the
// card was rendered but ~1600px below the fold, so every snapshot was of an
// empty band.

const { pageTargets, connect } = require('../../tools/cdp-client.js');

const PORT = Number(process.env.BD_CDP_PORT || 9223);

async function ev(c, e) {
  const r = await c.send('Runtime.evaluate', { expression: e, returnByValue: true });
  if (r.exceptionDetails) {
    throw new Error((r.exceptionDetails.exception && r.exceptionDetails.exception.description) || r.exceptionDetails.text);
  }
  return r.result.value;
}

const SCROLLER = `[...document.querySelectorAll('div')].find(x => x.scrollHeight > x.clientHeight + 40 && x.clientHeight > 200 && x.querySelector('[id^=chat-messages]'))`;

const BY = (dy) => `(() => {
  const n = ${SCROLLER};
  if (!n) return 'no scroller';
  n.scrollTop += ${dy};
  return 'top=' + Math.round(n.scrollTop) + ' h=' + n.scrollHeight;
})()`;

const OBSERVE = `(() => {
  const cards = [...document.querySelectorAll('[class*="embedFull"]')];
  const inView = cards.filter(c => { const r = c.getBoundingClientRect(); return r.bottom > 120 && r.top < 1000; });
  const w95 = {}; for (const e of document.querySelectorAll('[data-w95-embed]')) { const v = e.getAttribute('data-w95-embed'); w95[v] = (w95[v]||0)+1; }
  const st = {}; for (const e of document.querySelectorAll('[data-w95-state]')) { const v = e.getAttribute('data-w95-state'); st[v] = (st[v]||0)+1; }
  const ph = {}; for (const e of document.querySelectorAll('[data-w95-ph]')) { const v = e.getAttribute('data-w95-ph'); ph[v] = (ph[v]||0)+1; }
  const vis = {}; for (const e of document.querySelectorAll('[data-w95-visual]')) { const v = e.getAttribute('data-w95-visual'); vis[v] = (vis[v]||0)+1; }
  const owner = {}; for (const e of document.querySelectorAll('[data-w95-owner]')) { const v = e.getAttribute('data-w95-owner'); owner[v] = (owner[v]||0)+1; }
  return JSON.stringify({
    cardsRendered: cards.length,
    cardsInView: inView.length,
    cardHeights: inView.map(c => Math.round(c.getBoundingClientRect().height)),
    cardImgs: inView.map(c => c.querySelectorAll('img').length),
    w95embed: w95, w95state: st, w95ph: ph, w95visual: vis, w95owner: owner
  });
})()`;

const CLICK = (label) => `(() => {
  const d = [...document.querySelectorAll('[role="dialog"]')].find(x => /HideEmbeds Settings/.test(x.textContent || ''));
  if (!d) return 'no dialog';
  for (const inp of d.querySelectorAll('input[type=checkbox]')) {
    let n = inp, t = '';
    for (let i = 0; i < 6 && n; i++) { const c2 = (n.textContent || '').trim(); if (c2 && c2.length < 120) { t = c2; break; } n = n.parentElement; }
    if (t === ${JSON.stringify(label)}) { const b = inp.checked; inp.click(); return t + ': ' + b + ' -> ' + inp.checked; }
  }
  return 'label not found';
})()`;

const wait = (ms) => new Promise((r) => setTimeout(r, ms));

(async () => {
  const t = (await pageTargets(PORT))[0];
  const c = connect(t);
  await c.ready;
  await c.send('Runtime.enable');

  let settled = null;
  for (let i = 0; i < 10; i++) {
    const s = await ev(c, BY(400));
    await wait(1600);
    const o = JSON.parse(await ev(c, OBSERVE));
    console.log('step' + i + ' ' + s + ' inView=' + o.cardsInView + ' h=' + JSON.stringify(o.cardHeights));
    if (o.cardsInView > 0) { settled = o; break; }
  }
  if (!settled) { console.log('NO CARD ENTERED THE VIEWPORT'); c.close(); return; }

  console.log('BASELINE   : ' + await ev(c, OBSERVE));
  console.log('toggle ON  : ' + await ev(c, CLICK('Hide rich link preview cards')));
  await wait(3000);
  console.log('AFTER ON   : ' + await ev(c, OBSERVE));
  console.log('toggle OFF : ' + await ev(c, CLICK('Hide rich link preview cards')));
  await wait(3000);
  console.log('AFTER OFF  : ' + await ev(c, OBSERVE));
  c.close();
})().catch((e) => { console.error('FAILED: ' + (e && e.message ? e.message : String(e))); process.exit(2); });