# T-905 SCOUT evidence — 2026-10-06

Scout only; no repair attempted. The repair target is the shared protocol
install, not this project, and this project does not own it (precedent: the
T-238 note in `.saipen/STATE.md`, which leaves an engine-side `validate.py`
repair open for the same reason).

## What the ticket claims, and what measuring it gives

IMP-002 — the VERIFY -> REVIEW gate matches an anchored event prefix that the
planning surface never states.

- RED, reproduced: `grep -rn 'target: T-' _SAIPEN/saipen/phases/*.md` returns
  nothing at all. No phase document names the required form.
- The form the gate actually matches is
  `verify -> PASS [target: T-###] conf: high -- <command>`. It exists in engine
  code and its tests only: `tools/test_refusal_routes.py` uses it as the
  canonical PASS evidence (lines 110, 122, 137, 268, 294, 399), and
  `saipen/phases/verify.md` states only the `conf:` suffix (line 48,
  "End with `conf: high` for green tests...") beside the anchoring rationale
  for MANUAL-VERIFY (lines 36-46, RULE-OWNER VERIFY-ORACLE-01).
- So a planner that reads verify.md learns the suffix and never the anchor, and
  meets the anchor only when a gate refuses with it — the ticket's wording.

IMP-003 — `retire` is a declared improve action, implemented, and absent from
the usage line `--help` prints.

- RED, reproduced: the usage table in `tools/saipen.py` (the string assembled
  around line 11060) lists improve actions `hold`, `unhold`, `status`, `sweep`,
  `sweep-queue`, `submit`, `complete`, `verify`, `cycle-complete`, `reconcile`,
  `abort`, `clean` — and not `retire`.
- `saipen/IMPROVE.md` line 20 declares
  `IMPROVE_ACTIONS = [bare, status, submit, complete, rebind, sweep, sweep-queue,
  verify, cycle-complete, reconcile, abort, retire, clean, hold, unhold]`, and
  line 83 documents the route.
- The CLI implements it: `tools/saipen.py` lines 8274, 8293, 8303 (and a second
  handler at 9272/9292/9302) refuse and dispatch `improve retire`, importing
  `retire_seat`. So the action is real and discoverable only from IMPROVE.md.

## The scope finding that is the real content of this scout

The fix does not land where the running CLI reads it, and the two trees are not
the same install:

| | protocol home | live runtime |
|---|---|---|
| path | `V:\...\_SAIPEN` | `C:\Users\vac34\AppData\Local\saipen\scheduled-source` |
| `saipen/phases/verify.md` | sha256 `3f558bb105f8b978...` | sha256 `3f558bb105f8b978...` (identical) |
| `tools/saipen.py` | 556272 bytes, 2026-10-06 06:42 | 546842 bytes, 2026-10-05 11:32 |

- IMP-002 is a `saipen/phases/verify.md` edit, and that file is byte-identical
  in both trees, so the two copies have to move together or the live install
  keeps teaching nothing.
- IMP-003 is a `tools/saipen.py` edit, and the live runtime is an OLDER deploy
  of that file. Editing the home fixes the source of truth and leaves the
  running CLI's `--help` unchanged until the next deploy — so the ticket's own
  red control ("the current install ...") stays red after a home-only patch.
- The home is the operator's own protocol product (`github.com/vacterro/saipen`
  per `AGENTS.md`) with a 219-file dirty working tree at `025bf596`, and its
  `tools/saipen.py` was written 2026-10-06 06:42 — i.e. some other session may
  have that exact file open. Concurrent editing of a shared tree is the hazard,
  not the patch.

## Patch text, ready to apply by whoever owns that tree

IMP-002, in `saipen/phases/verify.md`, where the `conf:` suffix is stated
(line 48), add the anchored form as the required shape:

```
- The verdict is an event whose PREFIX is anchored:
  `verify -> PASS [target: T-###] conf: high -- <command and its result>`.
  A line that merely contains `PASS`, or carries the suffix without the
  `[target: T-###]` anchor, does not satisfy the gate.
```

IMP-003, in `tools/saipen.py`'s usage string, add the missing action next to
its siblings (the `improve reconcile <cycle>|improve abort <cycle>` run):

```
improve retire <cycle> <seat> --reason <CODE>|
```

## Red control to keep, for whoever applies it

Both are greps, and both flip when the fix is right:

- `grep -rn 'target: T-' saipen/phases/*.md` — empty today, one hit after
  IMP-002.
- the improve usage line — `retire` absent today, present after IMP-003.
