'use strict';
// T-376 phase 2, step 2: walk the REAL settings nav to Plugins -> HideEmbeds and
// report the real controls that panel renders.

const { pageTargets, connect } = require('../../tools/cdp-client.js');

const PORT = Number(process.env.BD_CDP_PORT || 9223);

async function ev(cdp, expression) {
  const r = await cdp.send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: false });
  if (r.exceptionDetails) throw new Error(r.exceptionDetails.exception?.description || r.exceptionDetails.text);
  return r.result.value;
}

const NAV_LIST = `(() => {
  const nav = document.querySelector('[role="dialog"] nav, .content-1xShe3, nav');
  const root = nav || document.querySelector('[role="dialog"]') || document.body;
  return JSON.stringify([...root.querySelectorAll('[role="tab"], a, [class*="item"]')]
    .map(n => ({ t: (n.textContent || '').trim().slice(0, 40), sel: n.getAttribute('aria-selected') }))
    .filter(x => x.t));
})()`;

const CLICK_TEXT = (text) => `(() => {
  const want = ${JSON.stringify(text.toLowerCase())};
  const root = document.querySelector('[role="dialog"]') || document.body;
  const all = [...root.querySelectorAll('[role="tab"], a, [role="button"], [class*="item"]')];
  const hit = all.find(n => (n.textContent || '').trim().toLowerCase() === want)
           || all.find(n => (n.textContent || '').trim().toLowerCase().includes(want));
  if (!hit) return 'not found: ' + want;
  hit.click();
  return 'clicked: ' + (hit.textContent || '').trim().slice(0, 40);
})()`;

const PANEL = `(() => {
  const root = document.querySelector('[role="dialog"]') || document.body;
  const panel = root.querySelector('[role="tabpanel"], [class*="content"]') || root;
  const rows = [...panel.querySelectorAll('[role="tab"], [class*="setting"]')].map(n => (n.textContent || '').trim().slice(0, 40)).filter(Boolean).slice(0, 30);
  const controls = [...panel.querySelectorAll('input, select, [role="switch"], [role="checkbox"], [role="button"]')]
    .slice(0, 60).map(el => ({
      tag: el.tagName, type: el.type || null, role: el.getAttribute('role') || null,
      checked: el.checked === undefined ? null : el.checked,
      label: (el.getAttribute('aria-label') || el.name || '').toString().slice(0, 60),
      text: (el.textContent || '').trim().slice(0, 60)
    }));
  return JSON.stringify({ rows, controlCount: controls.length, controls });
})()`;

async function main() {
  const targets = await pageTargets(PORT);
  const cdp = connect(targets[0]);
  await cdp.ready;
  await cdp.send('Runtime.enable');

  console.log('nav: ' + await ev(cdp, NAV_LIST));
  console.log('click Plugins: ' + await ev(cdp, CLICK_TEXT('Plugins')));
  await new Promise((r) => setTimeout(r, 2000));
  console.log('panel after Plugins: ' + await ev(cdp, PANEL));

  console.log('click HideEmbeds: ' + await ev(cdp, CLICK_TEXT('HideEmbeds')));
  await new Promise((r) => setTimeout(r, 2000));
  console.log('panel after HideEmbeds: ' + await ev(cdp, PANEL));

  cdp.close();
}

main().catch((e) => { console.error('FAILED: ' + (e && e.message ? e.message : String(e))); process.exit(2); });