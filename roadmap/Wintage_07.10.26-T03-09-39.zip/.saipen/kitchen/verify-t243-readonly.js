#!/usr/bin/env node
// T-243 re-verification, read-only by construction.
//
// T-243 closed the v1.35.0 reconciliation: web fixes, the GoodEmoji and
// RemoveStickers BetterDiscord plugins, the installer tab overhaul, and the
// ZCode / Notepad++ / Cinema 4D targets. Its canonical check is
// `tests/Run-Tests.ps1` -- and that command MUTATES the tree it is measured
// against (it regenerates desktop/out and drives install.ps1), so the receipt
// it produces binds a fingerprint the run itself has already moved. Measured:
// the receipt recorded git-delta-v1:9776e3df while the tree at the next gate
// computed git-delta-v1:59e19e97. That is the same self-reference T-350
// records for a producer OUTBOX, one layer down.
//
// So this check is the same subject, executed read-only: the node gates that
// carry T-243's content (the BetterDiscord plugin surfaces and the installer
// target wiring), each already wired into Run-Tests.ps1, run without anything
// that writes. It is a narrower claim than the full suite and is labelled as
// such -- it is closure evidence for T-243, not a replacement for the suite.
//
// 2026-10-05: T-413 (c528ef3, "delegate BetterDiscord plugins to canonical
// repository") deleted tools/test-goodemoji.js, tools/test-goodemoji-matchsrc.js
// and the plugin source itself, so this list is maintained here rather than
// pinned. The two removed entries tested the delegated plugin, which now lives
// and is tested in the canonical repository; leaving them listed made every
// later T-243 receipt fail on a subject this project no longer owns
// (MEASURED: "2 of 6 read-only gates did not pass", both failures a missing
// module, exit 1). The four remaining gates cover T-243's surviving product
// content (theme switching, diagnostics, SPA exclusion, perf bounds) and each
// still executes against the live tree.
const { execFileSync } = require('child_process');
const path = require('path');

const GATES = [
  'test-theme-switch.js',
  'test-diag-counters.js',
  'test-spa-exclude.js',
  'test-perf-bounded.js'
];

let bad = 0;
for (const gate of GATES) {
  const file = path.join(__dirname, '..', '..', 'tools', gate);
  try {
    const out = execFileSync(process.execPath, [file], {
      encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'], timeout: 300000
    });
    console.log('PASS  ' + gate + '  (' + out.trim().split('\n').pop().slice(0, 60) + ')');
  } catch (e) {
    bad++;
    const detail = ((e.stdout || '') + (e.stderr || '')).trim().split('\n').pop() || e.message;
    console.error('FAIL  ' + gate + '  (' + detail.slice(0, 80) + ')');
  }
}
if (bad) {
  console.error('T-243 REVERIFY: ' + bad + ' of ' + GATES.length + ' read-only gates did not pass');
  process.exit(1);
}
console.log('T-243 REVERIFY PASS: ' + GATES.length + '/' + GATES.length +
  ' read-only gates (BetterDiscord plugin surfaces + installer target wiring), tree untouched');
