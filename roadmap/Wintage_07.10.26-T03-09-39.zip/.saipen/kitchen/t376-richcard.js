'use strict';
// T-376: the third setting -- "Hide rich link preview cards". A rich card was
// located in older history of #matchmaking, so the toggle now has something to
// act on and the clause can be observed for real instead of argued about.
//
// Restores the setting on the way out.

const { pageTargets, connect } = require('../../tools/cdp-client.js');

const PORT = Number(process.env.BD_CDP_PORT || 9223);
const CARD_SEL = '[class*="messageEmbed"], [class*="embedWrapper"], [class*="embedFull"], [class*="embeds"]';

async function ev(c, e) {
  const r = await c.send('Runtime.evaluate', { expression: e, returnByValue: true });
  if (r.exceptionDetails) {
    throw new Error((r.exceptionDetails.exception && r.exceptionDetails.exception.description) || r.exceptionDetails.text);
  }
  return r.result.value;
}

const SCROLLER = `[...document.querySelectorAll('div')].find(x => x.scrollHeight > x.clientHeight + 40 && x.clientHeight > 200 && x.querySelector('[id^=chat-messages]'))`;

const SET_TOP = (top) => `(() => {
  const n = ${SCROLLER};
  if (!n) return 'no scroller';
  n.scrollTop = ${top};
  return 'top=' + n.scrollTop;
})()`;

const OBSERVE = `(() => {
  const cards = [...document.querySelectorAll(${JSON.stringify(CARD_SEL)})];
  const vis = cards.filter(c => c.getBoundingClientRect().bottom > 100 && c.getBoundingClientRect().top < 1000);
  const w95 = {};
  for (const e of document.querySelectorAll('[data-w95-embed]')) {
    const v = e.getAttribute('data-w95-embed');
    w95[v] = (w95[v] || 0) + 1;
  }
  const st = {};
  for (const e of document.querySelectorAll('[data-w95-state]')) {
    const v = e.getAttribute('data-w95-state');
    st[v] = (st[v] || 0) + 1;
  }
  const ph = {};
  for (const e of document.querySelectorAll('[data-w95-ph]')) {
    const v = e.getAttribute('data-w95-ph');
    ph[v] = (ph[v] || 0) + 1;
  }
  return JSON.stringify({
    cardsRendered: cards.length,
    cardsVisible: vis.length,
    w95embed: w95,
    state: st,
    ph: ph
  });
})()`;

const DIALOG_PRESENT = `(() => {
  const ds = [...document.querySelectorAll('[role="dialog"]')];
  return JSON.stringify(ds.map(d => ({ head: (d.innerText || '').slice(0, 60), hasHE: /HideEmbeds Settings/.test(d.textContent || '') })));
})()`;

const CLICK_CHECKBOX = (label) => `(() => {
  const ds = [...document.querySelectorAll('[role="dialog"]')];
  const d = ds.find(x => /HideEmbeds Settings/.test(x.textContent || ''));
  if (!d) return 'no HideEmbeds dialog';
  for (const inp of d.querySelectorAll('input[type=checkbox]')) {
    let n = inp, t = '';
    for (let i = 0; i < 6 && n; i++) {
      const c2 = (n.textContent || '').trim();
      if (c2 && c2.length < 120) { t = c2; break; }
      n = n.parentElement;
    }
    if (t === ${JSON.stringify(label)}) {
      const before = inp.checked;
      inp.click();
      return t + ': ' + before + ' -> ' + inp.checked;
    }
  }
  return 'label not found: ' + ${JSON.stringify(label)};
})()`;

const wait = (ms) => new Promise((r) => setTimeout(r, ms));

(async () => {
  const t = (await pageTargets(PORT))[0];
  const c = connect(t);
  await c.ready;
  await c.send('Runtime.enable');

  // Settle at a scroll position that actually holds rich cards, then HOLD it:
  // the earlier pass walked five positions and left the view past the card, so
  // every later observation was of an empty band.
  const PROBE_TOP = 1334;
  let found = false;
  for (const top of [PROBE_TOP, 1300, 1350, 1280, 1380]) {
    await ev(c, SET_TOP(top));
    await wait(2500);
    const o = JSON.parse(await ev(c, OBSERVE));
    console.log('probe top=' + top + ' cardsRendered=' + o.cardsRendered + ' cardsVisible=' + o.cardsVisible + ' w95=' + JSON.stringify(o.w95embed));
    if (o.cardsRendered > 0 && !found) { found = true; break; }
  }
  if (!found) { console.log('NO RICH CARD RENDERED'); c.close(); return; }

  await wait(2200);
  console.log('dialogs: ' + await ev(c, DIALOG_PRESENT));
  console.log('BASELINE : ' + await ev(c, OBSERVE));

  console.log('toggle ON  : ' + await ev(c, CLICK_CHECKBOX('Hide rich link preview cards')));
  await wait(3000);
  console.log('AFTER ON   : ' + await ev(c, OBSERVE));

  console.log('toggle OFF : ' + await ev(c, CLICK_CHECKBOX('Hide rich link preview cards')));
  await wait(3000);
  console.log('AFTER OFF  : ' + await ev(c, OBSERVE));

  c.close();
})().catch((e) => { console.error('FAILED: ' + (e && e.message ? e.message : String(e))); process.exit(2); });