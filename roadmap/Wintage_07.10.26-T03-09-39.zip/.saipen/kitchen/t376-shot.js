'use strict';
// T-376 phase 2, step 3: screenshot the real Discord window so the settings
// panel can be navigated by what is actually on screen rather than by guessing
// at Discord's generated class names.

const fs = require('fs');
const { pageTargets, connect } = require('../../tools/cdp-client.js');

const PORT = Number(process.env.BD_CDP_PORT || 9223);
const OUT = process.env.SHOT || '.saipen/kitchen/t376-shot.png';

async function ev(cdp, expression) {
  const r = await cdp.send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: false });
  if (r.exceptionDetails) throw new Error(r.exceptionDetails.exception?.description || r.exceptionDetails.text);
  return r.result.value;
}

const DIALOG_TEXT = `(() => {
  const d = document.querySelector('[role="dialog"]');
  if (!d) return 'NO DIALOG';
  const r = d.getBoundingClientRect();
  return JSON.stringify({ w: Math.round(r.width), h: Math.round(r.height), text: d.innerText.slice(0, 1200) });
})()`;

async function main() {
  const targets = await pageTargets(PORT);
  const cdp = connect(targets[0]);
  await cdp.ready;
  await cdp.send('Runtime.enable');
  await cdp.send('Page.enable');

  console.log(await ev(cdp, DIALOG_TEXT));

  const shot = await cdp.send('Page.captureScreenshot', { format: 'png' });
  fs.writeFileSync(OUT, Buffer.from(shot.data, 'base64'));
  console.log('wrote ' + OUT + ' (' + fs.statSync(OUT).size + ' bytes)');

  cdp.close();
}

main().catch((e) => { console.error('FAILED: ' + (e && e.message ? e.message : String(e))); process.exit(2); });