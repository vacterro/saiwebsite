'use strict';
// T-376 phase 2: read the whole settings dialog after navigating into a
// plugin's own settings page.

const { pageTargets, connect } = require('../../tools/cdp-client.js');

const PORT = Number(process.env.BD_CDP_PORT || 9223);

async function ev(c, e) {
  const r = await c.send('Runtime.evaluate', { expression: e, returnByValue: true });
  if (r.exceptionDetails) {
    throw new Error((r.exceptionDetails.exception && r.exceptionDetails.exception.description) || r.exceptionDetails.text);
  }
  return r.result.value;
}

(async () => {
  const t = (await pageTargets(PORT))[0];
  const c = connect(t);
  await c.ready;
  await c.send('Runtime.enable');
  console.log(await ev(c, `(() => {
    const ds = [...document.querySelectorAll('[role="dialog"]')];
    return JSON.stringify(ds.map((d, i) => ({
      i,
      len: (d.innerText || d.textContent || '').length,
      head: (d.innerText || d.textContent || '').replace(/\\n/g, ' | ').slice(0, 1200)
    })), null, 1);
  })()`));
  c.close();
})().catch((e) => { console.error('FAILED: ' + e.message); process.exit(2); });