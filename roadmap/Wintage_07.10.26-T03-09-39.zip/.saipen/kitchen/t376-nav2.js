'use strict';
// T-376 phase 2, step 4: click through the real BetterDiscord Plugins list and
// screenshot what the panel actually shows.

const fs = require('fs');
const { pageTargets, connect } = require('../../tools/cdp-client.js');

const PORT = Number(process.env.BD_CDP_PORT || 9223);

async function ev(cdp, expression) {
  const r = await cdp.send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: false });
  if (r.exceptionDetails) throw new Error(r.exceptionDetails.exception?.description || r.exceptionDetails.text);
  return r.result.value;
}

// Discord renders each sidebar entry as a div/button whose own text is the label.
// Matching on a trimmed full-text equality inside the dialog is what actually
// lands on the right row; anything looser hits the server rail instead.
const CLICK_IN_DIALOG = (text) => `(() => {
  const d = document.querySelector('[role="dialog"]');
  if (!d) return 'NO DIALOG';
  const want = ${JSON.stringify(text)};
  const nodes = [...d.querySelectorAll('div, span, button, a, [role="button"], [role="tab"]')]
    .filter(n => n.children.length === 0 || n.tagName === 'BUTTON' || n.tagName === 'A');
  const hit = nodes.find(n => (n.textContent || '').trim() === want);
  if (!hit) return 'not found: ' + want;
  (hit.closest('[role="button"],button,a') || hit).click();
  return 'clicked: ' + want;
})()`;

const CONTENT = `(() => {
  const d = document.querySelector('[role="dialog"]');
  if (!d) return 'NO DIALOG';
  // The sidebar is the narrow left column; the pane is the wide right column.
  const wide = [...d.querySelectorAll('div')].filter(n => {
    const r = n.getBoundingClientRect();
    return r.width > 400 && r.height > 300;
  }).pop();
  const pane = wide || d;
  return JSON.stringify({
    text: pane.innerText.slice(0, 900),
    switches: [...pane.querySelectorAll('input[type=checkbox], [role=switch], [role=checkbox]')]
      .slice(0, 40).map(el => ({
        tag: el.tagName, type: el.type || null, checked: el.checked === undefined ? null : el.checked,
        label: (el.getAttribute('aria-label') || el.id || el.name || '').toString().slice(0, 50),
        near: (el.closest('div') && el.closest('div').innerText || '').trim().slice(0, 60)
      }))
  });
})()`;

async function shot(cdp, name) {
  const s = await cdp.send('Page.captureScreenshot', { format: 'png' });
  const path = '.saipen/kitchen/t376-' + name + '.png';
  fs.writeFileSync(path, Buffer.from(s.data, 'base64'));
  return path;
}

async function main() {
  const targets = await pageTargets(PORT);
  const cdp = connect(targets[0]);
  await cdp.ready;
  await cdp.send('Runtime.enable');
  await cdp.send('Page.enable');

  console.log('click Plugins: ' + await ev(cdp, CLICK_IN_DIALOG('Plugins')));
  await new Promise((r) => setTimeout(r, 2000));
  console.log('content: ' + await ev(cdp, CONTENT));
  console.log('shot: ' + await shot(cdp, 'plugins-list'));

  cdp.close();
}

main().catch((e) => { console.error('FAILED: ' + (e && e.message ? e.message : String(e))); process.exit(2); });