'use strict';
// T-376 LIVE BetterDiscord acceptance, phase 1: does the real signed-in Discord
// carry BetterDiscord, and did the four plugins from
// desktop/targets/betterdiscord/plugins load into it without a console error?
//
// tools/cdp-client.js is request/response only -- it exposes no event
// subscription -- so a passive console listener is impossible through it. The
// supported way to observe load-time errors is to install the recorder as a
// new-document script BEFORE the reload, then read it back. That also means the
// capture covers BetterDiscord's own injection window, which a post-load
// listener would miss entirely.

const { pageTargets, connect } = require('../../tools/cdp-client.js');

const PORT = Number(process.env.BD_CDP_PORT || 9223);
const WANTED = ['HideEmbeds', 'RemoveGIFS', 'RemoveStickers', 'GoodEmoji'];

const RECORDER = `(() => {
  const errs = [];
  Object.defineProperty(window, '__w95errs', { value: errs, configurable: true });
  const push = (kind, text) => { try { errs.push(kind + ': ' + String(text).slice(0, 400)); } catch (e) {} };
  window.addEventListener('error', (e) => push('error', (e.message || '') + ' @ ' + (e.filename || '?') + ':' + (e.lineno || 0)));
  window.addEventListener('unhandledrejection', (e) => push('unhandledrejection', (e.reason && e.reason.stack) || e.reason));
  const ce = console.error;
  console.error = function () { push('console.error', [].join.call(arguments, ' ')); return ce.apply(console, arguments); };
  const cw = console.warn;
  console.warn = function () { push('console.warn', [].join.call(arguments, ' ')); return cw.apply(console, arguments); };
})();`;

async function evaluate(cdp, expression) {
  const r = await cdp.send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: false });
  if (r.exceptionDetails) {
    throw new Error('evaluate threw: ' + (r.exceptionDetails.exception?.description || r.exceptionDetails.text));
  }
  return r.result.value;
}

async function main() {
  const targets = await pageTargets(PORT);
  if (!targets.length) throw new Error('no page target on CDP ' + PORT);

  const cdp = connect(targets[0]);
  await cdp.ready;
  await cdp.send('Runtime.enable');
  await cdp.send('Page.enable');
  console.log('target: ' + targets[0].url);

  // The recorder has to be armed before the document that will run the plugins.
  await cdp.send('Page.addScriptToEvaluateOnNewDocument', { source: RECORDER });
  await cdp.send('Page.reload', { ignoreCache: false });

  // Bounded wait for BetterDiscord to finish injecting. Poll, never sleep-blind.
  const deadline = Date.now() + 45000;
  let report = null;
  while (Date.now() < deadline) {
    await new Promise((res) => setTimeout(res, 1500));
    try {
      const raw = await evaluate(cdp, `JSON.stringify({
        injected: !!(globalThis.BdApi || globalThis.Bdapi),
        hasRecorder: Array.isArray(globalThis.__w95errs)
      })`);
      const s = JSON.parse(raw);
      if (s.injected) { report = s; break; }
    } catch (e) { /* document mid-swap; poll again */ }
  }
  if (!report) throw new Error('BetterDiscord did not inject within 45s of the reload');

  const detail = JSON.parse(await evaluate(cdp, `(() => {
    const bd = globalThis.BdApi || globalThis.Bdapi;
    const list = bd.plugins && typeof bd.plugins.getAll === 'function' ? bd.plugins.getAll() : [];
    const want = ${JSON.stringify(WANTED)};
    return JSON.stringify({
      version: bd.version || null,
      pluginCount: list.length,
      loaded: list.filter(p => p.getName && want.includes(p.getName()))
                   .map(p => ({ name: p.getName(), version: p.getVersion(), enabled: p.isEnabled() })),
      errors: Array.isArray(globalThis.__w95errs) ? globalThis.__w95errs.slice() : []
    });
  })()`));

  console.log(JSON.stringify(detail, null, 2));

  const loadedNames = detail.loaded.map((p) => p.name);
  const missing = WANTED.filter((n) => !loadedNames.includes(n));
  // Discord/BetterDiscord chatter that is not a plugin failing to load.
  const relevant = detail.errors.filter((e) => /betterdiscord|plugin|hideembeds|removegifs|removestickers|goodemoji/i.test(e));

  console.log('--- verdict ---');
  console.log('BetterDiscord version   : ' + detail.version);
  console.log('plugins loaded total    : ' + detail.pluginCount);
  console.log('missing                 : ' + (missing.length ? missing.join(', ') : '(none)'));
  console.log('loaded-but-disabled     : ' + (detail.loaded.filter(p => !p.enabled).map(p => p.name).join(', ') || '(none)'));
  console.log('captured errors (all)   : ' + detail.errors.length);
  console.log('captured errors (plugin): ' + relevant.length);
  detail.errors.forEach((e) => console.log('  ERR ' + e));

  cdp.close();
  process.exit(!missing.length && relevant.length === 0 ? 0 : 1);
}

main().catch((e) => {
  console.error('PROBE FAILED: ' + (e && e.message ? e.message : String(e)));
  process.exit(2);
});