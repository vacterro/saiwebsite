"""T-238, pre-deletion proof: of the 116 files in the stray saitranslate tree,
the 98 that also exist in the canonical kitchen must be BYTE-IDENTICAL there.

A name match is not a recovery proof. If any of the 98 differs, deleting the
stray copy would destroy bytes the canonical copy does not hold, and this script
must say so before anything is removed.
"""
import hashlib
import pathlib

STRAY = pathlib.Path(".saipen/extensions/subs/saitranslate")
CANON = pathlib.Path(".saipen/saitranslate")


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


stray = sorted(p.relative_to(STRAY).as_posix() for p in STRAY.rglob("*") if p.is_file())
canon = {p.relative_to(CANON).as_posix() for p in CANON.rglob("*") if p.is_file()}

shared = [r for r in stray if r in canon]
unique = [r for r in stray if r not in canon]

identical = []
differing = []
for rel in shared:
    (identical if sha(STRAY / rel) == sha(CANON / rel) else differing).append(rel)

print("stray files: %d" % len(stray))
print("  also present by name in the canonical kitchen : %d" % len(shared))
print("  of those, BYTE-IDENTICAL                       : %d" % len(identical))
print("  of those, DIFFERING                            : %d" % len(differing))
print("  unique to the stray tree (archived)           : %d" % len(unique))
print()
if differing:
    print("REFUSED: these exist in both trees but differ, so removing the stray copy")
    print("would lose bytes the canonical copy does not hold:")
    for rel in differing[:20]:
        print("   %s" % rel)
    raise SystemExit(1)
print("CLEAR: every non-unique file is byte-identical in the canonical kitchen, so")
print("deleting the stray tree destroys nothing the surviving tree does not hold.")
print("The %d unique files are archived under .saipen/recovery/saitranslate-stray-20260929/." % len(unique))
