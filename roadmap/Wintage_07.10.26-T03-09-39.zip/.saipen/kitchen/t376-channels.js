'use strict';
// T-376 phase 2: the "Hide rich link preview cards" clause can only be observed
// on an actual rich link card, and the channel the client opened on (#matchmaking)
// has none. Enumerate the server's text channels so a bounded scan can look for
// one elsewhere.
//
// Read-only: listing channels clicks nothing.

const { pageTargets, connect } = require('../../tools/cdp-client.js');

const PORT = Number(process.env.BD_CDP_PORT || 9223);

async function ev(c, e) {
  const r = await c.send('Runtime.evaluate', { expression: e, returnByValue: true });
  if (r.exceptionDetails) {
    throw new Error((r.exceptionDetails.exception && r.exceptionDetails.exception.description) || r.exceptionDetails.text);
  }
  return r.result.value;
}

const CHANNELS = `(() => {
  const out = [];
  // Text channels, public and private, excluding threads.
  const items = [...document.querySelectorAll('[class*="channelItem"], [data-list-item-id^="channels__"], [class*="linkWrapper"]')]
    .map(n => {
      const href = n.getAttribute('href') || '';
      const m = href.match(/\\/channels\\/(\\d+)\\/(\\d+)/);
      const name = (n.getAttribute('aria-label') || n.textContent || '').trim();
      if (!m) return null;
      return { guild: m[1], channel: m[2], name: name.slice(0, 40), isThread: !!n.querySelector('[class*="thread"]') };
    })
    .filter(Boolean);
  const seen = new Set();
  for (const c of items) {
    const k = c.channel;
    if (seen.has(k)) continue;
    seen.add(k);
    out.push(c);
  }
  return JSON.stringify({ count: out.length, channels: out.slice(0, 60) }, null, 1);
})()`;

(async () => {
  const t = (await pageTargets(PORT))[0];
  const c = connect(t);
  await c.ready;
  await c.send('Runtime.enable');
  console.log(await ev(c, CHANNELS));
  c.close();
})().catch((e) => { console.error('FAILED: ' + (e && e.message ? e.message : String(e))); process.exit(2); });