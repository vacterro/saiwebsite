'use strict';
// T-376 phase 2: inventory the real HideEmbeds settings dialog controls.

const { pageTargets, connect } = require('../../tools/cdp-client.js');

const PORT = Number(process.env.BD_CDP_PORT || 9223);

async function ev(c, e) {
  const r = await c.send('Runtime.evaluate', { expression: e, returnByValue: true });
  if (r.exceptionDetails) {
    throw new Error((r.exceptionDetails.exception && r.exceptionDetails.exception.description) || r.exceptionDetails.text);
  }
  return r.result.value;
}

const INVENTORY = `(() => {
  const ds = [...document.querySelectorAll('[role="dialog"]')];
  const d = ds.find(x => /HideEmbeds Settings/.test(x.textContent || ''));
  if (!d) return 'no HideEmbeds dialog';
  const rows = [];
  for (const inp of d.querySelectorAll('input')) {
    let n = inp, label = '';
    for (let i = 0; i < 6 && n; i++) {
      const t = (n.textContent || '').trim();
      if (t && t.length < 120) { label = t; break; }
      n = n.parentElement;
    }
    rows.push({ kind: 'input', type: inp.type, checked: inp.checked, value: inp.value || null, label: label.slice(0, 90) });
  }
  const btns = [...d.querySelectorAll('button')].map(b => ({
    text: (b.textContent || '').trim().slice(0, 40),
    aria: (b.getAttribute('aria-label') || '').slice(0, 40),
    cls: (b.className || '').toString().slice(0, 50)
  }));
  return JSON.stringify({ inputs: rows, buttons: btns, text: (d.innerText || '').slice(0, 900) }, null, 1);
})()`;

(async () => {
  const t = (await pageTargets(PORT))[0];
  const c = connect(t);
  await c.ready;
  await c.send('Runtime.enable');
  console.log(await ev(c, INVENTORY));
  c.close();
})().catch((e) => { console.error('FAILED: ' + e.message); process.exit(2); });