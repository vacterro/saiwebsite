'use strict';
// T-376 phase 2, retry: the placeholder-mode control is a native <select>, not
// a button row. The previous pass clicked a LABEL and changed nothing, so the
// mode change was never actually exercised. Setting select.value and firing
// 'change' is what a user's own choice in the native picker produces, and it is
// the only way React's controlled <select> observes the change at all.

const { pageTargets, connect } = require('../../tools/cdp-client.js');

const PORT = Number(process.env.BD_CDP_PORT || 9223);

async function ev(c, e) {
  const r = await c.send('Runtime.evaluate', { expression: e, returnByValue: true });
  if (r.exceptionDetails) {
    throw new Error((r.exceptionDetails.exception && r.exceptionDetails.exception.description) || r.exceptionDetails.text);
  }
  return r.result.value;
}

const SEL = `(() => {
  const ds = [...document.querySelectorAll('[role="dialog"]')];
  const d = ds.find(x => /HideEmbeds Settings/.test(x.textContent || ''));
  const sels = [...d.querySelectorAll('select')].map(s => ({
    value: s.value,
    options: [...s.options].map(o => o.value + '=' + o.text)
  }));
  return JSON.stringify(sels);
})()`;

const SET_MODE = (mode) => `(() => {
  const ds = [...document.querySelectorAll('[role="dialog"]')];
  const d = ds.find(x => /HideEmbeds Settings/.test(x.textContent || ''));
  const sel = [...d.querySelectorAll('select')].find(s => [...s.options].some(o => o.value === ${JSON.stringify(mode)} || o.text === ${JSON.stringify(mode)}));
  if (!sel) return 'no select with option ' + ${JSON.stringify(mode)};
  const before = sel.value;
  sel.value = ${JSON.stringify(mode)};
  sel.dispatchEvent(new Event('change', { bubbles: true }));
  sel.dispatchEvent(new Event('input', { bubbles: true }));
  return 'select ' + before + ' -> ' + sel.value;
})()`;

const OBSERVE = `(() => {
  const ds = [...document.querySelectorAll('[role="dialog"]')];
  const d = ds.find(x => /HideEmbeds Settings/.test(x.textContent || ''));
  const txt = d ? (d.innerText || '') : '';
  const m = txt.match(/Items hidden in current session: ([0-9]+)/);
  const val = (n) => {
    const vs = [...document.querySelectorAll('[data-w95-' + n + ']')].map(e => e.getAttribute('data-w95-' + n));
    const c = {}; for (const v of vs) c[v] = (c[v] || 0) + 1;
    return { total: vs.length, counts: c };
  };
  const sel = d ? [...d.querySelectorAll('select')].map(s => s.value) : [];
  return JSON.stringify({
    selectValues: sel,
    hiddenCount: m ? Number(m[1]) : null,
    state: val('state'), visual: val('visual'), ph: val('ph'), act: val('act')
  });
})()`;

const wait = (ms) => new Promise((r) => setTimeout(r, ms));

(async () => {
  const t = (await pageTargets(PORT))[0];
  const c = connect(t);
  await c.ready;
  await c.send('Runtime.enable');

  console.log('selects: ' + await ev(c, SEL));
  console.log('00 baseline  : ' + await ev(c, OBSERVE));

  for (const mode of ['blurred', 'collapsed', 'compact']) {
    console.log('set ' + mode + ' : ' + await ev(c, SET_MODE(mode)));
    await wait(2500);
    console.log('   observed   : ' + await ev(c, OBSERVE));
  }

  console.log('done');
  c.close();
})().catch((e) => { console.error('FAILED: ' + (e && e.message ? e.message : String(e))); process.exit(2); });