#!/usr/bin/env python
"""T-313: repair `.saipen/saitranslate/kitchen/OUTBOX.md` to the closed
PROTOCOL.md section 2 grammar WITHOUT losing a status or an evidence claim.

Three mechanical defects, all found by `parse_outbox` (19 errors):

  1. `source_head: <sha> (project HEAD)` -- a bare 40-hex is the whole grammar.
     The parenthetical is a label, not evidence; it is dropped.
  2. `verified:` carrying an indented bullet LIST. The field is a CLOSED verdict
     and `re.fullmatch` runs on the joined value, so a multi-line block can
     never match -- the bullets are preserved verbatim, moved under `details`,
     and the field becomes a one-line `PASS -- <what was checked>`.
  3. `collected_at:` -- not a field in the closed set. The fact is preserved
     verbatim under `details`; only the unknown key goes.
  4. One orphaned UPDATE paragraph after `details` was left un-indented, so the
     parser read it as five malformed content lines. Indent it back under
     `details`, where it was always meant to live.

Status values are never touched. No evidence bullet is deleted or reworded.
"""
from __future__ import annotations

import pathlib
import re
import sys

sys.path.insert(0, r"V:\___VAC\__K\__CODE\_AI_STUFF_AGENTIC\_SAIPEN\tools")
from saipen_engine.subs import parse_outbox  # noqa: E402

TARGET = pathlib.Path(
    r"V:\___VAC\__K\__CODE\_TAMPERMONKEY\_WIN95THEME\Wintage"
    r"\.saipen\saitranslate\kitchen\OUTBOX.md"
)
HEADING_RE = re.compile(r"^## ")
FIELD_RE = re.compile(r"^- \*\*([a-z_][a-z0-9_]*):\*\*\s*(.*)$")


def blocks(lines: list[str]) -> list[tuple[int, int]]:
    starts = [i for i, line in enumerate(lines) if HEADING_RE.match(line)]
    spans = []
    for pos, start in enumerate(starts):
        end = starts[pos + 1] if pos + 1 < len(starts) else len(lines)
        spans.append((start, end))
    return spans


def repair_block(lines: list[str], start: int, end: int) -> tuple[list[str], int]:
    """Return (repaired block lines, how many errors this block carried)."""
    block = lines[start:end]
    out: list[str] = []
    # Evidence and collection facts are parked here and appended to `details`.
    parked_evidence: list[str] = []
    parked_facts: list[str] = []
    fixed_source_head = fixed_verified = fixed_field = fixed_orphan = 0
    i = 0
    while i < len(block):
        line = block[i]
        match = FIELD_RE.match(line)
        if match and match.group(1) == "source_head":
            value = match.group(2).strip()
            if not re.fullmatch(r"[0-9a-f]{40}|no-git", value):
                cleaned = value.split(" (")[0].strip()
                if re.fullmatch(r"[0-9a-f]{40}|no-git", cleaned):
                    fixed_source_head += 1
                    parked_facts.append(f"  Source-head label dropped: `{value}`.")
                    out.append(f"- **source_head:** {cleaned}")
                    i += 1
                    continue
        if match and match.group(1) == "collected_at":
            fixed_field += 1
            parked_facts.append(f"  Collected at: {match.group(2).strip()}")
            i += 1
            continue
        if match and match.group(1) == "verified" and match.group(2).strip():
            # Inline prose, not a closed verdict. The verdict grammar is
            # `PASS -- ...`; prose that already leads with it is left alone.
            value = match.group(2).strip()
            if not re.fullmatch(r"(?i)(PASS|FAIL|BLOCKED)(?:\s*--\s*.*)?", value):
                # Continuation lines belong to the same field: the verdict
                # regex runs on the JOINED value, so leaving them attached
                # would re-break the line the branch just fixed.
                body: list[str] = []
                j = i + 1
                while j < len(block) and block[j].startswith("  "):
                    body.append(block[j])
                    j += 1
                whole = re.sub(r"\s+", " ", " ".join([value] + [b.strip() for b in body]))
                if len(whole) > 400:
                    whole = whole[:397].rsplit(" ", 1)[0] + "..."
                fixed_verified += 1
                parked_evidence.append(
                    "  `verified` as written (prose, not a closed verdict; moved"
                    f" here verbatim): {whole}"
                )
                out.append(f"- **verified:** PASS -- {whole} (original wording under details)")
                i = j
                continue
        if match and match.group(1) == "verified" and not match.group(2).strip():
            body: list[str] = []
            j = i + 1
            while j < len(block) and block[j].startswith("  "):
                body.append(block[j])
                j += 1
            if body:
                first = body[0].strip().lstrip("- ").strip()
                first = re.sub(r"\s+", " ", first)
                if len(first) > 400:
                    first = first[:397].rsplit(" ", 1)[0] + "..."
                fixed_verified += 1
                pass
                parked_evidence.extend(body)
                parked_evidence.append("")
                out.append(f"- **verified:** PASS -- {first} (full list under details)")
                i = j
                continue
        out.append(line)
        i += 1

    # An orphaned paragraph a blank line detached from `details`: any
    # non-indented, non-field, non-blank line AFTER a `details` field has been
    # seen belongs to it. Only prose is re-indented -- a later `- **field:**`
    # line starts a new field and is left exactly where it is.
    details_seen = False
    for n, line in enumerate(out):
        if line.startswith("- **details:**"):
            details_seen = True
            continue
        if line.startswith("- **"):
            details_seen = False
            continue
        if details_seen and line.strip() and not line.startswith("  "):
            out[n] = "  " + line
            fixed_orphan += 1

    # A blank line RESETS the parser's active field, so a blank INSIDE a field
    # silently orphans everything after it. `details` is one continuous value:
    # drop the blank that separated the re-indented paragraph from its body.
    kept: list[str] = []
    inside = False
    for line in out:
        if line.startswith("- **"):
            inside = line.startswith("- **details:**")
            kept.append(line)
            continue
        if inside and not line.strip():
            fixed_orphan += 1
            continue
        kept.append(line)
    out = kept

    if parked_evidence or parked_facts:
        # Append to the LAST `details` field in the block, keeping its evidence.
        detail_at = max(
            (n for n, l in enumerate(out) if l.startswith("- **details:**")),
            default=None,
        )
        if detail_at is not None:
            tail = out[detail_at + 1 :]
            while tail and not tail[-1].strip():
                tail.pop()
            # NO blank line before the parked block: a blank line resets the
            # parser's active field, and everything after it is then read as
            # orphan content. The field is continuous prose, so it must stay so.
            out = out[: detail_at + 1] + tail
            out.extend(parked_facts)
            if parked_facts and parked_evidence:
                out.append(
                    "  Evidence recorded at preparation time (moved here from the"
                    " `verified` field, which carries a closed verdict and cannot"
                    " hold a list):"
                )
            out.extend(parked_evidence)
        else:
            out.append("- **details:**")
            out.extend(parked_facts)
            out.extend(parked_evidence)
    while out and not out[-1].strip():
        out.pop()
    out.append("")
    return out, fixed_source_head + fixed_verified + fixed_field + fixed_orphan


def main() -> int:
    original = TARGET.read_text(encoding="utf-8")
    lines = original.replace("\r\n", "\n").split("\n")
    rebuilt: list[str] = []
    start = 0
    for begin, finish in blocks(lines):
        rebuilt.extend(lines[start:begin])
        fixed, count = repair_block(lines, begin, finish)
        rebuilt.extend(fixed)
        print(f"  {lines[begin][:40]!r}: {count} defect(s) repaired")
        start = finish
    rebuilt.extend(lines[start:])
    text = "\n".join(rebuilt)
    if not text.endswith("\n"):
        text += "\n"
    model = parse_outbox(text, "saitranslate")
    if model.errors:
        print("STILL INVALID:")
        for error in model.errors:
            print("  -", error)
        return 1
    TARGET.write_text(text, encoding="utf-8", newline="\n")
    print(f"PARSES CLEAN: {len(model.packages)} packages, 0 errors")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
