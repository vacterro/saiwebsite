"""T-408 decisive check: are T-243/T-244/T-245 bound to THIS tree by an
executed, passing reverify receipt -- and is T-357 honestly left unbound?

Reads the receipt ledger and asks the engine for the current source identity,
rather than trusting what a receipt says about itself. Re-runs T-244's three
verification commands live so the RUN event records work done after the
`transition to VERIFY` boundary, not a replay of a pre-boundary result.

Exits 0 on PASS, 1 otherwise.
"""

import json
import subprocess
import sys
from pathlib import Path

SAIPEN = Path(r"V:\___VAC\__K\__CODE\_AI_STUFF_AGENTIC\_SAIPEN")
sys.path.insert(0, str(SAIPEN / "tools"))

from saipen_engine.conformance import validator_version_info  # noqa: E402

ROOT = Path(__file__).resolve().parents[2]
LEDGER = ROOT / ".saipen" / "recovery" / "conformance" / "reverify"

# The tickets this ticket claims to bind, and the receipt each was bound by.
BOUND = {"T-243": "RV-000130", "T-244": "RV-000128", "T-245": "RV-000129"}
# Bound deliberately NOT: its verify clause needs the signed-in live shell.
UNBOUND = "T-357"

# T-244's contract, re-executed live rather than replayed.
LIVE_CHECKS = [
    ["node", "--check", "wintage.user.js"],
    ["node", "tools/check-css.js"],
    ["node", "tools/build-desktop.js", "--check"],
]

problems = []


def load(receipt_id):
    path = LEDGER / f"{receipt_id}.json"
    if not path.is_file():
        problems.append(f"{receipt_id}: receipt missing from the ledger")
        return None
    return json.loads(path.read_text(encoding="utf-8"))


ident = validator_version_info(ROOT, gate="core")
print(f"current source_head            {ident.source_head}")
print(f"current source_tree_fingerprint {ident.source_tree_fingerprint}")
print()

print("bound receipts")
for ticket, receipt_id in sorted(BOUND.items()):
    d = load(receipt_id)
    if d is None:
        continue
    checks = {
        "work": d.get("work") == ticket,
        "evidence_class=executed": d.get("evidence_class") == "executed",
        "verdict=PASS": d.get("verdict") == "PASS",
        "gate=core": d.get("gate") == "core",
        "head is current": d.get("source_head") == ident.source_head,
        "fingerprint is current": d.get("source_tree_fingerprint")
        == ident.source_tree_fingerprint,
    }
    bad = [k for k, ok in checks.items() if not ok]
    problems.extend(f"{ticket} ({receipt_id}): {k}" for k in bad)
    print(
        f"  {ticket:6} {receipt_id}  {d.get('evidence_class'):9} "
        f"{d.get('verdict'):5}  {'OK' if not bad else 'BAD ' + ','.join(bad)}"
    )

print()
print(f"unbound ticket {UNBOUND}")
latest = None
for path in sorted(LEDGER.glob("RV-*.json")):
    d = json.loads(path.read_text(encoding="utf-8"))
    if d.get("work") == UNBOUND:
        latest = (path.stem, d)
if latest is None:
    print("  no receipt at all")
else:
    rid, d = latest
    overclaim = d.get("verdict") == "PASS" and d.get("evidence_class") == "executed"
    if overclaim:
        problems.append(
            f"{UNBOUND}: {rid} records a clean executed PASS, but its live leg "
            "was never exercised -- that is the over-claim T-359 exists to stop"
        )
    print(
        f"  {rid}  {d.get('evidence_class')}  {d.get('verdict')}  "
        f"{'OVERCLAIM' if overclaim else 'correctly not a clean PASS'}"
    )

print()
print("live re-execution of T-244's contract")
for cmd in LIVE_CHECKS:
    p = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True)
    tail = (p.stdout or p.stderr).strip().splitlines()
    print(f"  exit {p.returncode}  {' '.join(cmd)}  {tail[-1][:70] if tail else ''}")
    if p.returncode != 0:
        problems.append(f"{' '.join(cmd)} exited {p.returncode}")

print()
if problems:
    print(f"PROBLEMS ({len(problems)}):")
    for p in problems:
        print(f"  - {p}")
    sys.exit(1)

print("PASS - three tickets bound to this tree by executed receipts; "
      "the fourth honestly unbound. conf: high")
