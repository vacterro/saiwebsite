'use strict';
// T-376 phase 2: the LIVE toggle pass.
//
// Every interaction is a real click on a real control in the real BetterDiscord
// settings panel of the operator's own signed-in Discord. Nothing is written
// through an API shortcut, because the clause being proven is "toggling each of
// the three settings from the real panel changes what a user sees" -- driving
// BdApi directly would prove the settings object, not the panel.
//
// Every setting is restored to the value it had on entry. This run must not
// leave the operator's configuration altered.

const { pageTargets, connect } = require('../../tools/cdp-client.js');

const PORT = Number(process.env.BD_CDP_PORT || 9223);

async function ev(c, e) {
  const r = await c.send('Runtime.evaluate', { expression: e, returnByValue: true });
  if (r.exceptionDetails) {
    throw new Error((r.exceptionDetails.exception && r.exceptionDetails.exception.description) || r.exceptionDetails.text);
  }
  return r.result.value;
}

const DIALOG = `document.querySelectorAll('[role="dialog"]')`;

// Real user-visible state, read out of the MESSAGE LIST, not out of the plugin.
const OBSERVE = `(() => {
  const ds = [...${DIALOG}];
  const d = ds.find(x => /HideEmbeds Settings/.test(x.textContent || ''));
  const panelText = d ? (d.innerText || '') : '';
  const grab = (label) => {
    const m = panelText.match(new RegExp(label + ': ([0-9]+)'));
    return m ? Number(m[1]) : null;
  };
  const val = (name) => {
    const vals = [...document.querySelectorAll('[data-w95-' + name + ']')].map(n => n.getAttribute('data-w95-' + name));
    const counts = {};
    for (const v of vals) counts[v] = (counts[v] || 0) + 1;
    return { total: vals.length, counts };
  };
  return JSON.stringify({
    statusActive: /Status: ACTIVE/.test(panelText),
    hiddenCount: grab('Items hidden in current session'),
    unidentified: grab('Images left visible because they could not be positively identified'),
    messageList: {
      state: val('state'),
      visual: val('visual'),
      ph: val('ph')
    }
  });
})()`;

// A real click on the checkbox whose row carries this exact label.
const CLICK_CHECKBOX = (label) => `(() => {
  const ds = [...${DIALOG}];
  const d = ds.find(x => /HideEmbeds Settings/.test(x.textContent || ''));
  if (!d) return 'no dialog';
  for (const inp of d.querySelectorAll('input[type=checkbox]')) {
    let n = inp, t = '';
    for (let i = 0; i < 6 && n; i++) {
      const c = (n.textContent || '').trim();
      if (c && c.length < 120) { t = c; break; }
      n = n.parentElement;
    }
    if (t === ${JSON.stringify(label)}) {
      const before = inp.checked;
      inp.click();
      return 'toggled ' + t + ' ' + before + '->' + inp.checked;
    }
  }
  return 'label not found: ' + ${JSON.stringify(label)};
})()`;

const MODE_SELECTORS = `(() => {
  const ds = [...${DIALOG}];
  const d = ds.find(x => /HideEmbeds Settings/.test(x.textContent || ''));
  const out = [];
  for (const el of d.querySelectorAll('*')) {
    const t = (el.textContent || '').trim();
    if (['compact', 'blurred', 'collapsed'].includes(t) && el.children.length === 0) {
      out.push({ tag: el.tagName, cls: (el.className || '').toString().slice(0, 60), role: el.getAttribute('role'), text: t });
    }
  }
  return JSON.stringify(out);
})()`;

const CLICK_MODE = (mode) => `(() => {
  const ds = [...${DIALOG}];
  const d = ds.find(x => /HideEmbeds Settings/.test(x.textContent || ''));
  for (const el of d.querySelectorAll('*')) {
    if ((el.textContent || '').trim() === ${JSON.stringify(mode)} && el.children.length === 0) {
      const target = el.closest('[role=button],button,label,div') || el;
      target.click();
      return 'clicked mode ' + ${JSON.stringify(mode)} + ' on ' + target.tagName + '.' + (target.className || '').toString().slice(0, 50);
    }
  }
  return 'mode not found: ' + ${JSON.stringify(mode)};
})()`;

const CLICK_BTN = (text) => `(() => {
  const ds = [...${DIALOG}];
  const d = ds.find(x => /HideEmbeds Settings/.test(x.textContent || ''));
  for (const b of d.querySelectorAll('button')) {
    if ((b.textContent || '').trim() === ${JSON.stringify(text)}) { b.click(); return 'clicked ' + ${JSON.stringify(text)}; }
  }
  return 'button not found: ' + ${JSON.stringify(text)};
})()`;

const SETTINGS_STATE = `(() => {
  const ds = [...${DIALOG}];
  const d = ds.find(x => /HideEmbeds Settings/.test(x.textContent || ''));
  const out = {};
  for (const inp of d.querySelectorAll('input[type=checkbox]')) {
    let n = inp, t = '';
    for (let i = 0; i < 6 && n; i++) {
      const c = (n.textContent || '').trim();
      if (c && c.length < 120) { t = c; break; }
      n = n.parentElement;
    }
    out[t] = inp.checked;
  }
  for (const el of d.querySelectorAll('*')) {
    const t = (el.textContent || '').trim();
    if (['compact', 'blurred', 'collapsed'].includes(t) && el.children.length === 0) {
      const holder = el.closest('[aria-pressed=true], [aria-checked=true], .w95-mode-active, [class*=active]');
      if (holder) out['mode'] = t;
    }
  }
  return JSON.stringify(out);
})()`;

const wait = (ms) => new Promise((r) => setTimeout(r, ms));

async function main() {
  const t = (await pageTargets(PORT))[0];
  const c = connect(t);
  await c.ready;
  await c.send('Runtime.enable');

  const step = async (name, expr, settle) => {
    const res = await ev(c, expr);
    await wait(settle || 1800);
    const obs = JSON.parse(await ev(c, OBSERVE));
    const st = JSON.parse(await ev(c, SETTINGS_STATE));
    console.log('--- ' + name + ' ---');
    console.log('  action : ' + res);
    console.log('  panel  : ' + JSON.stringify(st));
    console.log('  observe: ' + JSON.stringify(obs.messageList) +
                ' hidden=' + obs.hiddenCount + ' active=' + obs.statusActive);
    return { obs, st };
  };

  const start = await step('00 entry (baseline)', '(()=>"baseline")()', 200);
  console.log('mode selectors: ' + await ev(c, MODE_SELECTORS));

  // 1. Hide rich link preview cards: false -> true
  await step('01 toggle "Hide rich link preview cards" ON',
             CLICK_CHECKBOX('Hide rich link preview cards'), 2200);

  // 2. Placeholder mode compact -> blurred
  await step('02 placeholder mode -> blurred', CLICK_MODE('blurred'), 2200);
  await step('03 placeholder mode -> collapsed', CLICK_MODE('collapsed'), 2200);
  await step('04 placeholder mode -> compact (restore)', CLICK_MODE('compact'), 2200);

  // 3. Session reveal
  await step('05 Reveal all hidden media for this session',
             CLICK_BTN('Reveal all hidden media for this session'), 2500);
  await step('06 Hide all again (restore)', CLICK_BTN('Hide all again'), 2500);

  // Restore the checkbox we flipped.
  await step('07 restore "Hide rich link preview cards" OFF',
             CLICK_CHECKBOX('Hide rich link preview cards'), 2200);

  const end = await step('08 final (should equal baseline)', '(()=>"final")()', 400);

  console.log('=== RESTORE CHECK ===');
  console.log('baseline panel : ' + JSON.stringify(start.st));
  console.log('final panel    : ' + JSON.stringify(end.st));
  console.log('baseline hidden : ' + start.obs.hiddenCount + '  final hidden : ' + end.obs.hiddenCount);
  console.log('baseline visual : ' + JSON.stringify(start.obs.messageList.visual) +
              '  final visual : ' + JSON.stringify(end.obs.messageList.visual));

  c.close();
}

main().catch((e) => { console.error('FAILED: ' + (e && e.message ? e.message : String(e))); process.exit(2); });