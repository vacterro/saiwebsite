'use strict';
// T-376 phase 2: is there a real rich link preview card anywhere in this
// channel's reachable history? The "Hide rich link preview cards" clause can
// only be observed on an actual card, so find one or prove there is none.
//
// Read-only: this scrolls the message list and counts. It clicks nothing.

const { pageTargets, connect } = require('../../tools/cdp-client.js');

const PORT = Number(process.env.BD_CDP_PORT || 9223);

async function ev(c, e) {
  const r = await c.send('Runtime.evaluate', { expression: e, returnByValue: true });
  if (r.exceptionDetails) {
    throw new Error((r.exceptionDetails.exception && r.exceptionDetails.exception.description) || r.exceptionDetails.text);
  }
  return r.result.value;
}

const CARDS = `(() => {
  const list = document.querySelector('[id^=chat-messages], [class*=messageList]');
  const rows = [...document.querySelectorAll('[id^=chat-messages]')];
  const cardSel = [
    '[class*="messageEmbed"]',
    '[class*="embedWrapper"]',
    '[class*="embedContent"]',
    '[class*="embeds"]',
    '[class*="linkEmbed"]',
    'a[class*="link"][href^="http"]',
    '[class*="messageReference"]'
  ].join(',');
  const cards = [...document.querySelectorAll(cardSel)];
  const list1 = [...document.querySelectorAll('[class*="messageEmbed"], [class*="embedWrapper"], [class*="embeds"]')];
  const anchors = [...document.querySelectorAll('a[href^="http"]')].map(a => ({
    href: (a.getAttribute('href') || '').slice(0, 90),
    cls: (a.className || '').toString().slice(0, 60),
    inRow: !!a.closest('[id^=chat-messages]')
  }));
  const w95embed = [...document.querySelectorAll('[data-w95-embed]')].map(e => ({
    v: e.getAttribute('data-w95-embed'),
    cls: (e.className || '').toString().slice(0, 70),
    text: (e.textContent || '').trim().slice(0, 80)
  }));
  return JSON.stringify({
    rows: rows.length,
    cardNodes: cards.length,
    embedNodes: list1.length,
    scrollTop: list ? Math.round(list.scrollTop) : null,
    scrollHeight: list ? Math.round(list.scrollHeight) : null,
    clientHeight: list ? Math.round(list.clientHeight) : null,
    httpAnchors: anchors.slice(0, 12),
    w95embed
  }, null, 1);
})()`;

const SCROLL_TOP = `(() => {
  const list = document.querySelector('[id^=chat-messages]') || document.querySelector('[class*=messageList]');
  if (!list) return 'no list';
  const before = list.scrollTop;
  list.scrollTop = 0;
  list.dispatchEvent(new Event('scroll', { bubbles: true }));
  return 'scrollTop ' + Math.round(before) + ' -> ' + Math.round(list.scrollTop);
})()`;

const wait = (ms) => new Promise((r) => setTimeout(r, ms));

(async () => {
  const t = (await pageTargets(PORT))[0];
  const c = connect(t);
  await c.ready;
  await c.send('Runtime.enable');

  console.log('--- as loaded ---');
  console.log(await ev(c, CARDS));

  console.log('--- scrolled to top of loaded history ---');
  console.log(await ev(c, SCROLL_TOP));
  await wait(3000);
  console.log(await ev(c, CARDS));

  c.close();
})().catch((e) => { console.error('FAILED: ' + (e && e.message ? e.message : String(e))); process.exit(2); });