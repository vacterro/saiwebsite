'use strict';
// Identify what the two elements matching the loose embed selector actually are,
// and where they sit. One focused look; if none of them is a genuine link
// preview card the rich-card clause is reported as unobserved rather than
// argued into existence.

const { pageTargets, connect } = require('../../tools/cdp-client.js');

const PORT = Number(process.env.BD_CDP_PORT || 9223);
const CARD_SEL = '[class*="messageEmbed"], [class*="embedWrapper"], [class*="embedFull"], [class*="embeds"]';

async function ev(c, e) {
  const r = await c.send('Runtime.evaluate', { expression: e, returnByValue: true });
  if (r.exceptionDetails) {
    throw new Error((r.exceptionDetails.exception && r.exceptionDetails.exception.description) || r.exceptionDetails.text);
  }
  return r.result.value;
}

const WHAT = `(() => {
  const cards = [...document.querySelectorAll(${JSON.stringify(CARD_SEL)})];
  return JSON.stringify(cards.map(c => {
    const r = c.getBoundingClientRect();
    return {
      cls: (c.className || '').toString().slice(0, 70),
      rect: [Math.round(r.x), Math.round(r.y), Math.round(r.width), Math.round(r.height)],
      anchors: [...c.querySelectorAll('a[href^="http"]')].map(a => (a.getAttribute('href') || '').slice(0, 70)),
      imgs: c.querySelectorAll('img').length,
      text: (c.textContent || '').trim().slice(0, 100),
      visible: getComputedStyle(c).display !== 'none' && r.width > 0 && r.height > 0
    };
  }), null, 1);
})()`;

// Every rich link preview Discord renders, under any of its generated names.
const ALL_CARDISH = `(() => {
  const sels = ['[class*="messageEmbed"]','[class*="embedWrapper"]','[class*="embedFull"]','[class*="embedDefault"]',
                '[class*="embedLink"]','[class*="embedContainer"]','[class*="embed"]','[class*="linkPreview"]'];
  const seen = new Set(); const out = [];
  for (const s of sels) {
    for (const e of document.querySelectorAll(s)) {
      if (seen.has(e)) continue; seen.add(e);
      const r = e.getBoundingClientRect();
      if (r.height < 20) continue;
      const a = [...e.querySelectorAll('a[href^="http"]')];
      out.push({ sel: s, cls: (e.className||'').toString().slice(0,60), y: Math.round(r.y), h: Math.round(r.height), links: a.length, href: a[0] ? (a[0].getAttribute('href')||'').slice(0,80) : null });
    }
  }
  return JSON.stringify(out.slice(0, 20), null, 1);
})()`;

(async () => {
  const t = (await pageTargets(PORT))[0];
  const c = connect(t);
  await c.ready;
  await c.send('Runtime.enable');
  console.log('what matched: ' + await ev(c, WHAT));
  console.log('all cardish: ' + await ev(c, ALL_CARDISH));
  c.close();
})().catch((e) => { console.error('FAILED: ' + (e && e.message ? e.message : String(e))); process.exit(2); });