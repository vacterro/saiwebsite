# OUTBOX

## W-011: Wintage wiki FORCE-FRESH rebind at c62d89d, v1.36.6 restamp + reddit/lean-CSS + honest target table
- **status:** ready
- **summary:** FORCE-FRESH re-verification of the full 8-page wiki at v1.36.6 (HEAD c62d89d), twelve commits past W-010's 82178cd binding. Version stamps moved to 1.36.6 (Home.md, _Footer.md). Desktop.md REVERSES W-010's own error: `antigravity-app` is a live target (an Electron relocation target, the Antigravity agent app, separate from the `antigravity` IDE) and W-010 had deleted its row on a wrong "no such target exists" reading; the missing `processexplorer` row is added and the `cinema4d` "survives an app update: yes" cell is corrected to no. Known-Behaviors.md rewritten where it contradicted the code: the safety guard's real mechanism (whole-URL case-insensitive patterns, with the bot-challenge and flipbook additions), the high-churn lean CSS-only path (X, Reddit, ChatGPT, Claude, Gemini, Qwen, Perplexity) added as a behaviour, the CSSOM `:hover` stripping qualified as inert on those hosts, the media-skip clause narrowed to colour, and the cross-origin bullet corrected — the 99,999s hover-freeze fallback it described was removed and no longer exists. Development.md: `build-desktop.js --check` is not the release gate (release rebuilds), the three `--check` importers are named, the gates list is corrected to what release.ps1 actually runs, the ADR range is ADR-001..010 with what 007..010 cover, the `browser-theme/` line is corrected to the localized README bundle, and the contributor-only `package.json`/`package-lock.json` manifest is documented. Installation.md step 3 qualified by the guard and the lean hosts. Palettes.md re-verified unchanged (16 palettes, 21 tokens, 10/10 hex match). The repo wiki/ mirror is expected to lag until qqq; `node tools/check-wiki-mirror.js` will be RED between this prepare and the collect, by design.
- **main_project_refs:** [wiki/Home.md, wiki/Installation.md, wiki/Palettes.md, wiki/Desktop.md, wiki/Known-Behaviors.md, wiki/Development.md, wiki/_Footer.md, CHANGELOG.md, wintage.user.js, desktop/install.ps1, desktop/modules/targets.ps1, release.ps1, tools/check-wiki-mirror.js]
- **critical:** false
- **severity:** P2
- **producer:** saiwiki
- **source_head:** c62d89df77ecc219204d183130955685edba7d4b
- **source_tree_fingerprint:** git-delta-v1:58c4eeac0159372d783c452a5aadb89f631484fe3c30205bf4d4c89bedbc92ec
- **role_revision:** sha256:54a42475a124ab0f27e83d600a284a9cc54d9668029c4828cfc48512b031df13
- **coverage:** All 8 maintained wiki pages (Home, Installation, Palettes, Desktop, Known-Behaviors, Development, _Sidebar, _Footer) - 100% of wiki surface.
- **payload:** .saipen/extensions/subs/saiwiki/kitchen/wiki/*.md (8 pages)
- **verified:** PASS -- 8/8 kitchen pages non-empty; no unresolved internal link and no stale version string (grep for 1.34/1.35/1.36.0 finds none); the version stamp 1.36.6 in Home.md and _Footer.md equals `@version` and `const W95_VERSION` (both read at wintage.user.js:4 and :686) and the latest CHANGELOG release heading (1.36.6, 2026-10-03); Palettes.md saying "sixteen palettes" equals the 16-key THEMES registry, which is exactly the 16 `themes/*.json` packs, and its 10-row hex table matches themes/goldendefault.json (21 tokens) with 0 mismatches in 10 rows; Desktop.md's target table now cites exactly the 22 live ValidateSet keys (desktop/install.ps1:21) with no key outside it and none uncovered; the `antigravity-app` and `processexplorer` definitions read directly at desktop/install.ps1:160-164 and :1028-1029 and the cinema4d install-tree write read at desktop/modules/targets.ps1:3217-3223/3367-3387; the lean-CSS claims read at wintage.user.js:229/251-252/736/4582 and the removed hover freeze at :898-905; source identity recomputed with freshness.compute_source_identity on this tree; role revision taken unchanged from the charter.
- **instructions:** For qqq (Core `saipen collect saiwiki` then ship): copy `.saipen/extensions/subs/saiwiki/kitchen/wiki/*.md` over `wiki/*.md`, adapting bare internal links to `*.md` -- the ONLY permitted difference (tools/check-wiki-mirror.js); then run `node tools/check-wiki-mirror.js` (must exit 0). That gate is RED between this prepare and the collect because the kitchen has moved ahead of the mirror, which is the expected lag; it is not a defect of this package. Commit and ship. This role pushed nothing and wrote nothing into the main tree.
- **details:**
  Docs drift since W-010 (82178cd, v1.36.0): twelve commits, and the wiki still stamped 1.36.0. Four families of drift were found and each is named with its evidence rather than smoothed over.
  - **Version stamp.** Home.md and _Footer.md said 1.36.0 (2026-09-16); the product is 1.36.6 (2026-10-03) at wintage.user.js:4/:686 and CHANGELOG.md:579.
  - **W-010 corrected itself.** W-010 recorded "the `antigravity-app` row in the target table (no such target exists in the live listing)" and deleted the row. Both halves of that are wrong: `antigravity-app` IS in the ValidateSet at desktop/install.ps1:21 and IS defined as an Electron relocation target at :160-164 ("Antigravity (agent app, not the IDE)"). `processexplorer` was equally live (:21, :287, :1028) and had no row at all. The row is restored and both are added. The `cinema4d` row claimed "survives an app update: yes"; `Get-Cinema4DSchemesDir` resolves the schemes directory inside the Cinema 4D install tree (desktop/modules/targets.ps1:3217-3223) and `Invoke-Cinema4D` writes there (:3367-3387), so an update replaces it — corrected to no. The `discord` row's "plugins tab manages BetterDiscord add-ons" was also stale: the plugin payloads were deleted (CHANGELOG.md:106-115, ADR-007) and the tab is now a navigation page to github.com/vacterro/BetterDiscord_vac34_plugins (desktop/WintageInstaller.ps1:1138).
  - **The wiki contradicted the code on behaviour.** The safety guard is a case-insensitive pattern test over the whole URL (wintage.user.js:35-49), not a four-category host list, and v1.36.1 widened it with bot-challenge/anti-fraud providers and flipbook hosts while un-flagging localhost (CHANGELOG.md:646-661). Nothing in the wiki described the lean CSS-only path that X, Reddit, ChatGPT, Claude, Gemini, Qwen and Perplexity run (wintage.user.js:251-252), which the Unreleased/adr-010 change made user-visible, so Known-Behaviors.md's repainter, `:hover`-stripping, media-skip and Shadow-DOM bullets all needed the qualifier; the cross-origin bullet described a 99,999-second hover-freeze fallback that no longer exists (removed; wintage.user.js:898-905) and was rewritten to what the code does now.
  - **Development.md described a release that does not exist.** `build-desktop.js --check` is not what release.ps1 runs — it rebuilds (:274); the `--check` variant is the suite's. Eleven directly-invoked release steps were absent from the Gates list, and three `--check` importers (import-fastprompter, derive-palette, apply-themes) were named nowhere. The ADR range said ADR-001..006 while ADR-007..010 exist. The `browser-theme/` line described generated manifests; it is the localized README bundle plus a reference manifest, and the sixteen manifests are generated into desktop/out/browser/<palette>/. The contributor-only `package.json`/`package-lock.json` (Playwright, for the live viewport gate) is now documented, since a fresh clone needs `npm ci` before that gate runs.
  - Re-verified rather than rewritten: Palettes.md (16 palettes, 21 tokens, 10/10 hex), _Sidebar.md, the Installation command block, and every Desktop.md row that was already correct.
  - **Cause of W-010's error is recorded as an unverified reading, not a guess.** The most likely source is that the row was checked against a truncated or stale listing rather than the ValidateSet, but that was not established, so it is stated as what was observed, not as a cause.

## W-010: Wintage wiki FORCE-FRESH rebind at 82178cd, v1.36.0 restamp
- **status:** stale
- **superseded_by:** W-011 (source_head 82178cd -> c62d89d, v1.36.0 -> v1.36.6)
- **summary:** FORCE-FRESH re-verified full 8-page wiki package bound to v1.36.0 HEAD 82178cd. Version stamps moved to 1.36.0 (Home.md, _Footer.md); Desktop.md dropped the non-existent `antigravity-app` target row and now documents the remembered portable-browser discovery plus `-RescanBrowsers`; Installation.md shows the rescan command; Development.md lists the repainter-budget and browser-cache gates. Palettes.md re-verified unchanged (16 palettes, 21 tokens, 10/10 hex match). The repo wiki/ mirror is expected to lag until qqq.
- **main_project_refs:** [wiki/Home.md, wiki/Installation.md, wiki/Palettes.md, wiki/Desktop.md, wiki/Development.md, wiki/_Footer.md, CHANGELOG.md, wintage.user.js, desktop/install.ps1, tools/install-browsers.ps1, tools/check-wiki-mirror.js]
- **critical:** false
- **severity:** P2
- **producer:** saiwiki
- **source_head:** 82178cdfb124ad55f9dccc7cd55ce3a633d51a6c
- **source_tree_fingerprint:** git-delta-v1:c66baf69a8306f3b95dfc7badb5f72b088f8de8408e933efadc4d149721a1195
- **role_revision:** sha256:54a42475a124ab0f27e83d600a284a9cc54d9668029c4828cfc48512b031df13
- **coverage:** All 8 maintained wiki pages (Home, Installation, Palettes, Desktop, Known-Behaviors, Development, _Sidebar, _Footer) - 100% of wiki surface.
- **payload:** .saipen/extensions/subs/saiwiki/kitchen/wiki/*.md (8 pages)
- **verified:** PASS -- 8/8 kitchen pages non-empty; the version stamp 1.36.0 in Home.md and _Footer.md equals wintage.user.js @version and const W95_VERSION; Palettes.md saying "sixteen palettes" equals the 16-entry THEMES registry and its 10-row hex table matches themes/goldendefault.json (21 tokens) with zero mismatches; the Desktop.md target table contains no key outside the live listing and leaves none of the 20 live targets uncovered; no unresolved internal links; source identity recomputed with freshness.compute_source_identity on a clean working tree at 82178cd; role revision recomputed from this charter and unchanged.
- **instructions:** For qqq (Core `saipen collect saiwiki` then ship): copy `.saipen/extensions/subs/saiwiki/kitchen/wiki/*.md` over `wiki/*.md`, adapting bare internal links to `*.md` -- the ONLY permitted difference (tools/check-wiki-mirror.js); then run `node tools/check-wiki-mirror.js` (must exit 0). That gate is RED between this prepare and the collect because the kitchen has moved ahead of the mirror, which is the expected lag E-014 recorded; it is not a defect of this package. Commit and ship. This role pushed nothing and wrote nothing into the main tree.
- **details:**
  Docs drift since W-009 (v1.30.0, 2026-09-02): the wiki still described 1.30.0 while CHANGELOG.md and wintage.user.js are at 1.36.0 (the audit/5.md wave, T-245/T-246). Three facts had drifted: the version stamp, the `antigravity-app` row in the target table (no such target exists in the live listing -- the Electron relocation targets are freebuff, codenomad, workbuddy, zcode plus claude patched in place), and a new user-facing capability with no page describing it (the portable browser root is now remembered, so a status refresh no longer rescans it, and `install.ps1 -RescanBrowsers` / `install-browsers.ps1 -Rescan` is the explicit rescan). Everything else re-verified rather than rewritten: palettes (16/16, token table equal to the Golden Default pack), the target mechanisms table, the userscript behaviours and the deliberate UI.md deviations.

## W-007: Wintage wiki FORCE-FRESH rebind at 8867967
- **status:** stale
- **superseded_by:** WIKI-009
- **summary:** historical v1.26.4-era wiki package; superseded by WIKI-009.
- **producer:** saiwiki
- **source_head:** 886796720f135b12da6bb05ae3fc5e8cf2e411b2
- **source_tree_fingerprint:** git-delta-v1:8f53396e95963bbf98b1b22591605330366eb4b79b8a89274e0d9b4db7d591b6
- **role_revision:** sha256:54a42475a124ab0f27e83d600a284a9cc54d9668029c4828cfc48512b031df13
- **coverage:** 8 wiki pages (Home, Installation, Palettes, Desktop, Known-Behaviors, Development, _Sidebar, _Footer).
- **payload:** .saipen/extensions/subs/saiwiki/kitchen/wiki/*.md (8 pages)
- **verified:** PASS -- legacy run verified
- **instructions:** Superseded by WIKI-009.
- **details:** Historical entry retained for audit log continuity.

## W-008: Wintage wiki FORCE-FRESH rebind at a9399dc9
- **status:** stale
- **superseded_by:** WIKI-009 (source_head a9399dc9 -> ffc13fd at v1.30.0 ship)
- **summary:** historical v1.29.0-era wiki package; superseded by WIKI-009.
- **producer:** saiwiki
- **source_head:** a9399dc9d053b0cd333e0c343fbe6eed26d40185
- **source_tree_fingerprint:** git-delta-v1:3dc46023688daf25f64f1105823dc4f33ba0da21e693b73e8ff88a1da1357209
- **role_revision:** sha256:54a42475a124ab0f27e83d600a284a9cc54d9668029c4828cfc48512b031df13
- **coverage:** 8 wiki pages.
- **payload:** .saipen/extensions/subs/saiwiki/kitchen/wiki/*.md (8 pages)
- **verified:** PASS -- legacy run verified
- **instructions:** Superseded by WIKI-009.
- **details:** Historical entry retained for audit log continuity.

## W-009: Wintage wiki FORCE-FRESH rebind at ffc13fd, v1.30.0 restamp
- **status:** stale
- **superseded_by:** W-010
- **summary:** FORCE-FRESH re-verified full 8-page wiki package bound to v1.30.0 HEAD ffc13fd; version stamps updated to 1.30.0 (Home.md, _Footer.md); Desktop.md carries qbittorrent target + font policy; Palettes.md 10/10 hex match goldendefault.json; repo wiki/ mirror in sync.
- **main_project_refs:** [wiki/Home.md, wiki/Desktop.md, wiki/_Footer.md, README.md, wintage.user.js, themes/goldendefault.json]
- **critical:** false
- **severity:** P2
- **producer:** saiwiki
- **source_head:** ffc13fd5065855239642a6d479806e6c14956814
- **source_tree_fingerprint:** git-delta-v1:c3e75317953761991f3c534a4a146f4085ad51cbfe0d43929ac5417275e93d20
- **role_revision:** sha256:54a42475a124ab0f27e83d600a284a9cc54d9668029c4828cfc48512b031df13
- **coverage:** All 8 maintained wiki pages (Home, Installation, Palettes, Desktop, Known-Behaviors, Development, _Sidebar, _Footer) - 100% of wiki surface.
- **payload:** .saipen/extensions/subs/saiwiki/kitchen/wiki/*.md (8 pages)
- **verified:** PASS -- tools/check-wiki-mirror.js exits 0 (repo wiki/ mirror in sync via adaptForRepo); 8/8 kitchen pages non-empty; version stamp 1.30.0 matches wintage.user.js; Desktop.md covers qbittorrent; Palettes.md matches goldendefault.json.
- **instructions:** For qqq (Core saipen collect saiwiki then ship): copy kitchen pages to repo wiki/ via adaptForRepo (.md link rewrite), verify with check-wiki-mirror.js, commit and push.
- **details:**
  - Re-bound post-v1.30.0 ship to new source_head ffc13fd and source_tree_fingerprint.
  - Home.md and _Footer.md version stamps bumped to 1.30.0 (2026-09-02).
  - Desktop.md includes qbittorrent row + name-never-install font policy.
  - Repo wiki/ mirror synced and validated via node tools/check-wiki-mirror.js.
  - Boundary clean: all kitchen writes inside .saipen/extensions/subs/saiwiki/.
