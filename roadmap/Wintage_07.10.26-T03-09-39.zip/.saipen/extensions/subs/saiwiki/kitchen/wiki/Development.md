# Development & release

## Repository layout

- `wintage.user.js` — the userscript (Tampermonkey). Palettes are embedded by
  `tools/apply-themes.js` inside the `THEMES` registry.
- `themes/*.json` — the sixteen palette packs, the single source of truth for colour.
- `desktop/` — the desktop theme subsystem: `tools/build-desktop.js` fills `${token}`
  templates from the packs, `install.ps1` installs into the user profile,
  `WintageInstaller.ps1` is the WinForms GUI. Generated `desktop/out/` is
  gitignored and rebuilt with `node tools/build-desktop.js`.
- `tools/` — generators and gates: `apply-themes.js`, `derive-palette.js`,
  `check-css.js`, `build-desktop.js`, `electron-fuses.js`, `inspect-electron.js`
  (reads a live themed app over CDP), plus the test harnesses.
- `browser-theme/` — the localized README bundle shipped alongside the staged browser
  theme, plus the reference manifest. The sixteen per-palette Chromium theme manifests
  themselves are generated into `desktop/out/browser/<palette>/` from
  `desktop/targets/browser/template.json`.
- `tests/` — PowerShell test harness (`Run-Tests.ps1`).
- `package.json` / `package-lock.json` — a **contributor-only** manifest. It declares one
  devDependency, Playwright, for the live viewport gate; the userscript itself needs no
  install step. On a fresh clone: `npm ci`, then `npx playwright install chromium`.

## Releasing a new version

Add a `## [x.y.z] - date` entry to the top of `CHANGELOG.md` first — `release.ps1`
refuses to run without it. Then:

```powershell
.\release.ps1 -Message "what changed"
```

It bumps the `@version` patch number (the Tampermonkey header and the `W95_VERSION`
stamp both move together), rebuilds the generated desktop themes, runs the whole
release-gate suite, and commits, tags, and pushes — Tampermonkey clients pick the
update up automatically. Pass `-Bump minor` or `-Bump major` for bigger releases.

## Gates

`release.ps1` refuses to ship unless the generated artifacts are current, then runs the
whole suite. In order:

- `tools/build-desktop.js` — **rebuilds** `desktop/out/` from the packs; a release never
  ships output that has drifted. (The `--check` variant, which only compares and exits,
  is what `tests/Run-Tests.ps1` uses.)
- `tools/check-css.js` — no stray/unclosed/nested comments, brace imbalance, or
  off-palette hex in the CSS bodies; also checks the per-theme WCAG AA floor and
  version stamp consistency.
- `tools/test-theme-switch.js`, `tools/test-spa-exclude.js`, `tools/test-diag-counters.js`
  — palette switching, the SPA route-exclusion guard, and the diagnostic counters.
- `tools/test-perf-bounded.js`, `tools/test-perf-lanes.js`, `tools/test-perf-recovery.js`,
  `tools/test-fs-retry.js` — the bounded-work, lane, recovery and storage-retry
  contracts.
- `tools/test-repainter-polarity.js`, `tools/test-electron-shim.js`,
  `tools/test-theme-packs.js` — repainter polarity, the Electron shim, the packs.
- `tools/import-fastprompter.js --check`, `tools/derive-palette.js --check`,
  `tools/apply-themes.js --check` — the imported, derived and embedded theme artifacts
  match their sources; each names the command to re-run when stale.
- `tools/check-wiki-mirror.js` — the repository `wiki/` mirror matches the saiwiki
  sources (allowing only the bare-link → `.md` adaptation).
- `tools/test-shim-payloads.js`, `tools/test-terminal-font.js` — the Electron shim
  payloads parse, and the terminal colour table stays console-consistent.
- `tests/Run-Tests.ps1` — the full suite, which carries the remaining gates
  (`tools/test-repainter-budget.js`, `tools/test-browser-cache.ps1`, the ChatGPT
  viewport gate and the structural checks).

## Deliberate deviations from UI.md

Transition/animation stay at 0.001s (live evidence beats the literal law); no global
`margin: 0` or `box-sizing`; no `body { overflow-x: hidden }`; no class-name-based
status colours; semantic tokens are never used as text colour (1.8:1 fails AA).
Full reasoning lives in `.saipen/KNOWLEDGE/ADR-001..010` in the source repo — the design
law and its deviations in ADR-001..006, and the process rules in ADR-007..010:
BetterDiscord plugins are maintained outside this repository (ADR-007), a ticket commit
carries only that ticket's scope (ADR-008), a delivery claim must name a path the
artifact contains (ADR-009), and Reddit is a high-churn host that runs the lean CSS-only
path (ADR-010). `.saipen/KNOWLEDGE/INDEX.md` lists them.
