# Wintage

**Win95 Dark Golden Vintage theme for the whole web.** A Tampermonkey userscript
that restyles every site into a dark golden-brown Windows 95 application:
pixel-sharp 3D bevels, zero rounded corners, zero animations, no hover flashbangs,
Verdana everywhere.

The modern web optimizes for aesthetics at the expense of usability. Wintage brings
back explicit visual language: raised buttons, sunken inputs, sharp boundaries,
consistent typography, zero distractions, and immediate state changes. Every
element communicates its purpose at a glance.

## Quick facts

- **Current version:** 1.36.6 (2026-10-03)
- **Palettes:** sixteen, switchable per user from the Tampermonkey menu
- **Scope:** every site, plus desktop applications (see [Desktop](Desktop))
- **High-churn hosts** (X, Reddit, ChatGPT, Claude, Gemini, Qwen, Perplexity) run a
  lean CSS-only path instead of the live repainter (see [Known behaviors](Known-Behaviors))
- **License:** MIT

## Install

1. Install [Tampermonkey](https://www.tampermonkey.net/) (Chrome, Edge, Firefox, Opera, Safari).
2. Click **[Install Wintage](https://raw.githubusercontent.com/vacterro/Wintage/main/wintage.user.js)**.
3. Done.

Full instructions: [Installation](Installation)

## Pages

- [Installation](Installation)
- [Palettes](Palettes)
- [Desktop applications](Desktop)
- [Known behaviors](Known-Behaviors)
- [Development & release](Development)
