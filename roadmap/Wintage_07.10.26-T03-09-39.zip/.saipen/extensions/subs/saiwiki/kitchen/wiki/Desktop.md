# Desktop applications

The userscript themes the web. `desktop/` themes the programs around it, from the
same palettes, so the browser and the apps stop disagreeing about what dark golden
means.

One rule behind every decision: **applications update themselves, and an update must
not quietly break anything.** Where a target has a place in your own profile, the
theme goes there and survives updates. Where it does not, the installer is written to
be re-run — and says so, rather than pretending it persisted.

## The GUI

Double-click **`Wintage Installer.vbs`** in the repo root to open it without a
console window, or run directly for diagnostics:

```powershell
powershell -File desktop\WintageInstaller.ps1
```

Theme list with colour chips, the targets found on this machine, a live Win95
preview, and all twenty-one colour tokens as editable swatches. Editing any swatch
forks the palette into **Custom**. A live WCAG panel shows contrast for the three
text-bearing tokens before Apply.

Targets are split into two keyboard-reachable lists: **MY APPS** (CodeNomad,
WorkBuddy) and **POPULAR APPS** (Windows, OBS, terminals, editors and other
installed software). ALL/NONE and Apply/Revert operate across both lists without
changing their grouping.

## What each target can actually be themed

| target | mechanism | survives an app update |
|---|---|---|
| `windows` | user `.theme`: dark system/app mode, accent and classic colour roles | yes |
| `browsers` | detects Chromium profiles, stages the chrome theme, opens browser-owned confirmation pages. Portable discovery is remembered, so a status refresh does not rescan the portable root (`-RescanBrowsers` to rescan on purpose) | yes after one **Load unpacked** per profile |
| `terminal` | Windows Terminal scheme + all-profile defaults, Terminus (TTF) for Windows | yes |
| `conhost` | `HKCU\Console` defaults + every existing cmd/PowerShell profile (colours, font, 9001-line scrollback floor) | yes |
| `obs` | OBS 30.2+ `.ovt` variant + active `user.ini` theme ID | yes |
| `qbittorrent` | unpacked Qt UI theme (`config.json` + `stylesheet.qss`) + the two `qBittorrent.ini` theme keys | yes |
| `antigravity`, `vscode` | colour-theme extension in the extensions folder | **yes** |
| `freebuff`, `codenomad`, `workbuddy`, `zcode` | Electron shim (relocation) | no — re-run the installer |
| `antigravity-app` | Electron shim (relocation). The Antigravity **agent** app — a separate program from the `antigravity` IDE, themed separately | no — re-run the installer |
| `claude` | Electron shim, patched in place | no — an update makes a new folder |
| `mpchc` | registry, dark theme + OSD typography only | no — MPC-HC rewrites settings on exit |
| `processexplorer` | `HKCU` colour table, for whichever portable Process Explorer copy you point it at | yes — but close Process Explorer first; it holds its colours in memory and rewrites them on exit |
| `qbittorrent`/`obs`/`mpchc` fonts | the themes NAME `Verdana_m1` (the no-antialias face); the installer never installs or removes fonts | n/a — install the face once by hand |
| `obsidian` | community theme per vault, all palettes installed at once | **yes** |
| `notepadplusplus` | XML theme dropped into themes folder | yes |
| `cinema4d` | scheme folder dropped into Cinema 4D's `resource\modules\...\schemes` directory, inside its install tree | no — an update replaces the install tree, so re-run the installer |
| `discord` | CSS dropped into BetterDiscord's own theme folder. The installer's BetterDiscord tab is a navigation page linking the canonical plugin repository, `github.com/vacterro/BetterDiscord_vac34_plugins` — no plugin payload ships in this repo | yes |
| `totalcmd`, `totalcmd2` | `wincmd.ini` `[Colors]` keys | yes |

### Portable browsers

Chromium builds that are not installed the usual way live under a *portable root*
that you point the installer at once. Scanning that root can mean walking an entire
software directory, so Wintage remembers the browser candidates it found and
revalidates them cheaply on every later status refresh — a browser that has since
been removed is dropped, never reported. To make it look for browsers added under
the same root afterwards, ask for a rescan:

```powershell
.\desktop\install.ps1 -RescanBrowsers                        # rescan the remembered root
.\tools\install-browsers.ps1 -Rescan -PortableRoot D:\apps    # rescan directly
```

## Electron apps

`resources/app.asar` is moved to `resources/app/app.asar` (its `app.asar.unpacked`
sibling moves with it — that pairing is by filename), and a small `shim.cjs` takes
the vacated `resources/app` slot. The shim injects the stylesheet and then loads the
original archive. **No application byte is rewritten**, only relocated; `-Revert`
moves it straight back.

The stylesheet is not written for these apps — it is extracted from
`wintage.user.js`, so every bevel, scrollbar and type-ladder fix made for the browser
lands here too.

### Claude's desktop app: in-place

Claude cannot use relocation, because `OnlyLoadAppFromAsar` is fused on. It is
patched **in place**: the archive is backed up, its `package.json` `main` is
rewritten to the shim (padded to the same byte length, so every offset stays valid),
and the per-file integrity hash is updated to match. `-Revert` restores the backup.

Claude's `BrowserWindow` renders a thin shell and the entire visible application is a
`WebContentsView` — the shim hooks `web-contents-created`, which covers window
contents, `WebContentsView`s, `BrowserView`s, `<webview>` guests and popups alike.

## Terminals

`terminal` writes a `Wintage` colour scheme into every detected Windows Terminal
settings file and selects it through `profiles.defaults`, together with
console-safe Terminus (TTF) for Windows. `conhost` covers classic `cmd.exe`,
Windows PowerShell, Git CMD/Bash profiles and other `HKCU\Console` children,
writing the palette's full 16-colour table, the Terminus (TTF) for Windows font,
and a 9001-line screen-buffer floor (some launchers create cmd/PowerShell
profiles whose buffer height equals the window height — zero scrollback) while
restoring only the values it touched. It applies Consolas there too, because
proportional Verdana collides inside the fixed-width cell grid used by both
terminal hosts.

## Rebuilding

Everything under `desktop/out/` is generated from `themes/*.json`. It is not
tracked in git, so a fresh clone must build it once before installing:

```powershell
node ..\tools\build-desktop.js          # rebuild all targets
node ..\tools\build-desktop.js --check  # exit 1 if anything is stale
```

`release.ps1` runs the build and every gate, so a release cannot ship output that has
drifted from the palettes.
