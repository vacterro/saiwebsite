Wintage v1.36.6 · MIT License · [Source](https://github.com/vacterro/Wintage) · [Changelog](https://github.com/vacterro/Wintage/blob/main/CHANGELOG.md)
