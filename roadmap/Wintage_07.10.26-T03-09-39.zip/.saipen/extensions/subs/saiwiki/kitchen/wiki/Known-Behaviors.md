# Known behaviors

- **Hover effects built in JavaScript** (class toggling rather than CSS `:hover`) may
  still show their own highlight — the script only strips readable `:hover` CSS rules.
- **Cross-origin stylesheets**: the hover stripping walks `document.styleSheets`, and a
  cross-origin sheet's rules cannot be read from the page. Its `:hover` paint is
  therefore left alone — a hover flashbang can survive on a site that hosts its CSS on
  another origin. (Older versions papered over this with a 99,999-second transition
  freeze on every hovered element; that is gone, because its compositor cost was worse
  than the flashbang.)
- **Static by design**: no options panel, no per-site toggles. Fork it and edit the
  tokens at the top if you want a different flavor.
- **Safety guard**: the script disables itself where a critical flow would be restyled.
  The guard is a case-insensitive pattern match on the whole URL — not a host-suffix
  check — and it covers OAuth (`/oauth`, Google and Microsoft sign-in), captcha and bot
  challenges (generic captcha, Arkose/FunCaptcha, Cloudflare challenges and Turnstile,
  Kasada, PerimeterX), banking, and the payment providers it knows (PayPal, Stripe).
  Navigating inside a single-page app into a guarded URL reloads the page so the guard
  takes effect there too.
- **High-churn hosts run the lean CSS-only path**: X, Reddit, ChatGPT, Claude, Gemini,
  Qwen and Perplexity get a static stylesheet instead of the live repainter. The
  repainter, its observers and the CSSOM `:hover` surgery are all switched off there;
  the bevels, the type ladder and the palette still apply, but a surface the site tints
  itself after load is not converted, and a `:hover` rule the site ships is not stripped.
  Reddit additionally carries a dedicated stylesheet of its own. The style inspector
  reports the reason as `reddit-lean-css` / `chatgpt-lean-css` /
  `known-high-churn-host`.

## What the script touches

- Dark golden palette — solid flat surfaces only: no gradients, no blur, no transparency.
- Classic 3D bevels — buttons raised, inputs sunken, pressed buttons push in (with
  the authentic 1px label shift). Scrollbars are full Win95-style.
- `border-radius: 0` enforced everywhere, including framework CSS variables.
- All transitions and animations zeroed; state changes are instant.
- Hover highlighting disabled completely — paint properties stripped from every
  readable `:hover` rule; functional properties (`display`/`visibility`/`opacity`)
  are kept so hover-opened menus still work. The stripping is live CSSOM surgery, so
  on the high-churn hosts above (which run CSS-only) it does not run at all.
- Verdana forced everywhere (inputs and textareas included, font smoothing
  disabled); icon fonts excluded so glyphs don't turn into letters. A custom font
  installed as `Verdana_m1` is used automatically.
- Adaptive repainter converts light surfaces and unthemed dark-mode grays into the
  vintage brown scale and fixes low-contrast text at WCAG-aware thresholds. Images,
  videos, canvases and known players are skipped for colour, though the universal
  invariants (`border-radius: 0`, no shadows, the type ladder) still reach them. On
  the high-churn hosts above the repainter does not run at all.
- Shadow DOM piercing themes web components too (YouTube, Reddit, and friends) via an
  `attachShadow` hook that styles each new root as it is created. On the high-churn
  hosts above the per-root repaint observer on top of that is off; the creation-time
  stylesheet still applies.
- Popups (menus, dialogs, tooltips, hovercards) are recolored only; the script never
  forces `opacity`/`z-index`/`visibility`, so hidden site UI stays hidden.
