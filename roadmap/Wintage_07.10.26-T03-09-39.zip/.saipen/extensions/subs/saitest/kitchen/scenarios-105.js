#!/usr/bin/env node
// TEST-105 scenario driver -- T-341, adversarially re-runs the v1.36.2 ChatGPT
// Web shell gate (tools/test-chatgpt-2026.js) that shipped in the working tree.
//
// SAFETY: every scenario runs against a COPY in kitchen/fixtures/. The
// project's own wintage.user.js is opened read-only and never written.
//
// The gate resolves its input as path.join(__dirname, '..', 'wintage.user.js'),
// so each scenario gets its own two-file tree: <case>/tools/<gate copy> beside
// <case>/wintage.user.js. The gate bytes are copied VERBATIM from the real
// tool -- the defect under test is the gate, not a re-implementation of it.

const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');

const KITCHEN = __dirname;
const FIXTURES = path.join(KITCHEN, 'fixtures');
// kitchen -> saitest -> subs -> extensions -> .saipen -> project root
const ROOT = path.join(KITCHEN, '..', '..', '..', '..', '..');
const REAL_GATE = path.join(ROOT, 'tools', 'test-chatgpt-2026.js');
const REAL_SCRIPT = path.join(ROOT, 'wintage.user.js');
const REAL_CHECK_CSS = path.join(ROOT, 'tools', 'check-css.js');

const results = [];
function verdict(id, family, state, extra) {
  results.push(Object.assign({ id, family, state }, extra || {}));
}

function freshTree(name) {
  const dir = path.join(FIXTURES, name);
  fs.rmSync(dir, { recursive: true, force: true });
  fs.mkdirSync(path.join(dir, 'tools'), { recursive: true });
  fs.copyFileSync(REAL_GATE, path.join(dir, 'tools', 'test-chatgpt-2026.js'));
  return dir;
}

function runGate(dir) {
  try {
    const out = execFileSync(process.execPath, [path.join(dir, 'tools', 'test-chatgpt-2026.js')], {
      encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'], timeout: 60000
    });
    return { exit: 0, out };
  } catch (e) {
    return { exit: e.status === undefined ? -1 : e.status, out: (e.stdout || '') + (e.stderr || '') };
  }
}

const real = fs.readFileSync(REAL_SCRIPT, 'utf8');

// ─── The ChatGPT override block, located by its own boundaries ──────────────
const BLOCK_START = '  html[data-w95-chatgpt="1"] {';
const BLOCK_END = 'html[data-w95-chatgpt="1"] #page-header button[aria-pressed="true"] {';
const start = real.indexOf(BLOCK_START);
const endAnchor = real.indexOf(BLOCK_END);
// Walk to the rule's OWN closing brace by depth. A plain indexOf('}') from the
// first '{' after the anchor lands on the closing brace of a ${B_INNER}
// interpolation, not the rule's -- which silently spliced S3's injected rules
// INSIDE the last rule's body, so the fixture tested nothing.
const end = (() => {
  if (endAnchor < 0) return -1;
  let depth = 0;
  for (let k = endAnchor; k < real.length; k++) {
    if (real[k] === '{') depth++;
    else if (real[k] === '}') { depth--; if (depth === 0) return k + 1; }
  }
  return -1;
})();
if (start < 0 || end < 0) {
  console.error('FATAL: could not locate the ChatGPT override block in wintage.user.js');
  process.exit(2);
}
const BLOCK = real.slice(start, end);
console.log('located ChatGPT override block: bytes ' + start + '..' + end +
  ' (' + BLOCK.split('\n').length + ' lines)\n');

// Every literal the gate greps for, taken from the gate itself so the fixture
// cannot drift from it.
const GATE_LITERALS = [
  'data-w95-chatgpt', '#app-shell-sidebar', '[data-composer-dark]', '[data-composer-body]',
  '[data-testid="prompt-textarea"]', '[data-user-message-bubble="true"]',
  '[data-markdown-copy="code-block"]', '#thread-bottom-container::after',
  '--chat-background-color:', '--app-color-background-surface:', '--color-surface:',
  '--color-background-panel:', '--color-token-main-surface-primary:',
  '--color-token-side-bar-background:', '--composer-background-color:',
  '--user-message-background-color:', '--codeblock-background-color:',
  '--color-token-text-code-block-background:',
  '#stage-slideover-sidebar', '#stage-sidebar-tiny-bar',
  'const HIGH_CHURN_HOST = IS_X || IS_CHATGPT', 'const CSS_ONLY_MODE = HIGH_CHURN_HOST'
];

// ─── S1: the gate passes on a file that themes ChatGPT not at all ───────────
// Family: adversarial content (a check that passes by reading its own fixture).
// The whole override is deleted and replaced by one CSS comment that names
// every string the gate looks for. The gate cannot tell the difference.
{
  const dir = freshTree('s1-comment-only');
  const body = '  /* ChatGPT 2026 contract (retired): ' + GATE_LITERALS.join(' ') + ' */';
  const mutant = real.slice(0, start) + body + real.slice(end);
  fs.writeFileSync(path.join(dir, 'wintage.user.js'), mutant);
  const r = runGate(dir);
  const cssLeft = /html\[data-w95-chatgpt="1"\][^{]*\{/.test(mutant.slice(start, start + 400));
  verdict('S1', 'adversarial-content', r.exit === 0 ? 'REPRODUCED' : 'NOT_REPRODUCED', {
    claim: 'deleting the entire ChatGPT override still passes tools/test-chatgpt-2026.js',
    command: 'node .saipen/extensions/subs/saitest/kitchen/fixtures/s1-comment-only/tools/test-chatgpt-2026.js',
    exit: r.exit,
    tail: r.out.trim().split('\n').slice(-1)[0],
    removed_block_lines: BLOCK.split('\n').length,
    live_rule_survives: cssLeft
  });
}

// ─── S2: token values can be neutered and the gate stays green ─────────────
// Family: input abuse (a valid-shaped value that carries no theme at all).
// `inherit` is a legal declaration value; a rule written with it themes
// nothing, and the gate only ever asks whether the token NAME is present.
{
  const dir = freshTree('s2-inherit-tokens');
  let n = 0;
  const neutered = BLOCK.replace(/(--[a-z0-9-]+:\s*)\$\{T\.[A-Za-z]+\}/gi, (m, p1) => { n++; return p1 + 'inherit'; });
  const mutant = real.slice(0, start) + neutered + real.slice(end);
  fs.writeFileSync(path.join(dir, 'wintage.user.js'), mutant);
  const r = runGate(dir);
  verdict('S2', 'input-abuse', r.exit === 0 && n > 0 ? 'REPRODUCED' : 'NOT_REPRODUCED', {
    claim: 'replacing every themed token value with `inherit` still passes the gate',
    command: 'node .saipen/extensions/subs/saitest/kitchen/fixtures/s2-inherit-tokens/tools/test-chatgpt-2026.js',
    exit: r.exit,
    declarations_neutered: n,
    tail: r.out.trim().split('\n').slice(-1)[0]
  });
}

// ─── S3: the two retired-selector bans are evaded by re-spelling ───────────
// Family: input abuse (a value containing the field, written differently).
// `[class*="composer" i]` and `div.sticky.bottom-0` are banned as exact
// substrings. The same over-broad matches spelled without the `i` flag and as
// an attribute selector are not caught.
{
  const dir = freshTree('s3-ban-evasion');
  const broad = [
    '  html[data-w95-chatgpt="1"] [class*="composer"] { color: ${T.textPrimary} !important; }',
    '  html[data-w95-chatgpt="1"] div.sticky[class~="bottom-0"] { background-color: ${T.background} !important; }'
  ].join('\n');
  const mutant = real.slice(0, end) + '\n' + broad + real.slice(end);
  fs.writeFileSync(path.join(dir, 'wintage.user.js'), mutant);
  const r = runGate(dir);
  verdict('S3', 'input-abuse', r.exit === 0 ? 'REPRODUCED' : 'NOT_REPRODUCED', {
    claim: 'an over-broad composer/sticky-bottom selector that avoids both banned spellings still passes',
    command: 'node .saipen/extensions/subs/saitest/kitchen/fixtures/s3-ban-evasion/tools/test-chatgpt-2026.js',
    exit: r.exit,
    added_selectors: ['[class*="composer"]', 'div.sticky[class~="bottom-0"]'],
    tail: r.out.trim().split('\n').slice(-1)[0]
  });
}

// ─── S4: brace damage inside the ChatGPT block -- is anything else watching? ─
// Family: damaged state. Asks the COVERAGE question, not a new bug: the gate
// under test is a substring sweep, so if it cannot see a dropped brace, the
// only other line of defence is tools/check-css.js.
{
  const dir = freshTree('s4-dropped-brace');
  // Drop exactly ONE closing brace: the first rule terminator in the block. The
  // pattern has to allow the block's own indentation -- `\n}` alone never
  // matches, which is what made the first attempt a no-op that "passed".
  const closeAt = BLOCK.search(/\n[ \t]*\}/);
  if (closeAt < 0) throw new Error('no rule terminator found in the ChatGPT block');
  const broken = BLOCK.slice(0, closeAt) + BLOCK.slice(closeAt).replace(/(\n[ \t]*)\}/, '$1');
  const mutant = real.slice(0, start) + broken + real.slice(end);
  const braces = s => ({ open: (s.match(/{/g) || []).length, close: (s.match(/}/g) || []).length });
  fs.writeFileSync(path.join(dir, 'wintage.user.js'), mutant);
  const r = runGate(dir);

  // The second line of defence runs against the project tree, so it is run
  // against a copy of the tool pointed at the mutant via a mirrored tree.
  const guardDir = path.join(FIXTURES, 's4-guard');
  fs.rmSync(guardDir, { recursive: true, force: true });
  fs.mkdirSync(path.join(guardDir, 'tools'), { recursive: true });
  fs.copyFileSync(REAL_CHECK_CSS, path.join(guardDir, 'tools', 'check-css.js'));
  fs.copyFileSync(path.join(ROOT, 'tools', 'theme-schema.js'),
    path.join(guardDir, 'tools', 'theme-schema.js'));
  fs.writeFileSync(path.join(guardDir, 'wintage.user.js'), mutant);
  let guard = { exit: -1, out: '(not run)' };
  try {
    const out = execFileSync(process.execPath, [path.join(guardDir, 'tools', 'check-css.js')],
      { encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'], timeout: 120000, cwd: guardDir });
    guard = { exit: 0, out };
  } catch (e) {
    guard = { exit: e.status === undefined ? -1 : e.status, out: (e.stdout || '') + (e.stderr || '') };
  }

  // The shipping defect is "a damaged ChatGPT block reaches a release". That is
  // REPRODUCED only if NOTHING catches it. check-css.js counting braces across
  // GLOBAL_CSS is exactly that other line of defence, so the verdict follows the
  // guard, not the gate under test. `chatgpt_gate_blind` records the sub-result
  // either way.
  verdict('S4', 'damaged-state', guard.exit === 0 ? 'REPRODUCED' : 'NOT_REPRODUCED', {
    chatgpt_gate_blind: r.exit === 0,
    claim: 'a dropped `}` inside the ChatGPT block is invisible to the ChatGPT gate; is it visible to check-css.js?',
    command: 'node .saipen/extensions/subs/saitest/kitchen/fixtures/s4-dropped-brace/tools/test-chatgpt-2026.js',
    exit: r.exit,
    guard_command: 'node .saipen/extensions/subs/saitest/kitchen/fixtures/s4-guard/tools/check-css.js',
    guard_exit: guard.exit,
    braces_real: braces(real),
    braces_mutant: braces(mutant),
    guard_finding: (guard.out.match(/FAIL: GLOBAL_CSS:.*/g) || [''])[0].trim(),
    tail: r.out.trim().split('\n').slice(-1)[0]
  });
}

// ─── report ────────────────────────────────────────────────────────────────
console.log('scenario                                    family                 verdict');
for (const r of results) {
  console.log(
    r.id.padEnd(43) +
    r.family.padEnd(24) +
    r.state);
}
console.log('');
for (const r of results) {
  console.log('--- ' + r.id + ' [' + r.state + '] ' + r.family);
  console.log('    claim:   ' + r.claim);
  console.log('    command: ' + r.command);
  for (const k of Object.keys(r)) {
    if (['id', 'family', 'state', 'claim', 'command'].includes(k)) continue;
    console.log('    ' + k + ': ' + JSON.stringify(r[k]));
  }
  console.log('');
}
fs.writeFileSync(path.join(FIXTURES, 'results.json'), JSON.stringify(results, null, 2));
process.exit(0);
