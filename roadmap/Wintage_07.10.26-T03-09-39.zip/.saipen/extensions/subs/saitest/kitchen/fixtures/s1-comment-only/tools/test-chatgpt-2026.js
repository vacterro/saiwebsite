#!/usr/bin/env node
// ChatGPT Web September 2026 shell regression gate.
//
// ChatGPT moved major UI surfaces onto semantic CSS variables and stable data
// hooks while redesigning the sidebar, composer, Projects and full-page Settings.
// Wintage intentionally keeps ChatGPT in CSS-only mode, so those contracts are
// the durable integration point. This test prevents a future cleanup from
// quietly restoring the old broad class/bottom-bar selectors that matched the
// previous shell but also recoloured unrelated scroll/layout containers.

const fs = require('fs');
const path = require('path');

const src = fs.readFileSync(path.join(__dirname, '..', 'wintage.user.js'), 'utf8');
let bad = 0;

function pass(label) { console.log('PASS: ' + label); }
function fail(label) { console.error('FAIL: ' + label); bad++; }
function requireText(label, text) { src.includes(text) ? pass(label) : fail(label + ' missing `' + text + '`'); }

// ── The ChatGPT override, read as CSS RULES rather than as substrings ──────
// This file used to be a bare `src.includes()` sweep, and a sweep cannot tell a
// declaration from a comment: deleting all 126 lines of the override and naming
// the selectors in one CSS comment left every check green, so the gate reported
// a fully themed ChatGPT for a file that themed ChatGPT not at all. The same
// blindness let all 47 themed token values become the keyword `inherit` and
// still PASS. Both are real (TEST-105 S1/S2).
//
// So the checks below run against the RULES that target the ChatGPT stamp, and
// nothing else. Comments are stripped before parsing (a comment is not a rule),
// which is what makes the deletion case fail: with the override gone there are
// zero rules, every CSS check misses, and the gate exits 1. That is the RED
// control -- no separate harness, and no way to satisfy it with prose.
function globalCss() {
  const decl = 'const GLOBAL_CSS = `';
  const i = src.indexOf(decl);
  if (i < 0) { fail('GLOBAL_CSS template literal not found'); return ''; }
  const start = i + decl.length;
  const closer = /\n[ \t]*`;/.exec(src.slice(start));
  if (!closer) { fail('GLOBAL_CSS has no closing backtick'); return ''; }
  return src.slice(start, start + closer.index);
}

function parseRules(css) {
  const rules = [];
  let depth = 0, ruleFrom = 0, bodyFrom = 0;
  for (let k = 0; k < css.length; k++) {
    if (css[k] === '{') { if (depth === 0) bodyFrom = k + 1; depth++; }
    else if (css[k] === '}') {
      depth--;
      if (depth === 0) {
        rules.push({ sel: css.slice(ruleFrom, bodyFrom - 1).trim(), body: css.slice(bodyFrom, k) });
        ruleFrom = k + 1;
      }
    }
  }
  return rules;
}

const CHATGPT_RULES = parseRules(globalCss().replace(/\/\*[\s\S]*?\*\//g, ''))
  .filter(r => r.sel.includes('html[data-w95-chatgpt'));
const CHATGPT_CSS = CHATGPT_RULES.map(r => r.sel + ' {' + r.body + '}').join('\n');
if (!CHATGPT_RULES.length) {
  fail('no CSS rule targets html[data-w95-chatgpt] -- the ChatGPT override is gone, renamed or commented out');
}

// A hook counts only when it is a SELECTOR on a live ChatGPT rule, and a token
// only when it is DECLARED with the active palette. `inherit`, a hardcoded hex
// and ChatGPT's own stock value are all legal CSS and all theme nothing.
function requireHook(label, text) {
  const hits = CHATGPT_RULES.filter(r => r.sel.includes(text)).length;
  hits ? pass(label) : fail(label + ' is not a selector on any ChatGPT rule (`' + text + '`)');
}
function requireToken(label, token) {
  const re = new RegExp('--' + token + '\\s*:\\s*([^;]+);');
  const decls = CHATGPT_RULES.filter(r => re.test(r.body));
  if (!decls.length) return fail(label + ' is never declared on a ChatGPT rule');
  for (const r of decls) {
    const value = re.exec(r.body)[1].trim();
    if (!/\$\{T\.[A-Za-z0-9_]+\}/.test(value)) {
      fail(label + ' is assigned `' + value + '` instead of a ${T.*} palette interpolation');
    }
  }
  pass(label);
}

requireText('ChatGPT host stamp exists', 'data-w95-chatgpt');
requireHook('new app shell sidebar hook', '#app-shell-sidebar');
requireHook('new composer dark hook', '[data-composer-dark]');
requireHook('new composer body hook', '[data-composer-body]');
requireHook('current prompt textarea hook', '[data-testid="prompt-textarea"]');
requireHook('current user bubble hook', '[data-user-message-bubble="true"]');
requireHook('current code block hook', '[data-markdown-copy="code-block"]');
requireHook('thread footer fade hook', '#thread-bottom-container::after');

for (const token of [
  '--chat-background-color:',
  '--app-color-background-surface:',
  '--color-surface:',
  '--color-background-panel:',
  '--color-token-main-surface-primary:',
  '--color-token-side-bar-background:',
  '--composer-background-color:',
  '--user-message-background-color:',
  '--codeblock-background-color:',
  '--color-token-text-code-block-background:'
]) {
  // The list reads as the CSS declaration (`--token:`); requireToken wants the
  // bare name and supplies the `--` itself.
  requireToken('semantic token ' + token.slice(2, -1), token.slice(2, -1));
}

// Rollout fallbacks are deliberate. Accounts can contain surfaces from both
// generations for a while, so removing these would make the theme flicker or
// leak stock colours during migration.
requireHook('legacy slideover sidebar fallback', '#stage-slideover-sidebar');
requireHook('legacy tiny sidebar fallback', '#stage-sidebar-tiny-bar');

// The retired approach was too broad for the redesigned shell: it recoloured
// unrelated scroll and layout containers along with the composer.
//
// A literal ban could not hold that line. `[class*="composer" i]` is only ONE
// spelling of "match every element whose class contains composer", and
// `[class*="composer"]` -- same over-broad match, `i` flag simply dropped --
// sailed past it, as did `div.sticky[class~="bottom-0"]` for the bottom bar
// (TEST-105 S3). Worse, the ban was a substring sweep over the whole file, so
// the comment you are supposed to write when you remove a retired selector
// contained the banned text and failed the gate.
//
// So the ban is on the SHAPE, evaluated on the parsed selectors of the ChatGPT
// rules: no class-substring match (`[class*=`, `[class~=`, `[class^=`,
// `[class$=`) and no `.sticky` + bottom-0 utility pair. Every spelling of the
// retired approach is caught, and prose that merely names one is not.
for (const rule of CHATGPT_RULES) {
  for (const sel of rule.sel.split(',').map(s => s.trim()).filter(Boolean)) {
    if (/\[class\s*[~^$*|]?=\s*["']?/i.test(sel)) {
      fail('retired class-fragment match in a ChatGPT selector: `' + sel + '`');
    }
    if (/\.sticky\b/.test(sel) && /bottom-0\b/.test(sel)) {
      fail('retired sticky-bottom selector in a ChatGPT rule: `' + sel + '`');
    }
  }
}
if (!bad) console.log('PASS: no retired class-fragment or sticky-bottom selector in the ChatGPT rules');

// ChatGPT must remain in the bounded CSS-only high-churn path. DOM repainting a
// continuously streaming chat is the wrong solution even when it looks easier.
requireText('ChatGPT classified as high churn', 'const HIGH_CHURN_HOST = IS_X || IS_CHATGPT');
requireText('high churn remains CSS-only', 'const CSS_ONLY_MODE = HIGH_CHURN_HOST;');

if (bad) {
  console.error('\nChatGPT 2026 shell gate: ' + bad + ' failure(s)');
  process.exit(1);
}
console.log('\nChatGPT 2026 shell gate: PASS');
