// Bounded reproduction of F-2 catch-path (patch-freebuff-ads.js:170-175, T-251).
// We do NOT touch the working tree: monkeypatch fs.rmSync to throw the exact
// EPERM a Windows lock produces, then run the production prune shape verbatim.
const fs = require('fs'); const path = require('path');
const orig = fs.rmSync;
fs.rmSync = () => { const e = new Error('EPERM: operation not permitted'); e.code='EPERM'; throw e; };
const out = [];
const cl = console.log; console.log = (m)=>out.push(String(m));
const old = { dir: '/x/_orig-baseline-2026-09-16T00-00-00-000Z-1234' };
// verbatim from desktop/patch-freebuff-ads.js:171-175
try { fs.rmSync(old.dir, { recursive: true, force: true }); console.log('pruned stale baseline ' + path.basename(old.dir)); }
catch (e) { console.log('could not prune stale baseline ' + path.basename(old.dir) + ': ' + ((e && e.code) || e)); }
console.log = cl; fs.rmSync = orig;
const line = out[0] || '';
const diagnosed = /^could not prune stale baseline .*: EPERM$/.test(line);
console.log('OBSERVED: ' + JSON.stringify(line));
console.log('DIAGNOSED_ON_FAILURE: ' + diagnosed);
process.exit(diagnosed ? 0 : 1);
