#!/usr/bin/env node
// PRE-FIX COPY of tools/test-chatgpt-2026.js, reconstructed verbatim for the
// T-342/T-343 regression pair. Not part of the product; it exists so the FAIL
// half of the pair can be re-run on demand.

const fs = require('fs');
const path = require('path');

const src = fs.readFileSync(path.join(__dirname, '..', 'wintage.user.js'), 'utf8');
let bad = 0;

function pass(label) { console.log('PASS: ' + label); }
function fail(label) { console.error('FAIL: ' + label); bad++; }
function requireText(label, text) { src.includes(text) ? pass(label) : fail(label + ' missing `' + text + '`'); }
function forbidText(label, text) { !src.includes(text) ? pass(label) : fail(label + ' still contains `' + text + '`'); }

requireText('ChatGPT host stamp exists', 'data-w95-chatgpt');
requireText('new app shell sidebar hook', '#app-shell-sidebar');
requireText('new composer dark hook', '[data-composer-dark]');
requireText('new composer body hook', '[data-composer-body]');
requireText('current prompt textarea hook', '[data-testid="prompt-textarea"]');
requireText('current user bubble hook', '[data-user-message-bubble="true"]');
requireText('current code block hook', '[data-markdown-copy="code-block"]');
requireText('thread footer fade hook', '#thread-bottom-container::after');

for (const token of [
  '--chat-background-color:',
  '--app-color-background-surface:',
  '--color-surface:',
  '--color-background-panel:',
  '--color-token-main-surface-primary:',
  '--color-token-side-bar-background:',
  '--composer-background-color:',
  '--user-message-background-color:',
  '--codeblock-background-color:',
  '--color-token-text-code-block-background:'
]) {
  requireText('semantic token ' + token.slice(0, -1), token);
}

requireText('legacy slideover sidebar fallback', '#stage-slideover-sidebar');
requireText('legacy tiny sidebar fallback', '#stage-sidebar-tiny-bar');

forbidText('retired class-fragment composer selector', '[class*="composer" i]');
forbidText('retired generic sticky bottom selector', 'div.sticky.bottom-0');

requireText('ChatGPT classified as high churn', 'const HIGH_CHURN_HOST = IS_X || IS_CHATGPT');
requireText('high churn remains CSS-only', 'const CSS_ONLY_MODE = HIGH_CHURN_HOST;');

if (bad) {
  console.error('\nChatGPT 2026 shell gate: ' + bad + ' failure(s)');
  process.exit(1);
}
console.log('\nChatGPT 2026 shell gate: PASS');
