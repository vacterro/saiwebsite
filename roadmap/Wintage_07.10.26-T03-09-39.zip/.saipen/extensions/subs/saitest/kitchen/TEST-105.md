# TEST-105 — reproduction pass @ 44f6b33 + v1.36.2 working tree

Target handed by Core under T-341 (SRC-050, `user_explicit: true`): the
uncommitted **v1.36.2 ChatGPT Web September 2026 shell rebuild** and the new
gate that is supposed to protect it.

- product delta: `wintage.user.js` 7486 lines changed at HEAD `44f6b33`
- new gate: `tools/test-chatgpt-2026.js` (untracked), wired into
  `tests/Run-Tests.ps1:780`
- driver: `kitchen/scenarios-105.js` — full transcript in `kitchen/TEST-105-run.txt`
- machine record: `kitchen/fixtures/results.json`

## Safety floor

Every scenario ran against a **copy** under `kitchen/fixtures/`. The project's
`wintage.user.js` was opened read-only and never written. The gate under test
is copied **verbatim** into each fixture tree — the defect is in the gate, so
re-implementing it would have tested the wrong thing. The gate resolves its
input as `path.join(__dirname, '..', 'wintage.user.js')`, so each fixture is a
two-file tree: `<case>/tools/test-chatgpt-2026.js` beside
`<case>/wintage.user.js`.

Load ceiling: 5 fixture trees, ~200 KB each, every `execFileSync` bounded at
60 s (120 s for the CSS guard). No scenario exceeded either.

## Verdicts

| ID | Family | Verdict | One line |
|----|--------|---------|----------|
| S1 | adversarial content | **REPRODUCED** | the whole 126-line ChatGPT override deleted, gate still PASSes |
| S2 | input abuse | **REPRODUCED** | all 47 themed token values replaced with `inherit`, gate still PASSes |
| S3 | input abuse | **REPRODUCED** | both banned selectors re-spelled, gate still PASSes |
| S4 | damaged state | **NOT_REPRODUCED** | a dropped `}` is invisible to the ChatGPT gate but `check-css.js` catches it |
| S5 | environment / order | **REPRODUCED** | `Run-Tests.ps1` aborted before the node suites; the new gate never ran |

## S1 — the gate passes on a file that themes ChatGPT not at all

`REPRODUCED`. Minimal input: `wintage.user.js` with bytes `93156..99050`
(126 lines, the complete `html[data-w95-chatgpt="1"]` override) replaced by one
CSS comment naming all 22 strings the gate greps for.

```
node .saipen/extensions/subs/saitest/kitchen/fixtures/s1-comment-only/tools/test-chatgpt-2026.js
```

Observed: exit `0`, last line `ChatGPT 2026 shell gate: PASS`, 25/25 checks
green — on a file that no longer contains a single ChatGPT rule
(`live_rule_survives: false`).

The gate is a bare `src.includes(text)` sweep (`tools/test-chatgpt-2026.js:19`).
A comment is as good as a declaration to it. There is no RED control: nothing in
the file fails when the thing it protects is gone.

## S2 — `inherit` is a legal declaration and themes nothing

`REPRODUCED`. Minimal input: every `${T.*}` interpolation inside the ChatGPT
block replaced with the keyword `inherit` — 47 declarations neutered, tokens
and selectors untouched.

```
node .saipen/extensions/subs/saitest/kitchen/fixtures/s2-inherit-tokens/tools/test-chatgpt-2026.js
```

Observed: exit `0`, `ChatGPT 2026 shell gate: PASS`. The gate's own header
claims the theme "maps the current chat, panel, sidebar, composer, message,
code-block, text and border tokens **directly to the active Wintage palette**".
It never checks a single value. A hand-typed `inherit`, an unedited ChatGPT
charcoal, or a stale hardcoded value all read identically to a correct theme.

## S3 — the two bans are exact substrings

`REPRODUCED`. Minimal input: two rules appended after the ChatGPT block —
`html[data-w95-chatgpt="1"] [class*="composer"]` and
`html[data-w95-chatgpt="1"] div.sticky[class~="bottom-0"]`.

```
node .saipen/extensions/subs/saitest/kitchen/fixtures/s3-ban-evasion/tools/test-chatgpt-2026.js
```

Observed: exit `0`, PASS. `forbidText` (`tools/test-chatgpt-2026.js:20`) bans
the exact text `[class*="composer" i]` and `div.sticky.bottom-0`. Dropping the
` i` case flag, or writing the class as an attribute selector, produces the same
over-broad match on ChatGPT's lowercase Tailwind classes and is not caught. The
bans also cannot be documented: naming either selector anywhere in the file —
including the explanatory comment that should accompany the removal — fails the
gate.

## S4 — brace damage: the gate is blind, the suite is not

`NOT_REPRODUCED` for the shipping defect, with a sub-finding worth keeping.

Minimal input: one `}` removed from the first rule in the ChatGPT block
(`{`/`}` 1012/1011 in the whole file; 441/440 inside `GLOBAL_CSS`).

```
node .../fixtures/s4-dropped-brace/tools/test-chatgpt-2026.js   -> exit 0, PASS
node .../fixtures/s4-guard/tools/check-css.js                   -> exit 1
```

`check-css.js:126-127` counts braces across `GLOBAL_CSS` and reports
`FAIL: GLOBAL_CSS: 441 \`{\` vs 440 \`}\``. A dropped brace cannot reach a
release through the suite. The ChatGPT gate on its own is blind to it
(`chatgpt_gate_blind: true`) — recorded so nobody cites this gate as CSS
structure evidence.

First attempt at this scenario was a **false negative**: the pattern `/\n\}/`
never matched, because the block's rule terminators are indented `\n  }`. The
scenario mutated nothing and "passed". The fixed pattern is `/\n[ \t]*\}/`. A
test that cannot fail is not a test — this one is logged here so the next pass
does not repeat the mistake.

## S5 — the suite was red on arrival and the new gate never ran

`REPRODUCED` (resolved in-run; the finding is the missing ordering obligation,
not the stale files).

On arrival, before any scenario ran:

```
powershell -NoProfile -ExecutionPolicy Bypass -File tests/Run-Tests.ps1
```

exited `1` after 8 sections, aborting inside `--- Testing -WhatIf Isolation ---`
with `desktop/out is out of date with themes/*.json`. `tests/Run-Tests.ps1:273`
comes before the `$toolSuites` loop that holds `test-chatgpt-2026.js` at
`:780`, so **no node suite executed at all** — the new gate was reported as
green only because it never ran.

`node tools/build-desktop.js --check` named the cause: 65 stale outputs, every
Electron palette's `wintage.css` and `shim.cjs`, every browser and obsidian
`manifest.json`, and the vscode `package.json`. `desktop/out/electron/golden/
wintage.css` carried 2 occurrences of `data-w95-chatgpt` and 0 of
`stage-slideover-sidebar`, against 22 in the source — the generated payloads
were still on the pre-2026 ChatGPT theme.

Regenerated with the command the error names, then re-ran:

```
node tools/build-desktop.js          -> 65 file(s) written, exit 0
node tools/build-desktop.js --check  -> exit 0
tests/Run-Tests.ps1                  -> ALL TESTS PASSED, exit 0, 0 FAIL, 265 PASS
```

and line 230 of the transcript is now
`[PASS] test-chatgpt-2026.js suite exits 0`.

`desktop/out/` is gitignored (`.gitignore:4`) and untracked, so this mutated
derived output only. The finding that survives: **nothing enforces that
`build-desktop.js` runs before `Run-Tests.ps1`.** A large `wintage.user.js`
change can leave the whole node gate layer unreachable, and the only symptom is
a suite that dies 500 lines before the test anyone was looking at.

## What was not run

The scenarios cover the new gate, the file it reads, and the suite that
executes it. They do **not** measure anything in a browser: no computed style,
no contrast, no rendered surface. S1/S2/S3 prove the gate is uninformative;
they say nothing about whether the shipped ChatGPT CSS is actually correct on
chatgpt.com. That needs a live page and is out of reach here.

## Re-run after Core's fixes — S1/S2/S3 NOT_REPRODUCED

Core closed the findings in T-342, T-343 and T-344 while this pass was open.
The same driver, unchanged, cold re-run against the fixed gate:

| ID | Verdict now | Fixture exit |
|----|-------------|--------------|
| S1 | NOT_REPRODUCED | 1 — `no CSS rule targets html[data-w95-chatgpt]` |
| S2 | NOT_REPRODUCED | 1 — names the `inherit` declaration |
| S3 | NOT_REPRODUCED | 1 — 3 failures, both selectors rejected by shape |
| S4 | NOT_REPRODUCED | unchanged; check-css.js still covers the brace |

One thing found while re-running, recorded because it has the same shape as S1:
the block-boundary locator in this driver used `indexOf('}')` from the first `{`
after the anchor, and that brace is the one in the `${B_INNER}` interpolation
rather than the rule's. S3's injected rules were landing *inside* the last rule's
body, so the fixture exercised nothing and its NOT_REPRODUCED would have been
worthless. The locator now walks brace depth. **A scenario that cannot fail is
not a scenario** — the same sentence that governs a gate, and it applies to the
thing that tests the gate.

## Re-running the FAIL halves

The regression pairs recorded against T-342/T-343/T-344 are reproducible from
the two pre-fix subjects kept beside this file:

| File | sha256 (first 16) | Role |
|---|---|---|
| `prefix-test-chatgpt-2026.js` | `975fa146b802f77d` | the gate as it was before T-342/T-343 |
| `prefix-Run-Tests.pre-T-344.ps1` | `f0b0b457c5659313` | `tests/Run-Tests.ps1` minus the T-344 section |

Drop either one into a fixture tree's `tools/` and re-run: pre-fix, the three
broken inputs all exit 0; post-fix, all three exit 1. Same fixtures, same
commands, only the file under repair moved.


