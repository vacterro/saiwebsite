# OUTBOX

## SAIT-009: 28 English-valued UI keys translated in all 29 producer locale JSONs at c62d89d, three doc surfaces stamp-current (ready)

- **status:** ready
- **producer:** saitranslate
- **source_head:** c62d89df77ecc219204d183130955685edba7d4b
- **source_tree_fingerprint:** git-delta-v1:58c4eeac0159372d783c452a5aadb89f631484fe3c30205bf4d4c89bedbc92ec
- **role_revision:** sha256:7d18729f8d94eb58471ae3bb5fad9151e8499fea291e574b26439c5c89012e41
- **summary:** The 28 keys added by the terminal-font, themes and preset rounds were
  English copy-paste in ALL 29 producer-owned locale JSONs -- 812 strings of visible
  installer UI rendering English under 29 non-English picks -- and no shipped gate could
  see it. All 812 are now written, and each kitchen file mirrors the repo's own 80-key
  file byte-for-byte outside those 28 values. The kitchen copies were also 30 keys SHORT
  of the repo (50 keys each at HEAD), so the payload as it stood before this run would
  have DELETED 30 keys per file on collect; the mirror is now exact. The two stale kitchen
  doc drafts were resynced from the repo, which is the current gate-green truth, so the
  whole kitchen now equals the live surfaces.
- **critical:** false
- **severity:** P2
- **coverage:**
  - UI strings -- desktop/locales/*.json: **29 producer locales** (ar bg cs da de el es fi
    fr he hi hr hu id it ja ko nl no pl pt ro sk sv th tr uk vi zh), 28 keys each,
    **812 of 812 strings written**.
  - docs -- root README: **32 locales**, kitchen resynced to the live
    `locales/README.<lang>.md` content; digest 62ecd9032c8c2f79 current in all 32 on both
    sides.
  - docs -- desktop/README.md: **32 locales**, kitchen resynced byte-identical to the live
    repo copies; digest 15c96dac8494ab84 current in all 32 on both sides.
  - docs -- browser-theme/README.txt: **32 locales**, already byte-identical on both sides;
    digest 056bdd1c330ee8c2 current in all 32. No change was needed.
- **payload:** `.saipen/saitranslate/kitchen/locales/<code>.json` x29 -- the deliverable:
  the 28 target values translated, every other key byte-identical to the repo file, and the
  30 keys the kitchen copies were missing restored, so applying them can no longer delete
  anything. Plus `.saipen/saitranslate/kitchen/README.<lang>.md` x32 and
  `.saipen/saitranslate/kitchen/desktop/README.<lang>.md` x32, resynced to the live repo
  content -- byte-identical to it, with the same two `../` link adaptations the collector
  already applies to a root README. browser-theme needs no copy.
- **verified:** PASS -- (1) integrity of all 29 kitchen locale files, each re-read against the repo's own file for the same code by an independent structural diff: no BOM, CRLF present, exactly 80 keys, key set and key ORDER identical to the repo file and to `en.json`'s set, all 52 non-target keys byte-equal, zero empty target values; (2) line-level diff kitchen vs repo, 1612 changed lines, every one of them a `"<key>":` line for one of the 28 and zero other lines moved (28 keys x 2 lines x 29 files = 1624, minus the 6 values byte-identical to English); (3) coverage 812/812 written, the 6 values still identical to English each correct (da/id TfLog "Log", fr TfSource "Source", id/pl PresetLabel "Preset", de TabThemes "Themes & Apps", the loanword et and ded already use for that key); (4) all three doc digests current in all 32 locales on both sides -- 62ecd9032c8c2f79 / 15c96dac8494ab84 / 056bdd1c330ee8c2 -- kitchen desktop and browser-theme byte-identical to the repo, kitchen root differing from `locales/README.<lang>.md` on exactly two lines per file, both the `../` link prefix; (5) repo gates re-run at c62d89d: test-readme-target-parity 395 PASS 0 FAIL, test-locale-parity 68 PASS 0 FAIL, test-locale-semantic 52 PASS 0 FAIL, test-locale-keys 11 PASS 0 FAIL; (6) `saipen outbox check saitranslate` exit 0 (OUTBOX_VALID).
- **instructions:** (1) `eee` collects: copy
  `.saipen/saitranslate/kitchen/locales/<code>.json` over `desktop/locales/<code>.json` for
  the 29 codes -- the only changed lines are the 28 values in each -- then confirm the three
  doc surfaces are already byte-identical (no copy needed), re-run the four gates and ship.
  (2) DURABLE FIX, Core's call and outside this role's write scope: extend
  `tools/test-locale-semantic.ps1` contract B from its 3 core locales to all 32. The gate's
  own header (line 21) records that the 29 producer locales "are not checked here", so
  right-keys-wrong-values can regress in 29 files with every gate green -- and did. The
  check is one loop over the key list the gate already holds, plus one red-control case.
  (3) If any source change lands before collect, re-run `ee` first: this package is bound to
  c62d89d.
- **details:**
  Why `ready`, and what was actually wrong. Three locale gates ship and all three are green
  at c62d89d, yet 28 keys x 29 locales rendered English, because none of the three looks at
  these files' values: `test-locale-parity.ps1` checks the key SET, `test-locale-keys.ps1`
  checks the call sites, and `test-locale-semantic.ps1` checks VALUES but only for the three
  Core locales -- its own header says so. The 28 keys are the ones the recent installer
  rounds added (`TabFonts`/`Tf*`, `TabThemes`/`TabBetterDiscord`/`BdPlugins`, `Preset*`),
  and in every producer file they carried the English string verbatim: correct keys, wrong
  values, the exact shape the semantic gate was written to catch, in the 29 files that gate
  does not read. That is one bounded defect, not a translation round, which is why this
  package is `ready` and not `blocked` for more information.
  The kitchen was also structurally wrong before this run, and that part is worth recording
  because it is worse than stale text: measured from HEAD, all the kitchen locale copies held
  50 keys against the repo's 80. A collect applies the kitchen over the repo, so the payload
  as it stood would have silently deleted 30 keys from each of the 29 files -- every key the
  last three rounds added. The mirror is now exact (80 keys, same order, same serialization:
  no BOM, CRLF, two-space indent, same key order), so the copy is a value-only change and
  nothing else can move.
  CORRECTION to SAIT-008, whose `blocked` was right about the desktop kitchen and wrong
  about the root. Measured now: the root README translations ARE integrated -- at
  `locales/README.<lang>.md`, 32 files, digest 62ecd9032c8c2f79 current, governed by test 7
  of `tools/test-readme-target-parity.ps1`, which reports 395 PASS / 0 FAIL including a
  per-file "digest stamp is current" check. SAIT-008 read the repository ROOT directory, saw
  no `README.<lang>.md` there, and concluded the surface did not exist; it exists one
  directory down. Its "12 table rows against the current README.md's 30" was a stale
  structural reading -- the live copies carry the same heading count as the source. The
  desktop kitchen drafts, by contrast, were genuinely behind (the kitchen `ar` file held 157
  lines against the repo's 253, missing the qbittorrent row and the sections added since),
  and they are now resynced from the repo. Nothing was re-stamped by hand anywhere: the
  digests that landed in the kitchen are the ones the repo already carried, and those were
  already current. The charter's rule that a stale digest is "a finding, never a silent
  refresh" is not weakened by this -- the finding is SAIT-008, it is recorded above and on
  the BOARD, and the refresh that followed is from the integrated truth, measured.
  How the 812 were produced and checked. Six parallel per-language passes wrote the values,
  then every file was re-read against its repo counterpart by an independent structural
  diff (integrity, order, byte-equality of the untouched 52 keys, emptiness, encoding, and
  the line-level diff census) -- those checks are the ones in `verified`, run directly
  rather than through a gate, because no gate covers these files. The replay risk is real
  and is named here so the collector can weigh it: these values are translations, the
  authoring passes were model-driven, and where a register or loanword choice existed the
  Core locales (et/ru/ded) were used as the reference.
  Namespace hygiene: nothing under the main tree was written -- every byte of this package
  is under `.saipen/saitranslate/`, the role's only legal write scope. Two subagent scratch
  files left in the kitchen (`translate6.py`, `check6.py`) were deleted rather than shipped.
  This namespace had no STATE.md or BOARD.md before this run (only LOG.md and the kitchen,
  which is why the earlier audit packages had no board to read); both are created with the
  package, matching the scheduler schema and the sibling producer layout. The previously
  retired mis-spawned namespace stays archived at `.saipen/recovery/saitranslate-stray-20260929/`;
  `saipen sub sync --dry-run` reports no namespace drift.

## SAIT-008: translation-surface audit at 44f6b33 -- browser-theme and locales CURRENT, root and desktop README translations BEHIND (blocked)
- **status:** stale
- **superseded_by:** SAIT-009 (source_head 44f6b33 -> c62d89d, v1.36.1 -> v1.36.6; the desktop gap it flagged closed, the root surface it reported missing found at `locales/README.<lang>.md`, and the 28 English-valued producer keys it did not see translated)
- **producer:** saitranslate
- **source_head:** 44f6b33868ef32dbb71130a1899d189fd2192328
- **source_tree_fingerprint:** git-delta-v1:cea203e9526e42fcfd73aa658dd9e96e001b5a62c0c9b2f4d9151ef61ba6e609
- **role_revision:** sha256:7d18729f8d94eb58471ae3bb5fad9151e8499fea291e574b26439c5c89012e41
- **summary:** Measured every translation surface against its current English source instead of assuming a round was needed. Two of four are current and two are materially behind, in OPPOSITE directions, which is why no single `ready` package is honest here.
- **critical:** false
- **severity:** P2
- **coverage:** four surfaces, measured: browser-theme README.txt, desktop/locales/*.json, root README.md, desktop/README.md
- **payload:** [] (nothing is collectable: the two behind surfaces are behind by CONTENT, not by a stale stamp, and a re-stamp would be a lie -- see details)
- **verified:** PASS -- every surface measured against its own English source. CURRENT: browser-theme, 32 of 32 translations carry digest 056bdd1c330ee8c2, which IS the current sha256 prefix of browser-theme/README.txt. CURRENT: locale JSONs, test-locale-parity.ps1 68 PASS 0, test-locale-semantic.ps1 61 PASS 0, test-locale-keys.ps1 11 PASS 0. BEHIND, and now gated: test-readme-target-parity.ps1, extended under T-352 to DERIVE its target list from the source table instead of carrying the frozen T-311 list, and to validate the source-digest stamp against the live source -- it now reports 231 PASS and 32 FAIL, one per locale, all the same single cause (missing: qbittorrent), where it previously reported 231 PASS and said nothing
- **instructions:** Do not collect. The desktop gap is now EXACTLY 64 cells and nothing more: every one of the 32 locales is missing the `qbittorrent` target row, and every one carries a `terminal` mechanism cell whose text predates the source change to Terminus. Run `python .saipen/kitchen/translation-worklist.py` for the per-language list; only the mechanism cell of each is language-dependent, since the first cell is a code literal and the third is a yes/no clause, so a round is 64 short technical sentences rather than 32 README rewrites. Then re-stamp each file's source-digest to sha256:11bc63db15c22b05 and the gate goes green on its own. SEPARATELY, the 32 root README.<locale>.md have never been integrated at all (the repo root holds zero translated READMEs and each kitchen translation has 12 table rows against the current README.md's 30) and need a full round. That is a much larger job and is why the root surface is not part of the 64.
- **details:** Why `blocked` and not `ready`, stated because the tempting shortcut is worse than useless. The digest marker each translation carries (<!-- source-digest: <file> sha256:<16hex> -->) is a version stamp of the English source at translation time. Measured now: browser-theme English README.txt digests to 056bdd1c330ee8c2 and all 32 translations carry exactly that, so that surface is CURRENT and needs no work. desktop English README.md digests to 11bc63db15c22b05 while all 33 repo files and all 32 kitchen files still carry 1b166ae6a7cf8a5c. Root English README.md digests to 3e0623c938fcd514 while all 32 kitchen files carry 886c5e27060e7b30. CORRECTION to an earlier reading recorded during this audit: the two header+separator pairs in each translated desktop README are NOT a duplicated header. They are two separate tables, each under its own heading, the second appended by the T-311 refresh to carry notepadplusplus, cinema4d and processexplorer. That is valid Markdown and renders correctly; nothing is malformed and no structural repair is owed. Also measured and worth recording: no translated surface anywhere in the repository contains the word qBittorrent in ANY language -- not the desktop READMEs, not the root READMEs, not browser-theme, not the locale JSONs -- so the missing row's translated text cannot be recovered by reuse and must be written. The tempting move is to re-stamp the marker to the current digest and declare the surface refreshed -- and that would be a fabricated claim in the exact shape PROTOCOL.md section 2 warns about: correctly formatted, confidently worded, status: ready, and wrong. The structural evidence says otherwise: 0 of 32 desktop translations in the repo and 0 of 32 in the kitchen match the source's heading sequence, row count and fence count. The content is behind, so the stamp is behind with it, honestly. This entry exists so the next producer round starts from measurements instead of from the assumption that a round is needed; the alternative is a `ready` package with an empty payload, which would turn the collect gate green while promising Core nothing it can act on.

## SAIT-007: Wintage full translation bundle — fresh EE at cdbe140, payload already live (eee collect)

- **status:** reviewed
- **summary:** Fresh EE bound to the current HEAD (cdbe140, v1.26.4 T-187 ship +
  converge closure checkpoint). SAIT-006 went stale when the closure checkpoint
  moved HEAD (8867967 -> cdbe140), so this package is the re-prepared handoff
  for the explicit `eee` collect. Full 32-language bundle re-verified against
  the current identity; the payload is already integrated (eee shipped it at
  fd53d63, nothing touched the translation surfaces since), so collect is a
  content-equivalent no-op: all repo surfaces are byte-identical to the
  kitchen. Freshness identity: source_head cdbe140, fingerprint c66baf69
  (clean delta, .saipen excluded), role_revision f241e6b8 (unchanged charter).
- **critical:** false
- **severity:** P3
- **producer:** saitranslate
- **source_head:** cdbe140278d1ad0fdf8701b351893d810971ae65
- **source_tree_fingerprint:** git-delta-v1:c66baf69a8306f3b95dfc7badb5f72b088f8de8408e933efadc4d149721a1195
- **role_revision:** sha256:f241e6b83c39e9b46bfa586638efb0374bbb39889646f723b9189bbb4912c0c5
- **coverage:**
  - docs — README.md: **32 locales** (en source + ru et ded + 29 bundle), all 32
    kitchen README.<lang>.md carry the current digest 886c5e27060e7b30 and the
    post-T-184 release section (CHANGELOG prerequisite named, zero "Edit
    wintage.user.js" hits, switcher bar verbatim).
  - docs — desktop/README.md: **32 locales**, digest 1b166ae6a7cf8a5c current,
    targets table + commands preserved.
  - docs — browser-theme/README.txt: **32 locales**, digest 056bdd1c330ee8c2
    current, T-171 fixed-legacy preamble everywhere.
  - UI strings — desktop/locales/*.json: **33 locales** (en ru et ded + 29),
    49 keys each, exact parity vs en.json, all parse.
- **payload:** the full 32-language kitchen set (README.<lang>.md at kitchen
  root, desktop/README.<lang>.md, browser-theme/README.<lang>.txt, 29 locale
  JSONs) — already live in the repo byte-identical (eee applied at fd53d63; the
  T-187 audit + closure checkpoint touched none of these surfaces). Collect =
  verify only; no file needs copying.
- **verified:** PASS -- Freshness identity recomputed with tools/freshness.py at cdbe140 (clean (full list under details)
- **instructions:** (1) `eee` collects: run the hard collect gate
  (`validate.py --gate collect:saitranslate`), verify byte-identity (proven
  here), mark this package reviewed, create/claim the Core collect ticket and
  ship it. No repo mutation is required — every payload file is already live
  byte-identical. (2) If any future source change lands before collect, re-run
  `ee` first.
- **details:**
  Fresh EE, not reuse: SAIT-006 (bound to 8867967) went stale when the converge
  closure checkpoint commit moved HEAD to cdbe140 — the collect gate correctly
  refused it (PROTOCOL.md § 6). The checkpoint touched only .saipen/ and
  .gitignore, so regeneration against all three freshness inputs is
  byte/content-equivalent — a legal no-op with the rerun verification recorded
  above. All work under .saipen/saitranslate/kitchen/; the main repo tree was
  not touched by this preparation.
  Collected at: 2026-08-11T13:20:00Z (eee, T-188)
  Source-head label dropped: `cdbe140278d1ad0fdf8701b351893d810971ae65 (project HEAD)`.
  Evidence recorded at preparation time (moved here from the `verified` field, which carries a closed verdict and cannot hold a list):
  - Freshness identity recomputed with tools/freshness.py at cdbe140 (clean
    tree): source_head cdbe140278d1ad0fdf8701b351893d810971ae65, fingerprint
    c66baf69 (empty delta, .saipen excluded), role_revision f241e6b8 matches
    the charter's declared YAML value.
  - All 32 kitchen READMEs: current digest 886c5e27060e7b30 (programmatic),
    zero stale release-section hits, switcher bar verbatim in all.
  - All 32 desktop kitchen files carry 1b166ae6a7cf8a5c; all 32 browser-theme
    kitchen files carry 056bdd1c330ee8c2 (programmatic digest match).
  - All 29 locale JSONs parse (json.load) and have exactly 49 keys; key set
    identical to desktop/locales/en.json (0 missing, 0 extra).
  - Byte-identity kitchen vs repo re-confirmed across all three md surfaces
    (root README.<lang>.md 32/32, desktop 32/32, browser-theme 32/32) and all
    29 locale JSONs — zero diffs; the eee collect already applied everything.
  - TRANSLATION_CONTRACT.md digest constants current (886c5e27060e7b30 /
    1b166ae6a7cf8a5c / 056bdd1c330ee8c2).

## SAIT-006: Wintage full translation bundle — fresh EE at 8867967, payload already live (converge closure)

- **status:** stale
- **superseded_by:** SAIT-007 (source_head 8867967 -> cdbe140 at the converge closure checkpoint)
- **summary:** Converge stage-K fresh EE bound to the current HEAD (8867967,
  v1.26.4 T-187 ship). Full 32-language bundle re-verified against the new
  identity; the payload is already integrated (eee shipped it at fd53d63, the
  T-187 audit touched no translation surface), so collect is a content-
  equivalent no-op: all repo surfaces are byte-identical to the kitchen.
  Freshness identity: source_head 8867967, fingerprint a7d2ffe1 (clean delta,
  .saipen excluded), role_revision f241e6b8 (unchanged charter).
- **critical:** false
- **severity:** P3
- **producer:** saitranslate
- **source_head:** 88679679000435dedb61393f89ccac971e9e0072
- **source_tree_fingerprint:** git-delta-v1:a7d2ffe1d350186aa7c2577b767eb5af8e3625e4ce75c0e9ef500759e9bc959b
- **role_revision:** sha256:f241e6b83c39e9b46bfa586638efb0374bbb39889646f723b9189bbb4912c0c5
- **coverage:**
  - docs — README.md: **32 locales** (en source + ru et ded + 29 bundle), all 32
    kitchen README.<lang>.md carry the current digest 886c5e27060e7b30 and the
    post-T-184 release section (CHANGELOG prerequisite named, zero "Edit
    wintage.user.js" hits, switcher bar verbatim).
  - docs — desktop/README.md: **32 locales**, digest 1b166ae6a7cf8a5c current,
    targets table + commands preserved.
  - docs — browser-theme/README.txt: **32 locales**, digest 056bdd1c330ee8c2
    current, T-171 fixed-legacy preamble everywhere.
  - UI strings — desktop/locales/*.json: **33 locales** (en ru et ded + 29),
    49 keys each, exact parity vs en.json, all parse.
- **payload:** the full 32-language kitchen set (README.<lang>.md at kitchen
  root, desktop/README.<lang>.md, browser-theme/README.<lang>.txt, 29 locale
  JSONs) — already live in the repo byte-identical (eee applied at fd53d63; the
  T-187 audit touched none of these surfaces). Collect = verify only; no file
  needs copying.
- **verified:** PASS -- Freshness identity recomputed with tools/freshness.py at 8867967: (full list under details)
- **instructions:** (1) This is a closure-bar package (CONVERGE.md stage K): it
  exists so `--gate converge` sees EE fresh+ready at the final HEAD. (2)
  Collect via `eee` is optional — it verifies byte-identity (already proven
  here) and marks reviewed; no repo mutation is required. (3) If any future
  source change lands before collect, re-run `ee` first.
- **details:**
  Fresh EE, not reuse: SAIT-005 was bound to 83d3d1e; the T-187 audit ship
  moved HEAD to 8867967 (v1.26.4), so the closure bar (CONVERGE.md stage M:
  "bound to the current source identity") demanded a fresh ready package. The
  T-187 ship touched no translation surface (installer/tools/themes only), so
  regeneration against all three freshness inputs is byte/content-equivalent —
  a legal no-op with the rerun verification recorded above. All work under
  .saipen/saitranslate/kitchen/; the main repo tree was not touched by this
  preparation.
  Source-head label dropped: `88679679000435dedb61393f89ccac971e9e0072 (project HEAD)`.
  Evidence recorded at preparation time (moved here from the `verified` field, which carries a closed verdict and cannot hold a list):
  - Freshness identity recomputed with tools/freshness.py at 8867967:
    source_head 88679679000435dedb61393f89ccac971e9e0072, fingerprint
    a7d2ffe1 (clean delta, .saipen excluded), role_revision f241e6b8 matches
    the charter's declared YAML value.
  - All 32 kitchen READMEs: current digest 886c5e27060e7b30 (programmatic),
    zero stale release-section hits, switcher bar verbatim in all.
  - All 32 desktop kitchen files carry 1b166ae6a7cf8a5c; all 32 browser-theme
    kitchen files carry 056bdd1c330ee8c2 (programmatic digest match).
  - All 29 locale JSONs parse (json.load) and have exactly 49 keys; key set
    identical to desktop/locales/en.json (0 missing, 0 extra).
  - Byte-identity kitchen vs repo re-confirmed across all three md surfaces
    (root README.<lang>.md 32/32, desktop 32/32, browser-theme 32/32) and all
    29 locale JSONs — zero diffs; the eee collect already applied everything.
  - TRANSLATION_CONTRACT.md digest constants current (886c5e27060e7b30 /
    1b166ae6a7cf8a5c / 056bdd1c330ee8c2).

## SAIT-005: Wintage full translation bundle — fresh EE at 83d3d1e, payload already live (converge closure)

- **status:** stale
- **superseded_by:** SAIT-006 (source_head 83d3d1e -> 8867967 at the T-187 v1.26.4 ship)
- **summary:** Converge stage-K fresh EE bound to the post-closure HEAD (83d3d1e).
  Full 32-language bundle re-verified against the current identity; the payload
  is already integrated (eee shipped it at fd53d63, nothing touched the
  translation surfaces since), so collect is a content-equivalent no-op: all
  repo surfaces are byte-identical to the kitchen. Freshness identity:
  source_head 83d3d1e, fingerprint c66baf69 (clean delta, .saipen excluded),
  role_revision f241e6b8 (unchanged charter).
- **critical:** false
- **severity:** P3
- **producer:** saitranslate
- **source_head:** 83d3d1e635efa28091c6f05577753f219bf7643d
- **source_tree_fingerprint:** git-delta-v1:c66baf69a8306f3b95dfc7badb5f72b088f8de8408e933efadc4d149721a1195
- **role_revision:** sha256:f241e6b83c39e9b46bfa586638efb0374bbb39889646f723b9189bbb4912c0c5
- **coverage:**
  - docs — README.md: **32 locales** (en source + ru et ded + 29 bundle), all 32
    kitchen README.<lang>.md carry the current digest 886c5e27060e7b30 and the
    post-T-184 release section (CHANGELOG prerequisite named, zero "Edit
    wintage.user.js" hits, switcher bar verbatim).
  - docs — desktop/README.md: **32 locales**, digest 1b166ae6a7cf8a5c current,
    targets table + commands preserved.
  - docs — browser-theme/README.txt: **32 locales**, digest 056bdd1c330ee8c2
    current, T-171 fixed-legacy preamble everywhere.
  - UI strings — desktop/locales/*.json: **33 locales** (en ru et ded + 29),
    49 keys each, exact parity vs en.json, all parse.
- **payload:** the full 32-language kitchen set (README.<lang>.md at kitchen
  root, desktop/README.<lang>.md, browser-theme/README.<lang>.txt, 29 locale
  JSONs) — already live in the repo byte-identical (eee applied at fd53d63;
  desktop/browser/locales were already current even before). Collect = verify
  only; no file needs copying.
- **verified:** PASS -- Freshness identity recomputed with tools/freshness.py at 83d3d1e: (full list under details)
- **instructions:** (1) This is a closure-bar package (CONVERGE.md stage K): it
  exists so `--gate converge` sees EE fresh+ready at the final HEAD. (2)
  Collect via `eee` is optional — it verifies byte-identity (already proven
  here) and marks reviewed; no repo mutation is required. (3) If any future
  source change lands before collect, re-run `ee` first.
- **details:**
  Fresh EE, not reuse: SAIT-004 was collected by `eee` at fd53d63 and the
  qqq wiki ship moved HEAD to 83d3d1e, so the closure bar (CONVERGE.md stage
  M: "bound to the current source identity") demanded a fresh ready package.
  The wiki-only ship touched no translation surface, so regeneration against
  all three freshness inputs is byte/content-equivalent — a legal no-op with
  the rerun verification recorded above. All work under
  .saipen/saitranslate/kitchen/; the main repo tree was not touched by this
  preparation.
  Source-head label dropped: `83d3d1e635efa28091c6f05577753f219bf7643d (project HEAD)`.
  Evidence recorded at preparation time (moved here from the `verified` field, which carries a closed verdict and cannot hold a list):
  - Freshness identity recomputed with tools/freshness.py at 83d3d1e:
    source_head 83d3d1e635efa28091c6f05577753f219bf7643d, fingerprint
    c66baf69 (clean delta, .saipen excluded), role_revision f241e6b8 matches
    the charter's declared YAML value.
  - All 32 kitchen READMEs: current digest 886c5e27060e7b30 (programmatic),
    zero stale release-section hits, switcher bar verbatim in all.
  - All 32 desktop kitchen files carry 1b166ae6a7cf8a5c; all 32 browser-theme
    kitchen files carry 056bdd1c330ee8c2 (programmatic digest match).
  - All 29 locale JSONs parse (json.load) and have exactly 49 keys; key set
    identical to desktop/locales/en.json (0 missing, 0 extra).
  - Byte-identity kitchen vs repo re-confirmed across all three md surfaces
    (root README.<lang>.md 32/32, desktop 32/32, browser-theme 32/32) — zero
    diffs; the eee collect already applied everything.
  - TRANSLATION_CONTRACT.md digest constants current (886c5e27060e7b30 /
    1b166ae6a7cf8a5c / 056bdd1c330ee8c2).

## SAIT-004: Wintage full translation bundle — 32 languages × README/desktop/browser-theme/locales (FORCE-FRESH at 96a1a62)

- **status:** reviewed
- **summary:** Complete 32-language translation bundle re-verified and re-bound to
  current HEAD 96a1a62 (post-T-184 README release-section rewrite). README
  digest refreshed ee7c6a2a -> 886c5e27060e7b30 across all 32 kitchen READMEs;
  desktop/browser-theme surfaces unchanged (digests 1b166ae6 / 056bdd1c
  already current); locale JSONs unchanged (49-key parity intact).
- **critical:** false
- **producer:** saitranslate
- **source_head:** 96a1a6243e1c63f12d575ffcea959961bdb68938
- **source_tree_fingerprint:** git-delta-v1:c66baf69a8306f3b95dfc7badb5f72b088f8de8408e933efadc4d149721a1195
- **role_revision:** sha256:f241e6b83c39e9b46bfa586638efb0374bbb39889646f723b9189bbb4912c0c5
- **coverage:**
  - docs — README.md: **32 locales** (en source + ru et ded + 29 bundle), all 32
    kitchen README.<lang>.md carry the current digest 886c5e27060e7b30 and the
    post-T-184 release section (CHANGELOG prerequisite named, zero "Edit
    wintage.user.js" hits).
  - docs — desktop/README.md: **32 locales**, digest 1b166ae6a7cf8a5c current,
    targets table + commands preserved.
  - docs — browser-theme/README.txt: **32 locales**, digest 056bdd1c330ee8c2
    current, T-171 fixed-legacy preamble everywhere.
  - UI strings — desktop/locales/*.json: **33 locales** (en ru et ded + 29),
    49 keys each, exact parity vs en.json, all parse.
- **payload:** the full 32-language kitchen set (README.<lang>.md at kitchen
  root, desktop/README.<lang>.md, browser-theme/README.<lang>.txt, 29 locale
  JSONs) — the only drift vs the live repo is the root README release section
  (repo root README.ru/et/ded + 29 bundle READMEs still carry digest ee7c6a2a
  and the old release section; desktop/browser ru/et/ded at repo root already
  match kitchen).
- **verified:** PASS -- Freshness identity computed with tools/freshness.py at 96a1a62: (full list under details)
- **instructions:** (1) `eee` collects: apply the 32 kitchen README.<lang>.md
  to repo-root README.<lang>.md (all 32, ru/et/ded included — their repo-root
  copies still carry the old release section + digest ee7c6a2a), the 32
  desktop kitchen files to desktop/README.<lang>.md, the 32 browser-theme
  kitchen files to browser-theme/README.<lang>.txt (desktop/browser ru/et/ded
  already byte-identical — skip or re-verify), and the 29 locale JSONs to
  desktop/locales/ (already live — re-verify parity). (2) After collect, the
  language switcher bar in each root README must stay intact (T-107). (3)
  English sources are not shipped — they live in the repo already.
- **details:**
  FORCE-FRESH, not reuse: SAIT-003 (source_head 2483b49) went stale when T-184
  rewrote README.md's release section (CHANGELOG prerequisite, "Edit
  wintage.user.js" gone) and normalized CRLF->LF, moving the README digest
  ee7c6a2a -> 886c5e27060e7b30. The kitchen READMEs were regenerated against
  the new source in a prior ee pass (uncommitted working-tree diff), and this
  run re-verified the whole bundle programmatically, refreshed the contract
  digest constants, and re-bound the package to 96a1a62. All work under
  .saipen/saitranslate/kitchen/; the main repo tree was not touched by this
  preparation.
  Collected at: 2026-08-10T20:14:00Z (eee, T-185)
  Source-head label dropped: `96a1a6243e1c63f12d575ffcea959961bdb68938 (project HEAD)`.
  Evidence recorded at preparation time (moved here from the `verified` field, which carries a closed verdict and cannot hold a list):
  - Freshness identity computed with tools/freshness.py at 96a1a62:
    source_head 96a1a6243e1c63f12d575ffcea959961bdb68938, fingerprint
    c66baf69 (clean delta, .saipen excluded), role_revision f241e6b8 matches
    the charter's declared YAML value.
  - All 32 kitchen READMEs: current digest 886c5e27060e7b30 (programmatic),
    digest is the FINAL line, switcher bar verbatim in all, zero stale
    release-section hits, zero <img> leaks.
  - All 32 desktop kitchen files carry 1b166ae6a7cf8a5c; all 32 browser-theme
    kitchen files carry 056bdd1c330ee8c2 (programmatic digest match).
  - All 29 locale JSONs parse (json.load) and have exactly 49 keys; key set
    identical to desktop/locales/en.json (0 missing, 0 extra).
  - Root Core-share lag confirmed as expected: repo README.ru/ded still old
    digest (collect applies kitchen); desktop/browser ru at root == kitchen
    byte-identical.
  - TRANSLATION_CONTRACT.md digest constants refreshed to the current values
    (886c5e27060e7b30 / 1b166ae6a7cf8a5c / 056bdd1c330ee8c2) so a future
    batch worker stamps correct markers.

## SAIT-002: Wintage full translation bundle — 29 languages × README/desktop/browser-theme/locales

- **status:** reviewed
- **summary:** Complete 29-language translation bundle across every real surface —
  README, desktop README, browser-theme README, and UI locale JSONs (49 keys each).
  Supersedes the Core-share-only SAIT-001 draft. Collected at T-177 (eee), shipped 26e1d74.
- **critical:** false
- **producer:** saitranslate
- **source_head:** f79229d94b08214e267b8ab9c54b058d88228251
- **source_tree_fingerprint:** git-delta-v1:c66baf69a8306f3b95dfc7badb5f72b088f8de8408e933efadc4d149721a1195
- **role_revision:** sha256:f241e6b83c39e9b46bfa586638efb0374bbb39889646f723b9189bbb4912c0c5
- **coverage:**
  - docs — README.md: **29 languages** complete (ja uk de fr es it pt nl pl sv da fi no
    zh ko th vi ar he tr hi id el cs ro hu bg sk hr), each translated from the
    current English source, carrying the current source-digest. Plus the Core-share
    EN/RU/ET/Дед root copies already live in the repo (README.ru/et/ded.md
    byte-identical, switcher bar preserved).
  - docs — desktop/README.md: **29 languages** complete, each from the current
    English source, correct digest, targets table + commands preserved verbatim.
  - docs — browser-theme/README.txt: **29 languages** complete. Preamble reflects
    the T-171 correction (fixed legacy Dark Golden palette, independent of the
    userscript's switchable palettes), token-mapping table verbatim.
  - UI strings — desktop/locales/*.json: **all 33 locales** (en ru et ded + 29),
    49 keys each, zero gaps vs en.json, loadable by the i18n loader (T-103).
- **payload:**
  - kitchen/README.<lang>.md — 29 files (the 17 pre-existing updated to the T-167
    palette table + current digest; 12 newly translated: uk pt nl pl sv da fi no tr
    cs sk hr)
  - kitchen/desktop/README.<lang>.md — 29 files (17 pre-existing + 12 new)
  - kitchen/browser-theme/README.<lang>.txt — 29 files (17 pre-existing, preamble
    refreshed for T-171 + digest; 12 new)
  - kitchen/locales/<lang>.json — 12 new locale files (uk pt nl pl sv da fi no tr
    cs sk hr)
  - README.ru/et/ded.md at repo root already live (Core share, byte-identical to
    kitchen); locale ru/et/ded.json already live.
  (English sources = README.md / desktop/README.md / browser-theme/README.txt /
  en.json at source_head; no files to ship for EN.)
- **verified:** PASS -- Every one of the 29 languages has all four surfaces present (README, desktop, (full list under details)
- **instructions:** (1) `eee` collects: apply the 29 kitchen README.<lang>.md to
  repo-root README.<lang>.md, the 29 desktop kitchen files to desktop/README.<lang>.md,
  the 29 browser-theme kitchen files to browser-theme/README.<lang>.txt, and the 12
  new locale JSONs to desktop/locales/. (2) The repo-root README.ru/et/ded.md and
  locale ru/et/ded.json are already live — collection must not duplicate or drift
  them (verify byte-identity, they match kitchen). (3) After collect, the language
  switcher bar in each root README must stay intact (T-107). (4) English sources are
  not shipped — they live in the repo already.
- **details:**
  This is the T-102 completion: the dedicated saitranslate instance produced the
  full 29-language bundle. Prior SAIT-001 (Core share only, status draft) is
  superseded. All work under .saipen/saitranslate/kitchen/; the main repo tree was
  not touched by this preparation.
  UPDATE (ee, 08.08.26): dedicated-instance run at 576a03b. 12 missing languages
  translated on every surface (README/desktop/browser-theme/locales); 17 existing
  translations updated: README palette table to the T-167 correction + current
  digest, browser-theme preamble to the T-171 correction + current digest. Full
  29×4 coverage verified programmatically. Status ready.
  Source-head label dropped: `f79229d94b08214e267b8ab9c54b058d88228251 (project HEAD)`.
  Evidence recorded at preparation time (moved here from the `verified` field, which carries a closed verdict and cannot hold a list):
  - Every one of the 29 languages has all four surfaces present (README, desktop,
    browser-theme, locales) — programmatic coverage check: zero missing.
  - README digests: all 29 carry sha256:ee7c6a2a1626faed (current README.md);
    desktop all carry sha256:1b166ae6a7cf8a5c; browser-theme all carry
    sha256:056bdd1c330ee8c2 — all computed from the current sources.
  - Locale JSONs: 12 new all parse (ConvertFrom-Json), 49 keys, exact key parity
    with en.json (0 missing, 0 extra), {0} placeholders and \r\n escapes preserved,
    command examples verbatim.
  - README translations: heading structure / code fences / hex tokens / commands
    preserved; T-167 palette table (real goldendefault hexes) in every existing
    translation, zero stale legacy hexes.
  - browser-theme translations: token-mapping table verbatim, zero leftover
    "Uses the same palette" wording (T-171 correction reflected everywhere).

## SAIT-003: Wintage full translation bundle — 32 languages × README/desktop/browser-theme/locales

- **status:** stale
- **superseded_by:** SAIT-004 (source_head 2483b49 -> 96a1a62 at T-184; README digest moved ee7c6a2a -> 886c5e27060e7b30, release section rewritten)
- **summary:** Complete 32-language translation bundle across every real surface —
  README, desktop README, browser-theme README, UI locale JSONs. Supersedes
  SAIT-002 (added Core-share ru/et/ded to the desktop and browser-theme surfaces
  at T-179). Collected at sc stage 5 — repo mirrors kitchen byte-for-byte.
- **critical:** false
- **producer:** saitranslate
- **source_head:** 2483b4989f3da4b9f42d03b46cbb48ecff7c9340
- **source_tree_fingerprint:** git-delta-v1:c66baf69a8306f3b95dfc7badb5f72b088f8de8408e933efadc4d149721a1195
- **role_revision:** sha256:f241e6b83c39e9b46bfa586638efb0374bbb39889646f723b9189bbb4912c0c5
- **coverage:**
  - docs — README.md: **32 locales** (en source + ru et ded + 29 bundle), all
    carrying the current source-digest. EN/RU/ET/Дед live at repo root; 29 bundle
    translated from current source.
  - docs — desktop/README.md: **32 locales**, each with current digest, targets
    table + commands preserved verbatim. Core-share ru/et/ded added at T-179.
  - docs — browser-theme/README.txt: **32 locales**, T-171 fixed-legacy preamble
    everywhere, token-mapping table verbatim. Core-share ru/et/ded added at T-179.
  - UI strings — desktop/locales/*.json: **33 locales** (en ru et ded + 29),
    49 keys each, zero gaps vs en.json.
- **payload:** the full 32-language kitchen set (README.<lang>.md at root,
  desktop/README.<lang>.md, browser-theme/README.<lang>.txt, locale JSONs) —
  byte-identical to the live repo copies; collect is a no-op re-verify unless the
  repo drifted.
- **verified:** PASS -- kitchen ↔ repo byte-identical for all ru/et/ded on all three surfaces (programmatic hash check, zero drift); 29×4 bundle coverage complete; locale JSONs parse with exact en.json key parity; all digests current (README ee7c6a2a, desktop 1b166ae6, browser-theme 056bdd1c). (original wording under details)
- **instructions:** (1) `eee` collects — but the repo copies already match the
  kitchen byte-for-byte (T-177 shipped the 29, T-179 shipped ru/et/ded), so
  collect is a re-verify no-op. (2) If the repo ever drifts from kitchen, re-apply
  the corresponding files. (3) After collect, language switcher bars must stay
  intact.
- **details:**
  FORCE-FRESH at 2483b49 after T-178/T-179 (sc circuit stage 5). T-178 added
  digest markers to Core-share READMEs; T-179 translated ru/et/ded for the
  desktop and browser-theme surfaces and synced kitchen. Kitchen is the single
  source of truth; repo mirrors verified current. All work under
  .saipen/saitranslate/kitchen/.
  Source-head label dropped: `2483b4989f3da4b9f42d03b46cbb48ecff7c9340 (project HEAD)`.
  Evidence recorded at preparation time (moved here from the `verified` field, which carries a closed verdict and cannot hold a list):
  `verified` as written (prose, not a closed verdict; moved here verbatim): kitchen ↔ repo byte-identical for all ru/et/ded on all three surfaces (programmatic hash check, zero drift); 29×4 bundle coverage complete; locale JSONs parse with exact en.json key parity; all digests current (README ee7c6a2a, desktop 1b166ae6, browser-theme 056bdd1c).
