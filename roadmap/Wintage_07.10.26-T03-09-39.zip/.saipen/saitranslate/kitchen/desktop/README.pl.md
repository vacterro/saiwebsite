# Wintage dla aplikacji desktopowych

Userskrypt motywuje sieć. To motywuje otaczające ją programy, z tych samych
palet, żeby przeglądarka i aplikacje przestały się nie zgadzać co do tego, co
znaczy ciemne złoto.

Za każdą decyzją tutaj stoi jedna zasada: **aplikacje aktualizują się same, a
aktualizacja nie może po cichu niczego zepsuć.** Tam, gdzie target ma miejsce w
twoim własnym profilu, motyw trafia tam i przetrwa aktualizacje. Tam, gdzie nie ma,
instalator jest napisany tak, by można go było uruchomić ponownie — i mówi to
wprost, zamiast udawać, że coś utrwalił.

## GUI

Kliknij dwukrotnie **`Wintage Installer.vbs`** w katalogu głównym repo, aby go
otworzyć bez okna konsoli, albo uruchom bezpośrednio to, do celów diagnostycznych:

```powershell
powershell -File desktop\WintageInstaller.ps1
```

Lista motywów z próbkami kolorów, targety znalezione na tej maszynie, podgląd
Win95 na żywo oraz wszystkie dwadzieścia jeden tokenów kolorów jako edytowalne
próbki. Edycja dowolnej próbki rozgałęzia paletę na **Custom**, zamiast zmieniać
dostarczony motyw pod tobą. Panel po prawej pokazuje na żywo kontrast WCAG dla
trzech tokenów niosących tekst — paleta, która tam nie przechodzi, i tak zostanie
odrzucona przez bramkę builda, więc lepiej zobaczyć to przed Apply niż po.

Targety są podzielone na dwie osiągalne z klawiatury listy: **MY APPS** zawiera
przenośne/drzewo-źródłowe narzędzia CodeNomad, WorkBuddy;
**POPULAR APPS** zawiera Windows, OBS, terminale, edytory i inne zainstalowane
oprogramowanie. ALL/NONE i Apply/Revert działają na obu listach bez zmiany ich
grupowania.

Okno nosi paletę, którą ma zaraz zainstalować. To najszybszy dostępny podgląd i
utrzymuje narzędzie uczciwym: paleta, która czyni to okno nieczytelnym, jest
widocznie nieczytelna.

Apply wywołuje `install.ps1`. Jest dokładnie jedna ścieżka kodu instalująca
motyw, więc GUI nie może oddalić się od linii poleceń.

## Linia poleceń

```powershell
.\desktop\install.ps1                                  # co tu jest, co jest motywowane i jaką paletą
.\desktop\install.ps1 -Target freebuff -Palette klite  # jedna aplikacja, jedna paleta
.\desktop\install.ps1 -Target all -Palette goldendefault # wszystko
.\desktop\install.ps1 -Target all -WhatIf              # pokaż, co by się zmieniło, niczego nie dotykaj
.\desktop\install.ps1 -Target freebuff -Revert         # cofnij jedną
```

`-Palette` domyślnie przyjmuje `goldendefault` (**Golden Default**). GUI otwiera
się na tej samej palecie i sprawdza każdy dostępny target. Przemalowanie aplikacji,
która już jest motywowana, działa, gdy działa ona na bieżąco; pierwsza instalacja
nie, bo archiwum jest w użyciu.

## Co właściwie można zmotywować w każdym targetu

| target | mechanizm | przetrwa aktualizację aplikacji |
|---|---|---|
| `windows` | `.theme` użytkownika: ciemny tryb systemu/aplikacji, kolor akcentu i klasyczne role kolorów | yes — zainstalowany w twoim lokalnym folderze Windows Themes |
| `browsers` | wykrywa zainstalowane + przenośne profile Chromium, przygotowuje wybrany motyw chrome i otwiera należące do przeglądarki strony potwierdzenia Tampermonkey/motywu | yes — po jednym **Load unpacked** na profil |
| `terminal` | schemat Windows Terminal + domyślne dla wszystkich profili, Consolas 12 aliased | yes — ustawienia są w twoim profilu |
| `conhost` | domyślne `HKCU\Console` + każdy istniejący profil cmd/PowerShell | yes — dokładny snapshot dotkniętych wartości |
| `obs` | wariant `.ovt` dla OBS 30.2+ + aktywny identyfikator motywu w `user.ini` | tak — żyje w twoim profilu |
| `qbittorrent` | rozpakowany motyw UI Qt (`config.json` + `stylesheet.qss`) + dwa klucze motywu w `qBittorrent.ini` | yes — żyje w twoim profilu |
| `antigravity`, `vscode` | rozszerzenie motywu kolorów w `~/.antigravity/extensions` / `~/.vscode/extensions` | **yes** — żyje w twoim profilu |
| `freebuff`, `antigravity-app`, `codenomad` | shim Electrona, patrz poniżej | no — uruchom ponownie instalator |
| `claude` | shim Electrona, łatany na miejscu — patrz poniżej | no — aktualizacja tworzy nowy folder `app-<version>` |
| `mpchc` | rejestr, ciemny motyw + tylko typografia OSD | no — MPC-HC nadpisuje swoje ustawienia przy zamykaniu |
| `obsidian` | motyw społeczności per vault, wszystkie palety zainstalowane naraz | **yes** — żyje w twoim vault |
| `discord` | CSS wrzucony do własnego folderu motywów BetterDiscord | yes |
| `totalcmd`, `totalcmd2` | klucze `wincmd.ini` `[Colors]`; istniejące filtry ostatnich plików używają koloru linku palety | yes — to twój ini |

### Usuwanie reklam FreeBuff

FreeBuff (desktopowa aplikacja asystenta AI) dostarcza własną sieć reklamową:
bundle renderera (`resources/orchestrator/ui/assets/index-*.js`) renderuje kartę
`sponsored-ad` i baner wątku, a orkiestrator (`resources/orchestrator/orchestrator.js`)
udostępnia trasy `/api/ad/slot|impression|click`, które wywołują zdalną aukcję
reklam. Shim tylko motywuje aplikację; nie dotyka tych plików.

`desktop/patch-freebuff-ads.js` wycina reklamy na poziomie bajtów:

- renderer: miejsca wywołań karty/banera reklamy stają się `null`, a metody klienta
  API `adSlot` / `adImpression` / `adClick` stają się no-opami — nic się nie
  renderuje i żaden `/api/ad/*` nie opuszcza renderera;
- orkiestrator: wszystkie trzy trasy `/api/ad/*` przestają wywoływać sieć
  reklamową, a inline'owe żądanie reklamy przy żywych turach (`maybeRequestAd`)
  jest zwarciowane.

Nazwa pliku bundle'a zawiera hash builda, więc łatka odkrywa bieżący bundle z
`index.html` zamiast dostarczać payload przypięty do wersji — to właśnie pozwala
jej przetrwać aktualizacje. Oryginały są kopiowane zapasowo do
`_orig-backup-<timestamp>/` w katalogu instalacji; `--revert` przywraca najnowszy.

**Przyszłe wersje są obsługiwane na dwóch niezależnych warstwach:**

1. **Łata bajtowa z fallbackami regexowymi.** Każdy target ma dokładny ciąg dla
   bieżącego builda *oraz* fallback oparty na wyrażeniach regularnych, zakotwiczony
   na tym, czego minifier nie może przemianować — literały ścieżek `/api/ad/*`,
   dyskryminator protokołu `case"ad":`, klasa `sponsored-ad` oraz plasowania
   `variant:"banner"` / `variant:"card"`. Orkiestrator nie jest minifikowany
   (czytelne nazwy jak `maybeRequestAd` i `app.ads.slotAd`), więc jego dokładne
   ciągi trzymają się długo; bundle renderera jest minifikowany, więc jego
   fallbacki regexowe przejmują w momencie, gdy następny build przemianuje jego
   identyfikatory.
2. **Blokada na poziomie shima (`targets/electron/shim.cjs`).** Całkowicie
   niezależna od bundle'a: każdy fetch/XHR pod URL `/api/ad/` jest odrzucany
   wewnątrz strony, a każdy element, którego klasa zawiera `sponsored-ad`, jest
   ukrywany w chwili pojawienia się. Nawet całkiem nowy bundle, którego ten skrypt
   się jeszcze nie nauczył, nie może wyświetlić reklamy.

```powershell
node .\desktop\patch-freebuff-ads.js           # łata (najpierw kopia zapasowa)
node .\desktop\patch-freebuff-ads.js --sound "C:\...\my.mp3"   # łata + własny dźwięk zakończenia (wav/mp3/ogg/flac/m4a/aac)
node .\desktop\patch-freebuff-ads.js --scan    # jakie markery reklam niesie TEN build?
node .\desktop\patch-freebuff-ads.js --verify
node .\desktop\patch-freebuff-ads.js --revert
```

Działa automatycznie w ramach `install.ps1 -Target freebuff` i musi być
uruchamiana po każdej aktualizacji FreeBuff (aktualizacje przywracają standardowe
pliki). Jeśli build zmieni kształt, skrypt podaje nazwę targeta, który przestał
pasować — uruchom `--scan`, aby zobaczyć, co nowy build wciąż niesie, i odśwież
tam ciągi.

**Dźwięk zakończenia FreeBuff.** Renderer gra `chime-<hash>.mp3`, gdy tura się
kończy. Łatka znajduje go tak samo, jak znajduje bundle (nazwa zawiera hash
builda), więc `--sound <file>` instaluje nad nim twoje własne audio
(wav/mp3/ogg/flac/m4a/aac) i zachowuje standardowy plik jako `chime-*.mp3.bak`;
`--revert` go przywraca. `--verify` raportuje, który jest aktywny.

### Przycisk dźwięku FreeBuff (GUI)

`WintageInstaller.ps1` ma mały przycisk **FB SOUND** pod stosem APPLY / REVERT.
Zapisuje tylko *preferencję*; `install.ps1 -Target freebuff` czyta ten sam plik i
przekazuje go łatce jako `--sound`, więc reklamy i dźwięk są stosowane w jednym
uruchomieniu:

- **Lewy klik** — wybierz plik audio (OpenFileDialog, wav/mp3/ogg/flac/m4a/aac)
  i od razu go usłyszysz: PCM WAV przez System.Media.SoundPlayer, każdy inny format
  przez WPF MediaPlayer (Media Foundation, asynchronicznie, więc okno nigdy nie
  zamarza). Wybór jest zapamiętywany w
  `%APPDATA%\Wintage\freebuff-sound.txt` (na maszynę, poza checkoutem git,
  dokładnie jak zapamiętane foldery drzewa źródłowego).
- **Prawy klik** — wyczyść preferencję z powrotem do standardowej chime FreeBuff
  (zatrzymuje też każdy wciąż grający podgląd).
- **COPY** — kopiuje wybrane audio do samego repo
  (`sounds\freebuff.<ext>`, zachowując rozszerzenie źródła) i przekierowuje
  preferencję na tę kopię, więc dźwięk przetrwa usunięcie lub przeniesienie
  oryginalnego pliku. Włączony tylko, gdy ustawiony jest własny dźwięk; ponowne
  kopiowanie po prostu nadpisuje kopię w repo. Folder `sounds/` to zwykła treść
  śledzona przez git, więc jej zacommitowanie sprawia, że dźwięk przetrwa też
  ponowne klony.

Podglądane są tylko rozpoznane kontenery audio — nagłówek jest sprawdzany
najpierw, więc wybór nie-audio jest anonsowany zamiast po cichu nic nie grać.

Przycisk pokazuje `ON`, gdy ustawiony jest własny dźwięk; najazd myszą pokazuje
ścieżkę. Zastosuj potem target `freebuff` (zaznacz FreeBuff + APPLY albo uruchom
`install.ps1 -Target freebuff` z terminala), aby zadziałał.

### Terminale

`terminal` zapisuje schemat kolorów `Wintage` do każdego wykrytego stabilnego,
Preview lub nieopakowanego pliku ustawień Windows Terminal i wybiera go przez
`profiles.defaults`, wraz z bezpieczną dla konsoli Consolas 12 i aliased tekstem.
Oryginalny plik jest zachowywany obok bajt po bajcie, a `-Revert` go przywraca.

`conhost` obejmuje klasyczne `cmd.exe`, Windows PowerShell, profile konsoli
Git CMD/Bash i inne istniejące dzieci `HKCU\Console`. Zapisuje pełną 16-kolorową
tabelę palety do domyślnych wartości głównych i każdej istniejącej nadpisywanej
wartości, a potem przywraca tylko wartości, których dotknął. Consolas stosuje tam
też, bo proporcjonalna Verdana koliduje z siatką komórek o stałej szerokości,
której używają oba hosty terminali.

### Przeglądarki i Tampermonkey

`browsers` znajduje profile Chrome, Edge, Brave, Cent, Vivaldi i Opera w
zainstalowanych lokalizacjach i z przenośnego katalogu głównego, na który go
wskazesz (`-PortableRoot`, albo zapamiętany wpis `portable` w `paths.json`). Jego
status pokazuje liczbę profili i to, ile z nich zawiera Tampermonkey. Apply kopiuje
wybrany motyw browser-chrome do stabilnego folderu
`%LOCALAPPDATA%\Wintage\browser-theme`, umieszcza tę ścieżkę w schowku i otwiera
każdy dokładny profil na `chrome://extensions` oraz stronę Instalacji/Aktualizacji
userskryptu Wintage. Profile bez Tampermonkey dostają też stronę Chrome Web Store.

Chromium celowo zabrania cichej instalacji rozszerzeń spoza sklepu na
niezarządzanym komputerze z Windows. Pierwsza instalacja motywu przeglądarki
wymaga więc jednego potwierdzenia **Developer mode → Load unpacked** na profil.
Wybierz skopiowaną ścieżkę; potem Wintage wciąż podmienia ten sam stabilny folder,
gdy palety się zmieniają. Potwierdź też **Install/Update** w Tampermonkey. Żaden
plik `Preferences` przeglądarki, Secure Preferences ani LevelDB Tampermonkey nie
jest edytowany za plecami przeglądarki. Jeśli Tampermonkey nie było, zainstaluj je
z otwartej karty sklepu i odśwież już otwartą kartę `wintage.user.js`, aby dostać
ekran Install.

### Windows

`windows` instaluje i natychmiast aktywuje adresowany treściowo
`%LOCALAPPDATA%\Microsoft\Windows\Themes\Wintage-<hash>.theme`. Zaczyna od
aktywnego motywu i zastępuje tylko udokumentowane sekcje kolorów, kursorów i stylu
wizualnego. Tapeta, dźwięki i ikony pulpitu pozostają niezmienione; kursory celowo
przełączają się na zainstalowany schemat `___CURRENT___`. Pierwszy aktywny motyw
jest zapisywany bajt po bajcie jako `Wintage.original.theme`; zmiany palety
zachowują tę bazę, a `-Revert` aktywuje ją ponownie. Nowoczesne kontrolki Windows
nadal pochodzą z podpisanego stylu wizualnego Aero — Wintage zmienia wspierany
przez niego ciemny tryb, akcent i klasyczne wejścia kolorów systemowych, zamiast
zastępować chronione pliki `.msstyles`. Aktywne i nieaktywne paski tytułowe
dzielą przytłumiony kolor podniesionej powierzchni palety; jasny highlight
pozostaje zarezerwowany dla krawędzi tekstu/zaznaczenia. Poprzedni akcent
nieaktywnego paska jest snapshotowany osobno i przywracany dokładnie przez
`-Revert`. Hash treści daje Windowsowi nowy cel asocjacji plików, gdy ta sama
paleta jest przebudowywana, więc ponowne zastosowanie zaktualizowanej palety nie
jest mylone z no-opem; wyprzedzony plik Wintage jest usuwany, gdy Windows
potwierdzi, że nowy jest aktywny.

### OBS Studio

`obs` generuje wariant OBS 30.2+ na bazie utrzymywanego Yami Classic, instaluje go
w `%APPDATA%\obs-studio\themes` i zapisuje jego stabilny identyfikator motywu do
`user.ini`, więc wybrana paleta Wintage jest już wybrana przy następnym uruchomieniu.
Zamknij OBS przed Apply lub Revert: OBS nadpisuje `user.ini` przy zamykaniu.
Pierwszy apply robi kopię zapasową zarówno poprzedniego wyboru, jak i każdego
motywu o tej samej nazwie, bajt po bajcie.

### qBittorrent

`qbittorrent` zapisuje **rozpakowany** motyw interfejsu Qt w `%APPDATA%\qBittorrent\themes\wintage` — plik `config.json` (role `Palette.*` oraz własne kolory kontekstowe qBittorrenta: stany listy transferów, wagi dziennika) i obok niego `stylesheet.qss` (2px fazowania, proste narożniki i Verdana, czego paleta nie potrafi wyrazić) — a następnie kieruje `General\CustomUIThemePath` na ten `config.json` i ustawia `General\UseCustomUITheme=true`.
Rozpakowany, a nie jako pakiet `.qbtheme` — celowo: `.qbtheme` to plik Qt Resource Collection i do jego wytworzenia potrzebny byłby na maszynie plik `rcc` o zgodnej wersji głównej, czyli zależność od kompilatora dla dwóch plików tekstowych. qBittorrent czyta postać folderu natywnie (`FolderThemeSource`).
Zamknij qBittorrent przed Apply lub Revert: przy zakończeniu nadpisuje cały `qBittorrent.ini`, więc zmiana wykonana podczas jego pracy przepada przy zamknięciu — cel odmawia działania w tym stanie, zamiast zgłaszać sukces, który zmiecie następne zakończenie. `-Revert` przywraca dwa klucze INI do dokładnych wartości sprzed Wintage (albo je usuwa, jeśli ich nie było) i odkłada z powrotem każdy folder motywu o tej samej nazwie, bajt po bajcie; niezwiązane zmiany w `qBittorrent.ini` wykonane po Apply przetrwają.
Nieosiągalne: ikony paska narzędzi i zasobnika pochodzą z własnego skompilowanego pakietu zasobów qBittorrenta, więc zachowują oryginalne kolory.

### Czcionki: nazwane, nigdy nieinstalowane

Prawo 1 z UI.md wymaga Verdana **bez antyaliasingu**. Arkusz stylów Qt nie ma takiej właściwości, a `OSDFont` w MPC-HC to zwykła nazwa czcionki GDI — jedyną dźwignią jest więc sama czcionka. `Verdana_m1.ttf` w katalogu głównym repozytorium to kopia Verdany z wstępnie wyrenderowanymi kreskami bitmapowymi 1 bpp w zakresie 3–30 ppem, których renderer używa zamiast wygładzania konturu.
Arkusze stylów `qbittorrent` i `obs` wskazują `Verdana_m1, Verdana`, a `mpchc` wskazuje tę z dwóch, którą maszyna faktycznie rozwiązuje. **Instalator nigdy nie instaluje ani nie odinstalowuje czcionki** i to jest celowe, a nie niedokończone:
Rodzinę czcionek rozwiązuje się przez (rodzina, styl). Zarejestruj Regular + Bold + Italic, a każdy odbiorca rozwiąże się poprawnie; wyrejestruj **jeden** element, a każdy odbiorca proszący o tę rodzinę zostanie przekierowany na element, który przetrwał. Na maszynie, która aliasuje `MS Shell Dlg 2` — czcionkę okien dialogowych Windows — do tej rodziny przez `HKLM\...\FontSubstitutes`, usunięcie Regular czyni **cały pulpit pochyłym**, łącznie z tytułami okien, które DWM już zapisał w pamięci podręcznej, a odzyskanie wymaga wylogowania. Żadna liczba referencji tego nie naprawi: zasięg jest ogólnomaszynowy, a instalator motywu nie ma tam czego szukać.
Czcionka jest więc jednorazowym, jawnym działaniem użytkownika: prawym przyciskiem na `Verdana_m1.ttf` → **Instaluj** (dla użytkownika, bez uprawnień administratora), a potem zastosuj cel ponownie. Jeśli czcionki brakuje, cele mówią to raz, nazywają poprawkę i wracają do stockowej Verdany — z antyaliasingiem, ale bez robienia czegokolwiek twojej maszynie za twoimi plecami.

### Aplikacje Electron

`resources/app.asar` jest przenoszone do `resources/app/app.asar` (jego
`app.asar.unpacked`-bliźniak podąża za nim — to parowanie jest po nazwie pliku, a
rozdzielenie ich psuje każdy natywny moduł), a mały `shim.cjs` zajmuje zwolniony
slot `resources/app`. Shim wstrzykuje arkusz stylów, a potem ładuje oryginalne
archiwum. **Żaden bajt aplikacji nie jest nadpisywany**, tylko przenoszony;
`-Revert` przenosi go z powrotem wprost.

Arkusz stylów nie jest pisany dla tych aplikacji — jest wyodrębniany z
`wintage.user.js`, więc każda poprawka bevelów, pasków przewijania i drabinki
typograficznej zrobiona dla przeglądarki ląduje też tutaj, bez drugiej kopii, która
mogłaby zgnić.

Dwie notatki, które warto znać z wyprzedzeniem:

- Oczywiste podejście — wrzucenie `resources/app` obok archiwum i poleganie na
  tym, że Electron je preferuje — **nie działa i zawodzi po cichu**. Electron
  szuka najpierw `app.asar`. Aplikacja startuje idealnie, a motyw nigdy nie działa.
- Shim jest celowo `.cjs`, nie `.js`. Jego `package.json` jest kopiowany z
  własnego pliku aplikacji, żeby aplikacja zachowała nazwę i wersję (nazwa decyduje,
  gdzie mieszka userData — shim, który ją przemianuje, przenosi aplikację do
  pustego profilu). Jeśli ten manifest mówi `"type": "module"`, `.js`-shim pada
  na pierwszym `require`.

### Aplikacja desktopowa Claude: na miejscu i w ramce, w której faktycznie rysuje

Claude nie może użyć powyższego przeniesienia, bo `OnlyLoadAppFromAsar` jest
wtopione: Electron ładuje `resources/app.asar` i nic poza tym, więc shim w
`resources/app` nigdy nie zadziała. Zamiast tego jest łatany **na miejscu**:
archiwum jest kopiowane zapasowo, `main` w jego `package.json` jest nadpisywany na
`"../wintage-shim.cjs"` (wypełnione do tej samej długości bajtów, więc każdy offset
w archiwum pozostaje ważny), a hash integralności per plik jest aktualizowany, by
pasował. `-Revert` przywraca kopię zapasową.

Instalator czyta fuses wciąż **zanim cokolwiek przeniesie** i odmawia z podaniem
powodu, gdy go blokują — `EnableEmbeddedAsarIntegrityValidation` sprawiłby, że
powyższe nadpisanie padłoby przy starcie, a nie przy instalacji. Sprawdź sam
dowolną aplikację:

```powershell
node ..\tools\electron-fuses.js "<path to the app's exe>"
```

Druga połowa tego była znacznie cichszym problemem. `BrowserWindow` Claude'a
renderuje cienką powłokę, a **cała widoczna aplikacja to `WebContentsView`**
przyczepiona do niej. Shim hakował kiedyś `browser-window-created`, więc
wstrzykiwał arkusz stylów do powłoki, raportował sukces do `wintage-status.txt` i
nie zmieniał niczego, co dałoby się zobaczyć. Teraz hakiuje `web-contents-created`,
co obejmuje zawartość okien, `WebContentsView`, `BrowserView`, gości `<webview>`
i popupy równo.

### Obsidian

Motyw społeczności jest zapisywany do `.obsidian/themes/` każdego vaulta — wszystkie
szesnaście palet naraz, dokładnie jak przy targetu VS Code, więc przełączasz się
między nimi w **Settings → Appearance** bez ponownego uruchamiania czegokolwiek.
Szablon pochodzi z ręcznie zrobionego motywu `VintageWin95`, który już był we
vaultcie, każdy kolor zastąpiony tokenem, któremu był równy. `-Palette <slug>`
ustala, który jest aktywny przy instalacji; `appearance.json` jest najpierw
kopiowany zapasowo, a `-Revert` usuwa tylko motywy `Wintage *` i przywraca twoje
poprzednie wybory — ręcznie zrobiony motyw w tym samym vaultcie nigdy nie jest
dotykany.


### MPC-HC (K-Lite)

Natywne Win32, bez arkusza stylów i bez punktu wstrzyknięcia, a kolory jego
ciemnego motywu są skompilowane w program — żadna wartość rejestru ich nie
ujawnia. Więc ten target **nie może nieść palety**. Co robi: włącza ciemny motyw i
stosuje do OSD zasady typografii z UI.md — jedyną powierzchnię, którą MPC-HC
pozwala użytkownikowi kontrolować. Poprzednie ustawienia są najpierw eksportowane
do `desktop/backup/mpc-hc-settings.reg`.

Zamknij MPC-HC przed zastosowaniem: nadpisuje swoje ustawienia przy zamykaniu.

## Przebudowa

Wszystko pod `desktop/out/` jest generowane z `themes/*.json`. Nie jest śledzone
w git (T-160), więc świeży klon musi je zbudować raz, zanim zainstaluje:

```powershell
node ..\tools\build-desktop.js          # przebuduj wszystkie targety
node ..\tools\build-desktop.js --check  # wyjście 1, jeśli cokolwiek jest nieaktualne
```

`release.ps1` uruchamia build i każdą bramkę, więc wydanie nie może dostarczyć
wyniku, który oddalił się od palet.

<!-- T-311 target/section coverage supplement -->
## Pokrycie targetów i sekcji

Ta sekcja odzwierciedla pokrycie Process Explorer, Notepad++, Cinema 4D i czcionek terminalowych z bieżącego angielskiego README, żeby ta lokalizacja nie została po cichu nieaktualna. Literały kodu (identyfikatory targetów, ścieżki rejestru, nazwy plików) są z założenia niezależne od języka; tekst wokół nich jest przetłumaczony.

### Co z każdego targetu naprawdę da się ostylować (nowe targety)

| target | mechanizm | przetrwa aktualizację aplikacji |
|---|---|---|
| `notepadplusplus` | XML motywu + alias do twojego folderu `themes` w Notepad++ | tak — mieszka w twoim profilu |
| `cinema4d` | schemat kolorów włożony do twojego folderu `schemes` w Cinema 4D | tak — mieszka w twoim profilu |
| `processexplorer` | `HKCU\Software\Sysinternals\Process Explorer`: kolory podświetlenia wierszy i tła wykresów, zobacz niżej | nie — Process Explorer przepisuje własne ustawienia przy zamykaniu; zamknij go i uruchom ponownie |

### Process Explorer (Sysinternals)

Process Explorer trzyma swoje kolory w `HKCU\Software\Sysinternals\Process Explorer` i przepisuje ten klucz przy zamykaniu, więc target **odmawia, gdy działa `procexp`, `procexp64` lub `procexp64a`** — zamknij go i uruchom ponownie. Ostylowuje on konfigurowalne kategorie kolorów:

- **osiągalne**: kolory podświetlenia wierszy procesów (`ColorOwn`, `ColorServices`, `ColorRelocatedDlls`, `ColorImmersive`, `ColorPacked`, `ColorJobs`, `ColorNet`, `ColorProtected`, `ColorNewProc`, `ColorDelProc`, `ColorSuspend`) zarówno w wariancie jasnego motywu, jak i w ich wariantach `*Dark`, plus tła wykresów (`ColorGraphBk`, `ColorGraphBkDark`) — łącznie 24 wartości. Każdy wariant jest mieszany z biegunem pasującym do aktywnej palety (jaśniejszy odcień dla wypełnienia w trybie jasnym, ciemniejszy dla `*Dark`), więc wypełnienia wierszy zostają w odcieniu samej palety, zamiast pastelizować się niemal na biel;
- **nieosiągalne**: pasek tytułu, pasek menu, pasek narzędzi, tło i kolory tekstu w widoku listy oraz kolory linii wykresów — są wbudowane w `procexp.exe` i żadna wartość ustawienia ich nie odsłania. Target ostylowuje podświetlenia wierszy i tło wykresu, które naprawdę posiada, i nie twierdzi nic ponadto.

Każda wartość, którą Apply może zmienić, jest zapisywana jako migawka przed zmianą (odzyskanie przy pierwszym dotknięciu w `%APPDATA%\Wintage\recovery\processexplorer\`) i przywracana co do bajtu przez `-Revert`, wraz z informacją, czy wartość nie istniała i czy znacznik był obecny, ale pusty. Przenośny folder poza standardowymi katalogami Sysinternals jest zapamiętywany przez kanoniczny klucz `paths.json` o nazwie `processexplorer` (argument wiersza poleceń `-ProcessExplorerPath`; GUI potrafi go również wybrać).

### Czcionki terminala (`fonts/terminal/`)

Oba targety terminala czytają JEDNĄ kanoniczną preferencję typograficzną z `%APPDATA%\Wintage\terminal-font.json` (`schema`, `fontSlug`, `family`, `size`, `renderingMode`). Gdy pliku nie ma, targety zachowują dostarczoną wartość domyślną (Terminus (TTF) for Windows, 12 pt, aliased), więc istniejące maszyny pozostają bez zmian. Uszkodzona preferencja zawodzi w sposób zamknięty: nic nie jest nadpisywane, a target odmawia.

`fonts/terminal/catalog.json` to jedyny katalog czcionek: 20 dołączonych otwartoźródłowych rodzin monospace plus dwa kroje systemowe, które Wintage nazywa, ale nigdy nie dostarcza (Terminus (TTF) for Windows, Consolas). Każdy dołączony wpis niesie swoje źródło upstream, przypiętą rewizję, identyfikator licencji, plik licencji i SHA-256. Dokładne pliki są dostarczone w `fonts/terminal/files/`, a ich teksty licencji w `licenses/`; działający Wintage pracuje w pełni offline i nigdy nie pobiera czcionki.

`tools/sync-terminal-fonts.ps1` to pobieracz zarezerwowany dla utrzymujących. Czyta `fonts/terminal/sources.json` (jeden niezmienny artefakt na rodzinę), weryfikuje każde SHA-256 i odmawia przy niezgodności. `-VerifyOnly` (domyślnie) sprawdza drzewo na dysku bez sieci; `-Fetch -Write` dostarcza pliki ponownie. Pobrane bajty czcionek są traktowane jako niezaufane zasoby binarne — haszowane i zapisywane, nigdy uruchamiane. Jedna podmiana jest zarejestrowana: **Fantasque Sans Mono** zastępuje Liberation Mono, które nie publikuje żadnego przypiętego wydania binarnego (tylko źródłowe `.sfd`).

Instalator **przegląda czcionki, nie instaluje ich.** Zakładka TERMINAL FONTS wczytuje dołączony krój do lokalnej dla procesu kolekcji `PrivateFontCollection` na żywy podgląd, który wykonuje **zero** systemowych rejestracji czcionek. Wybór czcionki, rozmiaru (7–24 pt) lub trybu renderowania (aliased/grayscale/cleartype) aktualizuje tylko podgląd i preferencję. Instalacja czcionki to osobne działanie **INSTALL SELECTED**, które otwiera własny instalator czcionek systemu Windows; po potwierdzeniu przez Windows użytkownik sprawdza ponownie przyciskiem Refresh. Rzeczywiste zmiany terminala zachodzą dopiero przy jawnym **APPLY TERMINAL / APPLY CONHOST / APPLY BOTH**.

Windows Terminal jest stosowany do wybranej zainstalowanej rodziny w wybranym rozmiarze, a tryb renderowania mapuje się na `profiles.defaults.antialiasingMode`. Klasyczny conhost jest surowszy: renderuje na stałej siatce komórek, więc wybrany krój zostaje odrzucony przed jakąkolwiek zmianą w rejestrze, chyba że Windows potrafi go rozwiązać (krój domyślny i zapasowy Consolas są zwolnione). Health i Reapply weryfikują skonfigurowany krój, rozmiar i wygładzanie względem preferencji, więc zmiana preferencji po Apply jest raportowana jako odchylenie, a nie jako stan "zdrowy". Cykl życia kolorów terminala pozostaje nietknięty: Revert przywraca dokładne wartości posiadane przed Wintagem i nigdy nie usuwa czcionki z maszyny.
<!-- source-digest: desktop/README.md sha256:15c96dac8494ab84 -->
