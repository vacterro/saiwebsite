# Wintage for skrivebordsapplikasjoner

Userscriptet temasetter nettet. Dette temasetter programmene rundt det, fra de samme palettene, slik at nettleseren og appene slutter å være uenige om hva mørkt gull betyr.

Det er én regel bak hver beslutning her: **applikasjoner oppdaterer seg selv, og en oppdatering må ikke stille bryte noe.** Der et mål har en plass i din egen profil, går temaet dit og overlever oppdateringer. Der det ikke har det, er installatøren skrevet for å kjøres på nytt — og sier ifra, i stedet for å late som om det vedvarte.

## GUI-en

Dobbeltklikk **`Wintage Installer.vbs`** i repo-roten for å åpne den uten konsollvindu, eller kjør dette direkte for diagnostikk:

```powershell
powershell -File desktop\WintageInstaller.ps1
```

Temaliste med fargebrikker, målene som er funnet på denne maskinen, en live Win95-forhåndsvisning og alle tjueen fargetokener som redigerbare swatches. Å redigere en swatch gafler paletten til **Custom** i stedet for å endre et utlevert tema under deg. Panelet til høyre viser live WCAG-kontrast for de tre tokenene som bærer tekst — en palett som feiler der blir uansett avvist av byggeporten, så det er bedre å se det før Apply enn etter.

Målene er delt i to lister som nås med tastatur: **MY APPS** inneholder de bærbare/kilde-tre-verktøyene CodeNomad, WorkBuddy; **POPULAR APPS** inneholder Windows, OBS, terminaler, editorer og den andre installerte programvaren. ALL/NONE og Apply/Revert virker på begge listene uten å endre grupperingen.

Vinduet bærer paletten den er i ferd med å installere. Det er den raskeste forhåndsvisningen som finnes, og det holder verktøyet ærlig: en palett som gjør dette vinduet uleselig, er synlig uleselig.

Apply delegerer til `install.ps1`. Det er nøyaktig én kodebane som installerer et tema, så GUI-en kan ikke drive bort fra kommandolinjen.

## Kommandolinjen

```powershell
.\desktop\install.ps1                                  # hva er her, hva er tematisert, med hvilken palett
.\desktop\install.ps1 -Target freebuff -Palette klite  # én app, én palett
.\desktop\install.ps1 -Target all -Palette goldendefault # alt
.\desktop\install.ps1 -Target all -WhatIf              # si hva som ville endret seg, ikke rør noe
.\desktop\install.ps1 -Target freebuff -Revert         # angre én
```

`-Palette` er som standard `goldendefault` (**Golden Default**). GUI-en åpner på samme palett og sjekker alle tilgjengelige mål. Å male om en app som allerede er tematisert, fungerer mens den kjører; en første installasjon gjør ikke det, fordi arkivet er i bruk.

## Hva hvert mål faktisk kan tematiseres

| mål | mekanisme | overlever en app-oppdatering |
|---|---|---|
| `windows` | bruker-`.theme`: mørk system/app-modus, aksent og klassiske fargeroller | ja — installert i din lokale Windows Themes-mappe |
| `browsers` | oppdager installerte + bærbare Chromium-profiler, legger til rette for det valgte chrome-temaet og åpner nettleserens egne Tampermonkey-/temabekreftelsessider | ja etter én **Load unpacked** per profil |
| `terminal` | Windows Terminal-skjema + standarder for alle profiler, Consolas 12 med alias | ja — innstillingene ligger i profilen din |
| `conhost` | `HKCU\Console`-standarder + alle eksisterende cmd/PowerShell-profiler | ja — nøyaktig øyeblikksbilde av berørte verdier |
| `obs` | OBS 30.2+ `.ovt`-variant + aktiv `user.ini`-tema-ID | ja — det ligger i profilen din |
| `qbittorrent` | utpakket Qt-uitema (`config.json` + `stylesheet.qss`) + de to temanøklene i `qBittorrent.ini` | ja — det ligger i profilen din |
| `antigravity`, `vscode` | fargetema-utvidelse i `~/.antigravity/extensions` / `~/.vscode/extensions` | **ja** — det ligger i profilen din |
| `freebuff`, `antigravity-app`, `codenomad` | Electron-shim, se nedenfor | nei — kjør installatøren på nytt |
| `claude` | Electron-shim, patchet på plass — se nedenfor | nei — en oppdatering lager en ny `app-<versjon>`-mappe |
| `mpchc` | register, mørkt tema + OSD-typografi kun | nei — MPC-HC skriver om innstillingene sine ved avslutning |
| `obsidian` | fellesskapstema per hvelv, alle paletter installert samtidig | **ja** — det ligger i hvelvet ditt |
| `discord` | CSS sluppet inn i BetterDiscords egen temamappe | ja |
| `totalcmd`, `totalcmd2` | `wincmd.ini` `[Colors]`-nøkler; eksisterende nylige-fil-filtre bruker palettens lenkefarge | ja — det er din ini |

### FreeBuff-annonsefjerning

FreeBuff (AI-assistent-skrivebordsappen) leverer sitt eget annonsenettverk: renderer-bundlen (`resources/orchestrator/ui/assets/index-*.js`) gjengir et `sponsored-ad`-kort og en trådbanner, og orkestratoren (`resources/orchestrator/orchestrator.js`) eksponerer `/api/ad/slot|impression|click`-ruter som kaller den eksterne annonseauksjonen. Shim-en tematiserer bare appen; den rører ikke disse filene.

`desktop/patch-freebuff-ads.js` kutter ut annonsene på bytenivå:

- renderer: annonsekort-/banner-kallepunktene blir `null`, og API-klientmetodene `adSlot` / `adImpression` / `adClick` blir no-ops — ingenting gjengis, og ingen `/api/ad/*`-forespørsel forlater rendereren;
- orkestrator: alle tre `/api/ad/*`-rutene slutter å kalle annonsenettverket, og den innebygde annonseforespørselen for levende tur (`maybeRequestAd`) kortsluttes.

Bundlenavnet inneholder en bygge-hash, så patchen finner den gjeldende bundlen fra `index.html` i stedet for å levere en versjonslåst nyttelast — det er det som gjør at den overlever oppdateringer. Originalene sikkerhetskopieres til `_orig-backup-<tidsstempel>/` i installasjonsmappen; `--revert` gjenoppretter den nyeste.

**Fremtidige versjoner håndteres på to uavhengige nivåer:**

1. **Byte-patch med regex-fallback.** Hvert mål har en eksakt streng for gjeldende bygg *og* en regex-fallback forankret i det en minifiserer ikke kan gi nytt navn — `/api/ad/*`-stilene, `case"ad":`-protokoll-diskriminatoren, `sponsored-ad`-klassen og `variant:"banner"` / `variant:"card"`-plasseringene. Orkestratoren er ikke minifisert (lesbare navn som `maybeRequestAd` og `app.ads.slotAd`), så de eksakte strengene holder lenge; renderer-bundlen er minifisert, så regex-fallbackene tar over i det neste bygget gir identifikatorene nye navn.
2. **Blokkering på shim-nivå (`targets/electron/shim.cjs`).** Helt uavhengig av bundlen: enhver fetch/XHR til en `/api/ad/`-URL avvises inne på siden, og ethvert element hvis klasse inneholder `sponsored-ad` skjules i det det dukker opp. Selv en helt ny bundle som dette scriptet ennå ikke har lært, kan ikke vise en annonse.

```powershell
node .\desktop\patch-freebuff-ads.js           # patch (sikkerhetskopierer først)
node .\desktop\patch-freebuff-ads.js --sound "C:\...\my.mp3"   # patch + tilpasset fullføringslyd (wav/mp3/ogg/flac/m4a/aac)
node .\desktop\patch-freebuff-ads.js --scan    # hvilke annonsemarkører bærer DETTE bygget?
node .\desktop\patch-freebuff-ads.js --verify
node .\desktop\patch-freebuff-ads.js --revert
```

Det kjører automatisk som en del av `install.ps1 -Target freebuff`, og må kjøres på nytt etter hver FreeBuff-oppdatering (oppdateringer gjenoppretter standardfilene). Hvis et bygg endrer form, navngir scriptet målet som ikke lenger matchet — kjør `--scan` for å se hva det nye bygget fortsatt bærer, og oppdater strengene der.

**FreeBuff-fullføringslyd.** Rendereren spiller `chime-<hash>.mp3` når en tur er ferdig. Patchen finner den på samme måte som den finner bundlen (navnet inneholder en bygge-hash), så `--sound <fil>` installerer din egen lyd (wav/mp3/ogg/flac/m4a/aac) over den og beholder standardfilen som `chime-*.mp3.bak`; `--revert` gjenoppretter den. `--verify` rapporterer hvilken som er aktiv.

### FreeBuff-lydknapp (GUI)

`WintageInstaller.ps1` har en liten **FB SOUND**-knapp under APPLY / REVERT-stabelen. Den lagrer bare en *preferanse*; `install.ps1 -Target freebuff` leser samme fil og gir den til patchen som `--sound`, så annonsene og lyden brukes i én kjøring:

- **Venstreklikk** — velg en lydfil (OpenFileDialog, wav/mp3/ogg/flac/m4a/aac) og hør den spilles av umiddelbart: PCM WAV via System.Media.SoundPlayer, alle andre formater via en WPF MediaPlayer (Media Foundation, asynkron, så vinduet aldri fryser). Valget huskes i `%APPDATA%\Wintage\freebuff-sound.txt` (per maskin, utenfor git-sjekkouten, akkurat som de huskede kilde-tre-mappene).
- **Høyreklikk** — tilbakestill preferansen til FreeBuff-standardlyden (stopper også en forhåndsvisning som fortsatt spiller).
- **COPY** — kopierer den valgte lyden inn i selve repoet (`sounds\freebuff.<ext>`, behold kilde-utvidelsen) og peker preferansen på den kopien, så lyden overlever at originalfilen slettes eller flyttes. Aktivert bare mens en tilpasset lyd er satt; å kopiere på nytt overskriver bare repo-kopien. `sounds/`-mappen er vanlig git-sporbart innhold, så å committe den gjør at lyden overlever også re-kloner.

Bare gjenkjente lydcontainere forhåndsvises — overskriften snuses først, så et ikke-lydvalg annonseres i stedet for stille å spille ingenting.

Knappen viser `ON` mens en tilpasset lyd er satt; å holde musepekeren over viser banen. Bruk `freebuff`-målet etterpå (huk av FreeBuff + APPLY, eller kjør `install.ps1 -Target freebuff` fra en terminal) for at det skal tre i kraft.

### Terminaler

`terminal` skriver et `Wintage`-fargeskjema inn i hver oppdagede stabile, Preview- eller uemballerte Windows Terminal-innstillingsfil og velger det via `profiles.defaults`, sammen med konsolltrygg Consolas 12 og aliasert tekst. Den originale filen beholdes byte-for-byte ved siden av, og `-Revert` gjenoppretter den.

`conhost` dekker klassisk `cmd.exe`, Windows PowerShell, Git CMD/Bash-konsollprofiler og andre eksisterende `HKCU\Console`-barn. Den skriver palettens fulle 16-fargetabell både til rotstandardene og til hvert eksisterende overstyr, og gjenoppretter deretter bare verdiene den rørte. Den bruker Consolas også der, fordi proporsjonal Verdana kolliderer innenfor det faste celle-rutenettet som begge terminalverter bruker.

### Nettlesere og Tampermonkey

`browsers` finner Chrome-, Edge-, Brave-, Cent-, Vivaldi- og Opera-profiler fra installerte plasseringer og fra den bærbare roten du peker den mot (`-PortableRoot`, eller den huskede `portable`-oppføringen i `paths.json`). Statusen viser både antall profiler og hvor mange som inneholder Tampermonkey. Apply kopierer det valgte nettleser-chrome-temaet til den stabile `%LOCALAPPDATA%\Wintage\browser-theme`-mappen, legger den banen på utklippstavlen og åpner hver eksakte profil på `chrome://extensions` pluss Wintage-userscriptets Install/Update-side. Profiler uten Tampermonkey får også Chrome Web Store-siden.

Chromium forbyr bevisst stille installasjon av utvidelser utenfor butikken på en uadministrert Windows-maskin. Den første nettlesertemainstallasjonen trenger derfor én **Developer mode → Load unpacked**-bekreftelse per profil. Velg den kopierte banen; etter det fortsetter Wintage å erstatte den samme stabile mappen når paletter endres. Bekreft også **Install/Update** i Tampermonkey. Ingen nettleser-`Preferences`, Secure Preferences eller Tampermonkey-LevelDB-fil redigeres bak ryggen på nettleseren. Hvis Tampermonkey ikke var til stede, installer den fra den åpnede butikkfanen og oppdater den allerede åpne `wintage.user.js`-fanen for å få Install-skjermen.

### Windows

`windows` installerer og aktiverer umiddelbart et innholdsadressert `%LOCALAPPDATA%\Microsoft\Windows\Themes\Wintage-<hash>.theme`. Det starter fra det aktive temaet og erstatter bare de dokumenterte farge-, markør- og visuell-stil-seksjonene. Bakgrunnsbilde, lyder og skrivebordsikoner forblir uendret; markører bytter bevisst til det installerte `___CURRENT___`-skjemaet. Det første aktive temaet lagres byte-for-byte som `Wintage.original.theme`; palettendringer beholder den grunnlinjen, og `-Revert` aktiverer den igjen. Moderne Windows-kontroller kommer fortsatt fra den signerte Aero-visuelle stilen — Wintage endrer dens støttede mørke modus, aksent og klassiske systemfarge-inndata i stedet for å erstatte beskyttede `.msstyles`-filer. Aktive og inaktive titler deler palettens dempede hevede overflatefarge; den lyse markeringen forblir reservert for tekst-/utvalgskanter. Den forrige inaktive tittel-aksenten øyeblikksbildes separat og gjenopprettes nøyaktig av `-Revert`. Innholdshashen gir Windows et nytt filassosiasjonsmål når den samme paletten bygges om, så å bruke en oppdatert palett på nytt ikke forveksles med en no-op; den overstyrte Wintage-filen fjernes etter at Windows bekrefter at den nye er aktiv.

### OBS Studio

`obs` genererer en OBS 30.2+-variant over den vedlikeholdte Yami Classic-basen, installerer den i `%APPDATA%\obs-studio\themes` og skriver den stabile tema-ID-en til `user.ini`, så den valgte Wintage-paletten allerede er valgt ved neste oppstart. Lukk OBS før Apply eller Revert: OBS skriver om `user.ini` ved avslutning. Første bruk sikkerhetskopierer både det forrige valget og ethvert tema med samme navn byte-for-byte.

### qBittorrent

`qbittorrent` skriver et **utpakket** Qt-uitema til `%APPDATA%\qBittorrent\themes\wintage` — en `config.json` (rollene `Palette.*` pluss qBittorrents egne kontekstfarger: tilstander i overføringslisten, loggalvorlighet) og en `stylesheet.qss` ved siden av (2px-fasene, de rette hjørnene og Verdana, som en palett ikke kan uttrykke) — og peker deretter `General\CustomUIThemePath` på den `config.json` og setter `General\UseCustomUITheme=true`.
Utpakket i stedet for en `.qbtheme`-pakke, med vilje: en `.qbtheme` er en Qt Resource Collection-fil og ville kreve en `rcc`-binærfil med samme hovedversjon på maskinen for å bli laget, altså en kompilatoravhengighet for to tekstfiler. qBittorrent leser mappeformen innebygd (`FolderThemeSource`).
Lukk qBittorrent før Apply eller Revert: den skriver hele `qBittorrent.ini` på nytt ved avslutning, så en endring gjort mens den kjører blir forkastet ved lukking — målet nekter å kjøre i den tilstanden i stedet for å rapportere en suksess som neste avslutning sletter. `-Revert` fører de to INI-nøklene tilbake til sine nøyaktige verdier før Wintage (eller fjerner dem hvis de ikke fantes) og legger en eventuell temamappe med samme navn tilbake byte for byte; urelaterte endringer i `qBittorrent.ini` gjort etter Apply overlever.
Ikke tilgjengelig: ikonene i verktøylinjen og systemkurven kommer fra qBittorrents egen kompilerte ressursbunt, så de beholder originalfargene.

### Skrifttyper: navngitt, aldri installert

Lov 1 i UI.md ber Verdana **uten antialiasing**. En Qt-stylesheet har ingen egenskap for det, og MPC-HC sin `OSDFont` er bare et GDI-skriftnavn — så det eneste virkemiddelet er selve skriften. `Verdana_m1.ttf` i depotroten er en kopi av Verdana med forhåndsgjengitte 1bpp bitmap-snitt fra 3 til 30 ppem, som gjengiveren bruker fremfor å glatte konturen.
Stilarkene til `qbittorrent` og `obs` navngir `Verdana_m1, Verdana`, og `mpchc` navngir den av de to maskinen faktisk løser. **Installasjonsprogrammet installerer eller avinstallerer aldri en skrift**, og det er tilsiktet, ikke uferdig:
En skriftfamilie løses etter (familie, stil). Registrer Regular + Bold + Italic, så løser alle forbrukere seg riktig; fjern **ett** medlem, så omdirigerer alle forbrukere som ber om den familien til et gjenværende medlem. På en maskin som aliaser `MS Shell Dlg 2` — Windows-dialogfonten — til den familien via `HKLM\...\FontSubstitutes`, gjør fjerning av Regular **hele skrivebordet kursiv**, også vindustitler DWM alt har bufret, og det kreves utlogging for å få det tilbake. Ingen mengde referansetelling fikser det: virkningsområdet er maskinbredt, og en temainstallatør har ingenting med det å gjøre.
Så skriften er en engangshandling, uttrykkelig fra brukeren: høyreklikk på `Verdana_m1.ttf` → **Installer** (per bruker, ikke nødvendig med admin), og bruk så målet på nytt. Er skriften fraværende, sier målene det én gang, navngir retningen og faller tilbake til standard-Verdana — med antialiasing, men ingenting gjøres ved maskinen bak ryggen din.

### Electron-apper

`resources/app.asar` flyttes til `resources/app/app.asar` (søskenet `app.asar.unpacked` flytter med — den paringen er etter filnavn, og å skille dem bryter hver nativ modul), og en liten `shim.cjs` tar den frigjorte `resources/app`-plassen. Shim-en injiserer stilarket og laster deretter det originale arkivet. **Ingen app-byte skrives om**, bare flyttes; `-Revert` flytter den rett tilbake.

Stilarket skrives ikke for disse appene — det trekkes ut av `wintage.user.js`, så hver fas-, scrollbar- og typestige-fiks laget for nettleseren havner også her, uten en andre kopi å råtne.

To notater verdt å ha på forhånd:

- Den åpenbare tilnærmingen — å slippe `resources/app` ved siden av arkivet og stole på at Electron foretrekker det — **virker ikke og feiler stille**. Electron søker etter `app.asar` først. Appen starter perfekt, og temaet kjører aldri.
- Shim-en er `.cjs`, ikke `.js`, med vilje. Dens `package.json` kopieres fra appens egen, så appen beholder navn og versjon (navnet avgjør hvor userData bor — en shim som gir det nytt navn, flytter appen til en tom profil). Hvis manifestet sier `"type": "module"`, dør en `.js`-shim på sin første `require`.

### Claude-skrivebordsappen: på plass, og rammen den faktisk tegner i

Claude kan ikke bruke flyttingen ovenfor, fordi `OnlyLoadAppFromAsar` er smeltet på — Electron laster `resources/app.asar` og ingenting annet, så en shim i `resources/app` kan aldri kjøre. Den patche i stedet **på plass**: arkivet sikkerhetskopieres, `main` i `package.json` skrives om til `"../wintage-shim.cjs"` (paddet til samme bytelengde, så hver offset i arkivet forblir gyldig), og per-fil-integritetshashen oppdateres til å matche. `-Revert` gjenoppretter sikkerhetskopien.

Installatøren leser fortsatt fuses **før den flytter noe** og nekter med en grunn når de blokkerer — `EnableEmbeddedAsarIntegrityValidation` ville få omskrivingen ovenfor til å feile ved oppstart i stedet for ved installasjon. Sjekk hvilken som helst app selv:

```powershell
node ..\tools\electron-fuses.js "<bane til appens exe>"
```

Den andre halvdelen av dette var et mye stillere problem. Claudes `BrowserWindow` gjengir et tynt skall, og **hele den synlige applikasjonen er en `WebContentsView`** festet til det. Shim-en pleide å koble på `browser-window-created`, så den injiserte stilarket inn i skallet, rapporterte suksess til `wintage-status.txt` og endret ikke noe du kunne se. Den kobler på `web-contents-created` nå, som dekker vindusinnhold, `WebContentsView`-er, `BrowserView`-er, `<webview>`-gjester og popup-vinduer likt.

### Obsidian

Et fellesskapstema skrives inn i hvert hvelvs `.obsidian/themes/` — alle seksten paletter samtidig, nøyaktig som VS Code-målet, så du bytter mellom dem i **Settings → Appearance** uten å kjøre noe på nytt. Malen ble utledet fra det håndlagde `VintageWin95`-temaet som allerede var i hvelvet, hver farge erstattet av tokenet den tilsvarte. `-Palette <slug>` setter hvilken som er aktiv ved installasjon; `appearance.json` sikkerhetskopieres først, og `-Revert` fjerner bare `Wintage *`-temaene og gjenoppretter ditt forrige valg — et håndlaget tema i samme hvelv røres aldri.


### MPC-HC (K-Lite)

Nativ Win32, uten stilark og uten injeksjonspunkt, og fargene i det mørke temaet er kompilert inn i programmet — ingen registerverdi eksponerer dem. Så dette målet **kan ikke bære en palett**. Hva det gjør: slår på det mørke temaet og bruker UI.md-typografireglene på OSD, som er den ene overflaten MPC-HC lar en bruker kontrollere. De forrige innstillingene eksporteres til `desktop/backup/mpc-hc-settings.reg` først.

Lukk MPC-HC før du bruker: det skriver om innstillingene sine ved avslutning.

## Gjenoppbygging

Alt under `desktop/out/` genereres fra `themes/*.json`. Det spores ikke i git (T-160), så en fersk klon må bygge det én gang før installasjon:

```powershell
node ..\tools\build-desktop.js          # bygg om alle mål
node ..\tools\build-desktop.js --check  # avslutt 1 hvis noe er utdatert
```

`release.ps1` kjører bygget og hver port, så en utgivelse kan ikke sende utdata som har drevet bort fra palettene.

<!-- T-311 target/section coverage supplement -->
## Dekning av mål og seksjoner

Denne seksjonen gjenspeiler dekningen av Process Explorer, Notepad++, Cinema
4D og terminalfonter i den gjeldende engelske README-en, slik at denne
oversettelsen ikke stille blir foreldet. Kodeliteralene (mål-ID-er,
registerstier, filnavn) er med vilje språklig uavhengige; teksten rundt er
oversatt.

### Hva hvert mål faktisk kan tematiseres (nye mål)

| mål | mekanisme | overlever en app-oppdatering |
|---|---|---|
| `notepadplusplus` | tema-XML + alias inn i brukerens `themes`-mappe for Notepad++ | ja — det ligger i profilen din |
| `cinema4d` | fargeskjema lagt i brukerens `schemes`-mappe for Cinema 4D | ja — det ligger i profilen din |
| `processexplorer` | `HKCU\Software\Sysinternals\Process Explorer`: radmarkeringens farger og grafikkbakgrunner, se nedenfor | nei — Process Explorer skriver om innstillingene sine ved avslutning; lukk og start på nytt |

### Process Explorer (Sysinternals)

Process Explorer beholder fargene sine i
`HKCU\Software\Sysinternals\Process Explorer` og skriver om den nøkkelen ved
avslutning, så målet **avviser mens `procexp`, `procexp64` eller `procexp64a`
kjører** — lukk og start på nytt. Det tematiserer de konfigurerbare
fargekategoriene:

- **tilgjengelige**: radmarkeringsfargene for prosesser (`ColorOwn`,
  `ColorServices`, `ColorRelocatedDlls`, `ColorImmersive`, `ColorPacked`,
  `ColorJobs`, `ColorNet`, `ColorProtected`, `ColorNewProc`, `ColorDelProc`,
  `ColorSuspend`) i både lysmodus- og `*Dark`-varianter, pluss grafikkbakgrunnene
  (`ColorGraphBk`, `ColorGraphBkDark`) — 24 verdier totalt. Hver variant blandes
  mot den tilsvarende polen i den aktive paletten (den lysere nyansen til
  lysmodus-fyllingen, den mørkere til `*Dark`), slik at radfyllene beholder
  palettens egen nyanse i stedet for å blekne nesten til hvit;
- **ikke tilgjengelige**: tittelfeltet, menylinjen, verktøylinjen, bakgrunnen
  og tekstfargene i listevisningen, samt grafikklinjefargene — de er kompilert
  inn i `procexp.exe` og eksponeres av ingen innstillingsverdi. Målet
  tematiserer radmarkeringene og grafikkbakgrunnen som det faktisk eier, og
  gjør ingen større påstander.

Hver verdi som Apply kan endre, tas som øyeblikksbilde før endringen
(gjenoppretting ved første berøring i
`%APPDATA%\Wintage\recovery\processexplorer\`) og settes eksakt tilbake av
`-Revert`, inkludert om hver verdi var fraværende og om markøren var til steds-
men tom. En bærbar mappe utenfor de vanlige Sysinternals-katalogene huskes via
den kanoniske `processexplorer`-nøkkelen i `paths.json` (CLI-argument
`-ProcessExplorerPath`; GUI-en kan også velge den).

### Terminalfonter (`fonts/terminal/`)

Begge terminalmålene leser ÉN kanonisk typografisk innstilling i
`%APPDATA%\Wintage\terminal-font.json` (`schema`, `fontSlug`, `family`, `size`,
`renderingMode`). Når filen mangler, beholder målene den utleverte
standardverdien (Terminus (TTF) for Windows, 12 pt, med alias), så eksisterende
maskiner forblir uendret. En ugyldig innstilling feiler lukket: ingenting
skrives over, og målet avviser.

`fonts/terminal/catalog.json` er den eneste skriftkatalogen: 20 medleverte
open source monospace-familier pluss de to systemtypene Wintage navngir, men
aldri leverer (Terminus (TTF) for Windows, Consolas). Hver medlevert oppføring
inneholder sin opprinnelseskilde, pinnet revisjon, lisens-ID, lisensfil og
SHA-256. De eksakte filene ligger i `fonts/terminal/files/` med
lisenstekstene i `licenses/`; Wintage i drift jobber helt offline og laster
aldri ned en skrift.

`tools/sync-terminal-fonts.ps1` er nedlasteren kun for vedlikeholdere. Den
leser `fonts/terminal/sources.json` (én uforanderlig artefakt per familie),
verifiserer hver SHA-256 og avviser ved avvik. `-VerifyOnly` (standard)
sjekker treet på disk uten nettverk; `-Fetch -Write` legger filene inn på nytt.
Nedlastede skriftbyte behandles som ubetroede binære eiendeler — hasht og
skrevet, aldri kjørt. Én erstatning er registrert: **Fantasque Sans Mono**
erstatter Liberation Mono, som ikke publiserer noen pinnet binær utgivelse
(kun kilde-`.sfd`).

Installatøren **utforsker skrifter, den installerer dem ikke.** Fanen
TERMINAL FONTS laster en medlevert skrifttype inn i en prosesslokal
`PrivateFontCollection` for et levende forhåndsbilde, og utfører **null**
systemregistrering av skrifter. Å velge skrift, størrelse (7–24 pt) eller
gjengivelsesmodus (aliased/grayscale/cleartype) oppdaterer bare forhåndsbildet
og innstillingene. Å installere en skrift er en egen **INSTALL SELECTED**
-handling som åpner Windows sin egen skriftinstallatør; etter Windows sin
bekreftelse sjekker brukeren på nytt med Refresh. Reelle terminalendringer
skjer først ved en eksplisitt **APPLY TERMINAL / APPLY CONHOST / APPLY BOTH**.

Windows Terminal brukes på den valgte installerte familien i den valgte
størrelsen, og gjengivelsesmodusen kartlegges til
`profiles.defaults.antialiasingMode`. Klassisk conhost er strengere: det
gjengir på et fast cellerutenett, så en valgt skrifttype avvises før enhver
registerendring med mindre Windows løser den opp (standardtypen og
Consolas-reserveen er fritatt). Health og Reapply validerer den innstilte
skrifttypen, størrelsen og kantglattingen mot innstillingen, så en endring av
innstillingen etter en Apply rapporteres som avvik i stedet for som "frisk".
Terminalfargenes livssyklus er urørt: Revert gjenoppretter de eksakte verdiene
som var i Wintages eie før den, og fjerner aldri en skrift fra maskinen.
<!-- source-digest: desktop/README.md sha256:15c96dac8494ab84 -->
