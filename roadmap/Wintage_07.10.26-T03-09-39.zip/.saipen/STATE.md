---
phase: DONE
task: none
next_action: "saipen continue"
blocker: none
agent: saipen-cli
saipen_version: 7
schema_version: 3
saipen_home: V:\___VAC\__K\__CODE\_AI_STUFF_AGENTIC\_SAIPEN
mode: full
last_event: 3362
style_contract: ded-069a4c52
updated: "2026-10-06T04:28:45Z"
transition_from: DONE
execution_intent: goal
goal_waves: 0
goal_tickets: 3
---

# Active Work

None. phase DONE, no active task. The authoritative state is the frontmatter
above plus BOARD + LOG. This prose body is agent-owned handoff narrative: the
canonical STATE rewriter owns ONLY the frontmatter and preserves everything
after the closing fence byte-for-byte (state.py, T-1003), so NO engine
operation regenerates it -- recorded as a protocol/reporting defect (a stale
body advanced alongside a live frontmatter and can mislead a cold-recovery
reader; frontmatter authority preserved). Do not resurrect T-246 or any
audit-era Work from prose; only frontmatter + BOARD + LOG are truth.

## Current machine truth (2026-09-24, post-audit/8 blocked-debt reconciliation)

- audit/8 umbrella T-286 DONE; children T-289..T-302 DONE; close-out T-303 DONE (E-1629). T-246 and all audit/5..audit/8 clauses terminal.
- T-304 (SRC-021, stale "continue audit/7 T-268 CORE-006") reconciled and FINISHED: T-268 was already DONE (E-1195/E-1196); zero product delta.
- work_closure_evidence debt cured on the current tree: reverify receipts RV-000050..53 bound for T-244/T-245/T-357/T-243 (PASS_WITH_CARRIED_DEBT, evidence_class executed, strict_gate:core), each running its own ticket check -- T-243 ran the full tests/Run-Tests.ps1. These replace the RV-000004..6 set, which was bound to the stale head 82178cd. NOTE: the receipts bind the current WORKING-TREE fingerprint, so committing the staged tree moves it and the sweep must be re-run before the gate is green again.
- 2026-10-05 (post-T-902, commit c62d89d): that note fired as predicted. The T-902 commit moved the tree and all four receipts went stale (four closure-evidence FAILs). Re-bound on the current tree with real executed checks: T-244 `node --check wintage.user.js`, T-245 `pwsh -NoProfile -File tools/test-totalcmd-recovery.ps1`, T-357 `node tools/test-inspect-web.js`, T-243 `.saipen/kitchen/verify-t243-readonly.js`. The T-243 kitchen check itself had to be maintained first: T-413 (c528ef3) deleted tools/test-goodemoji.js and tools/test-goodemoji-matchsrc.js when it delegated the BetterDiscord plugins to their canonical repository, so the check's pinned list named two files this project no longer owns and failed with "2 of 6 read-only gates did not pass" (both a missing module, exit 1) -- a receipt is only minted for a PASS verdict, which is why that one ticket kept failing while its three neighbours passed. The list now carries the four surviving gates and a comment naming T-413 as the authority for the narrowing. Correction to an earlier reading of this same evidence: the stale receipt was NOT an ordering artifact -- `work reverify` answers REVERIFY_REUSED while a current-tree PASS receipt exists, including after later memory writes, so re-binding is needed only when the verdict or the tree's product delta changes.
- Parked blockers (the only four):
  - T-259 BLOCKED: user-cancelled, no recoverable spec (do not reconstruct).
  - T-250 BLOCKED: deliverable complete as T-254/SRC-010:R001 (locale parity re-proven 2026-09-24: 33/33 files, en.json 84 keys, LanguageLabel present, zero missing/extra); closure impossible because its BOARD row names tombstone SRC-007 (linked_work T-246) and no canonical mechanism rebinds a live ticket's source_receipts (source link: active only; repair-metadata: DONE rows only; supersede: refuses carried receipts; resolve-external: same gate). SOURCE_RECEIPT_MISSING is now a registered clean refusal -- the 16.09 raw-ValueError escape is fixed.
  - T-238 BLOCKED: guard premise stale (current guard T-1387 admits ordinary .saipen paths; kitchens are not protected namespaces) and all 31 legacy-only kitchen files are proven superseded (canonical strict superset), but the verify clause needs engine-side validate.py repair (reads the legacy kitchen path first; unsatisfiable 64-vs-16-hex digest compare), a fresh saitranslate producer round (SAIT-005: locales/README.ja.md then uk), and extensions/subs/MANIFEST.md registration -- none owned in this project.
  - T-065 BLOCKED: requires an authenticated YouTube Studio session.
- Remaining chronic validator problems (carried debt, none curable from here): E-838 missing op marker (historical hand-append), saihunt OUTBOX write-boundary reference, hunt mark @82178cd naming an unpushed commit (push is user-gated), saitranslate sub STATE next_action + sub BOARD duplicate SAIT-004 (sub-side canonical state with no Core-side writer).
- CURED 2026-10-05 (was on this list as `sweep-ticket-link`): T-418 is ## DONE and its improve sweeps carried no recurrence:/weak_model: gates, which the strict sweep refuses. `saipen ticket reasoning T-418 --recurrence ... --weak-model ...` wrote both fields (code TICKET_REASONING_WRITTEN); the recurrence text names the two independent sweeps that converged on the same defect (imp-vacterro-wintage-20261005-4 RUN-1/IMP-005 and imp-vacterro-wintage-20261005-5 RUN-1/IMP-004) and the weak-model text names the decidable predicate plus its existing red control. Note for the next agent: that command refuses text containing a newline (BOARD scalars must render as one record) -- pass one plain line per gate.
- CURED 2026-09-30, do not re-add to the list above: `improve report protocol_fingerprint` was real and is gone. Every seat of imp-vacterro-wintage-20260930-1 carried a pre-v8.0.1 protocol fingerprint, and the install then moved twice more under an active editor, so no report written earlier can ever validate. A report is only valid against the protocol as installed at the moment it is written, which means an improve cycle cannot be kept valid while another session is editing the protocol repo -- freeze the tree AND the protocol, or the cycle's own evidence is what turns the gate red.

## Full matrix, current

tests/Run-Tests.ps1 ALL TESTS PASSED (2026-09-24, real Windows checkout, exit 0), including test-presets.ps1 (-RedControl), test-locale-parity.ps1 (33/33 locales, 84-key parity), repainter-budget, browser-cache and every audit/8 focused gate. Generated Electron payload re-proved aligned at E-936.

2026-10-05, post-T-902 run (default index, no GIT_INDEX_FILE), `pwsh -NoProfile -File
tests/Run-Tests.ps1`: `head=c62d89d ... exit=1 errors=6`, log
`.saipen/logs/run-tests-last.txt`. All six failing entries are the SAME environment
defect, not product: `FullyQualifiedErrorId : CommandNotFoundException` on the
literal `powershell`, which does not exist on this box (pwsh 7 only). The entries
are legacy tool-launcher rows that hardcode `powershell -NoProfile
-ExecutionPolicy Bypass -File ...`: test-batch-streaming-gui.ps1 (suite +
-RedControl), test-readme-target-parity.ps1 (suite + -RedControl),
test-processexplorer.ps1, stamp-readme-digests.ps1 -RedControl. Proven not product
by driving the strongest of them directly with the interpreter that IS present:
`pwsh -NoProfile -File tools/test-readme-target-parity.ps1` -> `395 PASS, 0 FAIL`,
exit 0. Every other suite, including all three new T-902 Reddit gates and
test-diag-counters.js, is green in the same run. The earlier 11-error runs in this
session were this same six plus test-browser-cache.ps1 (live smoke under concurrent
load) and three git-index casualties caused by pointing GIT_INDEX_FILE at a
repo-external index while the suite spawns scratch repositories -- that variable
must not be set for a full-suite run.

## SAIOPS is refused in this project, deliberately

`E-837` records it in full: fast validation demands a CONSECUTIVE E-ID chain, and this project carries two documented T-222-era stub-backfill gaps (E-703->E-717, E-718->E-722). E-774 relaxed that rule in the shared install; the saipen project has since reverted it and proved on a fixture that the relaxed rule accepts a forged log line. So E-865..E-888 are hand-appended with no `[op: ...]` id and the validator's `[saio]` provenance check lists them by design.

E-940 (one-time ledger repair, user-authorized) removed the three FLOOR/order defects that kept every mutating SAIOPS operation refused: the T-222-era LEDGER-GAP AMNESTY DECs were re-issued as E-937/E-938/E-939 so they are strictly increasing and, crucially, sit AT OR AFTER the gap they exempt (a DEC older than the gap it covers cannot bound it). Same text, same pairs, same scope -- ids and positions only; nothing was deleted (tree vs HEAD: 0 missing lines; the damaged intermediate is preserved under `.saipen/recovery/conflict-evidence/ledger-repair-20260916/`). Sealed-segment debt is untouched. Plan and write are live again for this project: E-941/E-942 (reconcile), E-943/E-944 (R015 build + transition), E-945 (R015 verify) were all written by the engine itself.

## Goal safety valve: tripped (2026-10-05, needs the operator)

`execution_intent: goal` with `goal_waves: 0` / `goal_tickets: 20` has reached the
RFC § 2.4 caps (3 waves / 20 tickets), so this wave is CONVERGED, not merely
idle. `next_action` carries the canonical form the validator demands for that
state (`WAIT: safety valve reached (0 waves / 20 tickets) -- run 'cc' to
continue`); the engine's own auto-written `saipen continue` is refused by the
core gate while the valve is tripped. Nothing else may be started until the
operator re-arms the goal with `cc` (or names a new objective with `saipen
goal`). T-902 ("Reddit runs the lean CSS-only path", commit c62d89d) was the
last ticket of the wave and is FINISHED.

## TODO (operator, unblocked only by a human)

- **T-359** — the only open board row (127 done / 1 open). Live ChatGPT acceptance for T-357/T-358. The tool half is proven and closed by T-365: `node tools/test-inspect-web-cdp-live.js` drives the real CLI over real CDP. What remains needs a browser session only the operator can start: sign in to chatgpt.com on a profile you own, quit the browser, relaunch it with `--remote-debugging-port=9222`, then run `node tools/inspect-web.js watch chatgpt.com 900 --attribute` and open each requested surface by hand. Re-probed 2026-09-30 23:15Z: nothing is listening on 127.0.0.1:9222, so this is genuinely blocked, not merely unstarted. Paste the bounded pass report back and T-359 closes.

## Untracked files that must ride the next ship

desktop/targets/cinema4d/ and desktop/targets/notepadplusplus/ templates (T-243 era), tools/test-vscode-recovery.ps1 (SRC-006:R004, E-895), tools/test-reapply-intent.ps1 (SRC-006:R005, E-899/E-900), tools/test-logon-task-gui.ps1 (concurrent actor, E-897). Tracked-but-modified T-242 surfaces: desktop/install.ps1, desktop/modules/common.ps1, tests/Run-Tests.ps1, desktop/WintageInstaller.ps1 (concurrent), tools/install-electron.js (concurrent R007 WIP).

## 2026-10-06 corrective: the ChatGPT viewport owner drifted, and nothing compared the two records

T-373 (2026-10-04) fixed the real defect of its moment: the viewport owner of the
then-current ChatGPT shell is `[data-testid="mobile-app-shell-scroll-container"]`,
theming an ancestor does not theme the area you look at, and the browser fixture
was rebuilt to reproduce that shell. That work is still correct.

What it did NOT do is keep the contract in one place. Between T-373 and T-903 the
signed-in shell moved on: the shell ChatGPT actually serves now owns its viewport
with `div.thread-scroll-container` inside a plain `main`, and its composer editor
is `[role="textbox"][contenteditable="true"]`. `tools/inspect-web.js` had already
measured exactly that — it lists `div.thread-scroll-container` and plain `main`
as ALWAYS `app-scroll-container` surfaces and the role=textbox editor as ALWAYS
`prompt-editor` — while production `CHATGPT_FAST_CSS` and every static gate still
bound only the retired data-testid contract, and the browser fixture still built
the retired shell. So the sheet, the inspector and the fixture could each be
updated on its own and stay green, and the signed-in page was stock black with
all gates passing. The inspector knew first; production CSS and its tests did not;
no gate compared them. That is the durable lesson, and it is a tooling/reporting
defect of the same family as the other drift entries on this board, not a theming
regression.

T-903 (SRC-066, E-3316..E-3328, closure own_patch) closes the product half on the
current tree: `html[data-w95-chatgpt="1"] div.thread-scroll-container`, plain
`html[data-w95-chatgpt="1"] main`, and `html[data-w95-chatgpt="1"]
[role="textbox"][contenteditable="true"]` (colour + caret only; the editor is
transparent in live measurement and `[data-composer-dark]` is its painted owner,
so the parent is left fail-open) are now bound, every older selector is retained
as rollout fallback, and no current-live hook shares a rule with a fallback.
`tools/chatgpt-live-contract.js` is the single contract-truth list, consumed by
`tools/test-chatgpt-2026.js`, `tools/test-chatgpt-perf-css.js` and the new
`tools/test-chatgpt-contract-parity.js`, the last of which refuses any surface the
inspector calls ALWAYS that the shipped sheet does not bind or explicitly name as
a transparent host. `tools/test-chatgpt-viewport-coverage.js` now drives three
generations (September/October rollout, current-live `thread-scroll-container >
main`, current-live `main > thread-scroll-container`) across six states and six
red controls; RC6 removes ONLY the current-live viewport rule and returns the
fixture to stock black while every rollout rule stays bound.

DO NOT read T-903 as ChatGPT visual acceptance. Acceptance is T-359 and it is
still OPEN and BLOCKED: nothing is listening on 127.0.0.1:9222, so no signed-in
page has been observed since the change. T-359's todo above stands unchanged —
sign in, relaunch with `--remote-debugging-port=9222`, run
`node tools/inspect-web.js watch chatgpt.com 900 --attribute`, open each requested
surface by hand, paste the bounded report back. Static gates, however green, are
not that.

## Correction to the T-903 round: the Playwright prerequisite was NOT durable

The T-903 hand-off report said the Playwright prerequisite was "already declared
(`devDependencies.playwright ^1.62.1`, in the lockfile)". That was wrong about
the durable repository, and the operator found it by cutting a clean archive and
running the gate: `node tools/test-chatgpt-viewport-coverage.js` exited 1 with
`Cannot find module 'playwright'`.

The files existed, and declared exactly that dependency, but they were NOT in
the repository. `.gitignore:66-67` ignored `package.json` and
`package-lock.json`, and `git ls-files` returned nothing for either: both were
working-copy-only. So the gate promised a deterministic prerequisite
(`npm ci` then `npx playwright install chromium`) that no clean checkout and no
archive could satisfy. The T-903 statement was true of this machine and false of
the artifact -- the same class of error as the T-413 delivery report that
described a `package.json` edit nobody could open, which is a defect this board
already carries twice (T-417, and imp-vacterro-wintage-20261005-4 RUN-1/IMP-004).
Grepping the shipped string for the dependency is not the same test as asking
whether the manifest that declares it is tracked.

T-906 (SRC-067, closure own_patch) repairs it: both manifests are tracked with
their content unchanged, `node_modules/` stays ignored, and
`tests/Run-Tests.ps1`'s non-vacuity probe no longer borrows a file --
`package.json` WAS that probe, and the note beside it said "if that file is ever
tracked, move the probe, not the check", so the probe is now a scratch
`.saipen/logs/untracked-probe.txt` the check creates and deletes. The two
in-repo comments that asserted the file was ignored keep their historical clause
and carry the correction appended. Verified on this tree after removing
`node_modules` entirely: `npm ci` (canonical npm 12.0.2 / node v24.15.0, 2
packages), `npx playwright install chromium`, then the gate at 114 PASS / 0 FAIL
with all six red controls firing.

## T-907: the same defect one layer down -- thirteen files the suite runs were staged for deletion

T-906 proved a clean archive now carries `package.json` and `package-lock.json`
by listing those two paths out of the written index tree
`c0055f1940c16378d59fa7b5f318dd25e252812d`. Naming only the files it had just
tracked is precisely what hid the next thing: that same tree was missing thirteen
others.

Thirteen paths were in HEAD and in the checkout -- byte-identical to HEAD in
twelve cases, the thirteenth (`tools/test-inject-wintage-web.js`) differing only
by line endings -- and were staged as DELETIONS with no rename counterpart: three
`KNOWLEDGE/ADR-008.md`, `ADR-009.md`, `ADR-010.md` and ten `tools/` files --
`stamp-readme-digests.ps1`, `test-build-desktop-publish.js`,
`test-commit-scope.ps1`, `test-generation-handover.js`,
`test-inject-wintage-web.js`, `test-manifest-forward-compat.ps1`,
`test-reddit-cssonly.js`, `test-reddit-mutation-stress.js`,
`test-reddit-repaint-gates.js`, `test-release-rollback-split.ps1`. The INDEX copy
of `tests/Run-Tests.ps1` still named `test-commit-scope.ps1` twice and
`stamp-readme-digests.ps1` twice, so this was not a coherent retirement: a commit
from that index would have written a tree whose own suite invokes files the
archive no longer carries. Same defect class as T-906 and T-417 -- the artifact
promises a file it does not ship -- and it is the failure the T-416 check in
`tests/Run-Tests.ps1` was built to catch, sitting in that check's one blind spot:
it accepts HEAD as a carrier, which is deliberate because this project commits
through a private index, but that leniency also passes a path the index being
written would delete.

The index entries were restored from the working tree, so no content moved; the
one remaining staged deletion, `.saipen/intake/active/SRC-015.meta.json`, is a
real retirement whose file is gone from disk as well. `Run-Tests.ps1` now asserts
that every path staged for deletion is also absent from the checkout, which is
what would have named all thirteen on the day they drifted. Verified with a
private-index red control (`git read-tree HEAD` into a throwaway index, then
`git update-index --force-remove tools/test-commit-scope.ps1`: the predicate
reports one live deletion and fails) against the real index (one staged deletion,
zero live, PASS). The full suite then ran at exit 1 / errors=6 -- the six
documented no-literal-`powershell` environment failures, in a run where the
documented `test-browser-cache.ps1` concurrent-load flake did not recur -- with
all three structural assertions PASS, and the archive tree
`0267a61c110dfb8504d2abb21b4decce8e1441b6` now carries all thirteen plus both
manifests.

Cause not established, and recorded as such rather than guessed: this session's
T-906 commands staged only `.gitignore`, `tests/Run-Tests.ps1`,
`tools/check-delivery-claims.ps1` and the two manifests, and `git add <pathspec>`
cannot remove an index entry outside its pathspec. The same pattern had already
been seen once before, on `tools/test-chatgpt-viewport-coverage.js` during T-903.
That an index can carry this silently for rounds is the finding; whichever
mechanism produced it, the new assertion is what makes it visible.

## 2026-10-06 (qq + ee + ship): two producer packages now await collect, and ship is not this project's command

- `qq` (saiwiki) published **W-011** at HEAD c62d89d / fp `git-delta-v1:58c4eeac`
  / role `54a42475`: v1.36.6 restamp, Desktop.md target table re-aligned to the
  22 live keys, Known-Behaviors.md re-aligned to the code, Development.md gates
  and ADR range corrected. 8/8 pages verified; `saipen outbox check saiwiki`
  exit 0. W-010 -> stale.
- `ee` (saitranslate) published **SAIT-009** at the same identity / role
  `7d18729f`: the 28 installer-UI keys added by the terminal-font, themes and
  preset rounds were English copy-paste in ALL 29 producer-owned locale JSONs
  (812 strings), invisible to every gate because all three locale gates are
  core-only or structural -- `test-locale-semantic.ps1` says so in its own
  header (line 21). All 812 translated; each kitchen file now mirrors the repo's
  80-key file with only those 28 values changed. The kitchen copies also held
  50 keys, so the old payload would have DELETED 30 keys per file on collect.
  Kitchen desktop + root README drafts resynced to the repo; all three doc
  digests current 32/32 on both sides. Gate counts at c62d89d:
  readme-target-parity 395/0, locale-parity 68/0, locale-semantic 52/0,
  locale-keys 11/0. `saipen outbox check saitranslate` exit 0. SAIT-008 ->
  stale, with the correction that the root README translations ARE integrated,
  at `locales/README.<lang>.md` (SAIT-008 read the repo root directory and
  concluded the surface did not exist).
- Awaiting an explicit collect (`qqq` / `eee`). Nothing was written under the
  main tree by either role, and nothing is committed or pushed.
- `saipen ship` **refused by design**: `VALIDATION_FAILED -- VERSION is missing
  from the repository root`, "publish a versioned release and does not apply to
  a project without one". That is consistent with this project's own record
  (E-3189, E-3199, E-3215, E-3225: "ship is not this project's command"; the
  version lives in `wintage.user.js` as `// @version` + `W95_VERSION` and is
  bumped by `release.ps1`). No VERSION file was invented to satisfy it.
- `saipen next` then routes to **PHASE SCOUT T-905**. Scouted, not repaired:
  both of its red controls reproduce on the current installs, and the repair
  target is the shared protocol home `V:\...\_SAIPEN`, which this project does
  not own -- the T-238 note above leaves an engine-side repair open for the same
  reason. Two facts make a home-only patch insufficient: `saipen/phases/verify.md`
  is byte-identical in the home and in the live runtime, while
  `tools/saipen.py` in the live runtime is an older deploy (2026-10-05 11:32 vs
  the home's 2026-10-06 06:42). Evidence and ready-to-apply patch text:
  `.saipen/kitchen/T-905-SCOUT-EVIDENCE.md`.

## 2026-10-06 close-out: gate green, and the two engine tickets are now honestly blocked

- The scout above would otherwise be re-run by every following agent, because a
  completed scout that reached "not workable here" left the row in TODO. Both
  engine-side rows are now `## BLOCKED` with the gate named in the blocker:
  T-905 (IMP-002/IMP-003, undiscoverable sanctioned routes) and T-904 (IMP-001,
  `ticket_block` refusing an already-BLOCKED ticket). Their owner is the seat
  that owns the shared install, not Vintage; the blocker text says what flips
  them back (the two red controls in the scout evidence). Journaled by the
  engine as E-3361/E-3362, so no hand-appended line was added -- the E-838
  op-marker debt is not extended by this cycle.
- The four `work_closure_evidence` FAILs were the debt the 2026-10-05 note
  predicted: the T-902 commit moved the tree and the receipts went stale with
  it. Re-bound on this tree as RV-000137 T-244, RV-000138 T-243, RV-000139
  T-245, RV-000140 T-357, all `PASS_WITH_CARRIED_DEBT` / `evidence_class:
  executed`. Canonical validator now exits 0: 26 PASS, 0 FAIL (was 6 FAIL at the
  start of this compound). The same note applies again: the next commit moves
  the working-tree fingerprint and these four go stale a third time, so the
  sweep has to be re-run after it.
- What this wave did NOT do: no product file was touched (every write is under
  `.saipen/`, plus scratch outside the repo), nothing was committed, nothing was
  pushed. W-011 (saiwiki) and SAIT-009 (saitranslate) remain `ready` in their
  own OUTBOXes awaiting an explicit collect; `saipen next` now answers `saipen
  continue` / maintain with zero workable tickets, because everything left is
  blocked on the operator (T-359 signed-in chatgpt.com tab, T-376 signed-in
  Discord) or on the shared install (T-904, T-905).
